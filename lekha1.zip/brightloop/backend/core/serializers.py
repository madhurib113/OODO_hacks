from django.contrib.auth.password_validation import validate_password as run_password_validators
from django.db import transaction
from django.utils import timezone
from rest_framework import serializers

from . import services
from .models import (Discount, Invoice, InvoiceLine, Payment, Plan, Product, ProductVariant,
                     QuotationTemplate, QuotationTemplateLine, Subscription, SubscriptionLine,
                     TaxRule, User)


# ---------------------------------------------------------------- users
class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["id", "email", "first_name", "last_name", "company", "role", "date_joined"]
        read_only_fields = fields


class RegisterSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True)
    first_name = serializers.CharField(required=False, allow_blank=True, max_length=150)
    last_name = serializers.CharField(required=False, allow_blank=True, max_length=150)
    company = serializers.CharField(required=False, allow_blank=True, max_length=150)
    role = User.Role.CUSTOMER

    def validate_email(self, value):
        value = value.strip().lower()
        if User.objects.filter(email__iexact=value).exists():
            raise serializers.ValidationError("An account with this email already exists.")
        return value

    def validate_password(self, value):
        run_password_validators(value)
        return value

    def create(self, data):
        return User.objects.create_user(role=self.role, **data)


class StaffCreateSerializer(RegisterSerializer):
    role = User.Role.STAFF


class PasswordResetRequestSerializer(serializers.Serializer):
    email = serializers.EmailField()


class PasswordResetConfirmSerializer(serializers.Serializer):
    uid = serializers.CharField()
    token = serializers.CharField()
    password = serializers.CharField(write_only=True)

    def validate_password(self, value):
        run_password_validators(value)
        return value


# ---------------------------------------------------------------- catalog
class ProductVariantSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source="product.name", read_only=True)

    class Meta:
        model = ProductVariant
        fields = ["id", "product", "product_name", "attribute", "value", "extra_price"]


class ProductSerializer(serializers.ModelSerializer):
    variants = ProductVariantSerializer(many=True, read_only=True)

    class Meta:
        model = Product
        fields = ["id", "name", "type", "sales_price", "cost_price", "notes", "is_active", "variants"]


class PlanSerializer(serializers.ModelSerializer):
    class Meta:
        model = Plan
        fields = "__all__"

    def validate(self, a):
        s, e = a.get("start_date"), a.get("end_date")
        if s and e and e < s:
            raise serializers.ValidationError("End date must be after the start date.")
        return a


class TemplateLineSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source="product.name", read_only=True)

    class Meta:
        model = QuotationTemplateLine
        fields = ["id", "product", "product_name", "variant", "quantity"]


class QuotationTemplateSerializer(serializers.ModelSerializer):
    lines = TemplateLineSerializer(many=True, required=False)
    plan_name = serializers.CharField(source="plan.name", read_only=True)

    class Meta:
        model = QuotationTemplate
        fields = ["id", "name", "validity_days", "plan", "plan_name", "lines"]

    @transaction.atomic
    def create(self, data):
        lines = data.pop("lines", [])
        t = QuotationTemplate.objects.create(**data)
        QuotationTemplateLine.objects.bulk_create([QuotationTemplateLine(template=t, **l) for l in lines])
        return t

    @transaction.atomic
    def update(self, inst, data):
        lines = data.pop("lines", None)
        for k, v in data.items():
            setattr(inst, k, v)
        inst.save()
        if lines is not None:
            inst.lines.all().delete()
            QuotationTemplateLine.objects.bulk_create([QuotationTemplateLine(template=inst, **l) for l in lines])
        return inst


class TaxRuleSerializer(serializers.ModelSerializer):
    class Meta:
        model = TaxRule
        fields = "__all__"


class DiscountSerializer(serializers.ModelSerializer):
    class Meta:
        model = Discount
        fields = "__all__"
        read_only_fields = ["times_used"]

    def validate(self, a):
        if a.get("kind") == Discount.Kind.PERCENT and a.get("value", 0) > 100:
            raise serializers.ValidationError({"value": "A percentage discount cannot exceed 100."})
        if a.get("apply_to") == Discount.Scope.PRODUCT and not a.get("product"):
            raise serializers.ValidationError({"product": "Choose the product this discount applies to."})
        s, e = a.get("start_date"), a.get("end_date")
        if s and e and e < s:
            raise serializers.ValidationError("End date must be after the start date.")
        return a


# ---------------------------------------------------------------- subscriptions
class SubscriptionLineSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source="product.name", read_only=True)
    variant_name = serializers.SerializerMethodField()
    tax_rate = serializers.SerializerMethodField()
    amount = serializers.SerializerMethodField()

    class Meta:
        model = SubscriptionLine
        fields = ["id", "product", "product_name", "variant", "variant_name", "quantity",
                  "unit_price", "tax_rate", "amount"]
        extra_kwargs = {"unit_price": {"required": False}}

    def get_variant_name(self, o):
        return f"{o.variant.attribute}: {o.variant.value}" if o.variant_id else None

    def get_tax_rate(self, o):
        return str(self.context.setdefault("tax_table", services.TaxTable()).rate_for(o.product_id))

    def get_amount(self, o):
        return str(services.q2(o.unit_price * o.quantity))

    def validate(self, a):
        v = a.get("variant")
        if v and v.product_id != a["product"].id:
            raise serializers.ValidationError("That variant does not belong to the chosen product.")
        return a


class SubscriptionSerializer(serializers.ModelSerializer):
    lines = SubscriptionLineSerializer(many=True, required=False)
    customer_email = serializers.CharField(source="customer.email", read_only=True)
    customer_company = serializers.CharField(source="customer.company", read_only=True)
    plan_name = serializers.CharField(source="plan.name", read_only=True)
    billing_period = serializers.CharField(source="plan.billing_period", read_only=True)
    plan_closable = serializers.BooleanField(source="plan.closable", read_only=True)
    plan_pausable = serializers.BooleanField(source="plan.pausable", read_only=True)
    plan_renewable = serializers.BooleanField(source="plan.renewable", read_only=True)
    total = serializers.SerializerMethodField()

    class Meta:
        model = Subscription
        fields = ["id", "number", "customer", "customer_email", "customer_company", "plan", "plan_name",
                  "billing_period", "plan_closable", "plan_pausable", "plan_renewable", "template", "status",
                  "start_date", "expiry_date", "payment_terms_days", "quotation_valid_until",
                  "next_invoice_date", "is_paused", "notes", "created_at", "lines", "total"]
        read_only_fields = ["number", "status", "next_invoice_date", "is_paused", "created_at"]

    def get_total(self, o):
        return str(sum((services.q2(l.unit_price * l.quantity) for l in o.lines.all()), services.Decimal("0")))

    def validate_customer(self, u):
        if u.role != User.Role.CUSTOMER:
            raise serializers.ValidationError("Subscriptions belong to customer accounts.")
        return u

    def validate(self, a):
        plan = a.get("plan") or getattr(self.instance, "plan", None)
        start = a.get("start_date") or getattr(self.instance, "start_date", None)
        exp = a.get("expiry_date", getattr(self.instance, "expiry_date", None))
        if exp and start and exp < start:
            raise serializers.ValidationError({"expiry_date": "Expiry must be on or after the start date."})
        if plan and start:
            if plan.start_date and start < plan.start_date:
                raise serializers.ValidationError({"start_date": f"This plan is available from {plan.start_date}."})
            if plan.end_date and start > plan.end_date:
                raise serializers.ValidationError({"start_date": f"This plan ended on {plan.end_date}."})
        for l in a.get("lines", []):
            if plan and l["quantity"] < plan.min_quantity:
                raise serializers.ValidationError({"lines": f"Minimum quantity for this plan is {plan.min_quantity}."})
        return a

    def _save_lines(self, sub, lines):
        objs = []
        for l in lines:
            price = l.get("unit_price")
            if price is None:
                price = l["product"].sales_price + (l["variant"].extra_price if l.get("variant") else 0)
            objs.append(SubscriptionLine(subscription=sub, product=l["product"], variant=l.get("variant"),
                                         quantity=l["quantity"], unit_price=price))
        SubscriptionLine.objects.bulk_create(objs)

    @transaction.atomic
    def create(self, data):
        lines = data.pop("lines", [])
        sub = Subscription.objects.create(status=Subscription.Status.DRAFT, **data)
        self._save_lines(sub, lines)
        return sub

    @transaction.atomic
    def update(self, inst, data):
        lines = data.pop("lines", None)
        if lines is not None and inst.status not in (Subscription.Status.DRAFT, Subscription.Status.QUOTATION):
            raise serializers.ValidationError({"lines": "Lines can only be edited in Draft or Quotation status."})
        for k, v in data.items():
            setattr(inst, k, v)
        inst.save()
        if lines is not None:
            inst.lines.all().delete()
            self._save_lines(inst, lines)
        return inst


class FromTemplateSerializer(serializers.Serializer):
    template = serializers.PrimaryKeyRelatedField(queryset=QuotationTemplate.objects.all())
    customer = serializers.PrimaryKeyRelatedField(queryset=User.objects.filter(role=User.Role.CUSTOMER))
    start_date = serializers.DateField(default=timezone.localdate)
    expiry_date = serializers.DateField(required=False, allow_null=True)

    @transaction.atomic
    def create(self, d):
        t = d["template"]
        sub = Subscription.objects.create(
            customer=d["customer"], plan=t.plan, template=t, status=Subscription.Status.QUOTATION,
            start_date=d["start_date"], expiry_date=d.get("expiry_date"),
            quotation_valid_until=timezone.localdate() + services.timedelta(days=t.validity_days),
        )
        objs = []
        for l in t.lines.select_related("product", "variant"):
            price = l.product.sales_price + (l.variant.extra_price if l.variant else 0)
            objs.append(SubscriptionLine(subscription=sub, product=l.product, variant=l.variant,
                                         quantity=max(l.quantity, t.plan.min_quantity), unit_price=price))
        SubscriptionLine.objects.bulk_create(objs)
        return sub


# ---------------------------------------------------------------- invoices & payments
class InvoiceLineSerializer(serializers.ModelSerializer):
    class Meta:
        model = InvoiceLine
        exclude = ["invoice"]


class InvoiceListSerializer(serializers.ModelSerializer):
    customer_email = serializers.CharField(source="customer.email", read_only=True)
    customer_company = serializers.CharField(source="customer.company", read_only=True)
    subscription_number = serializers.CharField(source="subscription.number", read_only=True)
    outstanding = serializers.DecimalField(max_digits=14, decimal_places=2, read_only=True)
    is_overdue = serializers.SerializerMethodField()

    class Meta:
        model = Invoice
        fields = ["id", "number", "status", "customer", "customer_email", "customer_company", "subscription",
                  "subscription_number", "period_start", "period_end", "issue_date", "due_date", "subtotal",
                  "discount_total", "tax_total", "total", "amount_paid", "outstanding", "is_overdue", "sent_at"]

    def get_is_overdue(self, o):
        return o.status == Invoice.Status.CONFIRMED and o.due_date < timezone.localdate()


class InvoiceDetailSerializer(InvoiceListSerializer):
    lines = InvoiceLineSerializer(many=True, read_only=True)

    class Meta(InvoiceListSerializer.Meta):
        fields = InvoiceListSerializer.Meta.fields + ["lines"]


class PaymentSerializer(serializers.ModelSerializer):
    invoice_number = serializers.CharField(source="invoice.number", read_only=True)
    customer_email = serializers.CharField(source="invoice.customer.email", read_only=True)

    class Meta:
        model = Payment
        fields = ["id", "invoice", "invoice_number", "customer_email", "method", "amount", "date", "note", "created_at"]
        read_only_fields = ["created_at"]

    def validate(self, a):
        inv = a["invoice"]
        if inv.status not in (Invoice.Status.CONFIRMED,):
            raise serializers.ValidationError({"invoice": "Payments can only be recorded against confirmed invoices."})
        if a["amount"] > inv.outstanding:
            raise serializers.ValidationError({"amount": f"Amount exceeds the outstanding balance of {inv.outstanding}."})
        return a

    @transaction.atomic
    def create(self, data):
        inv = Invoice.objects.select_for_update().get(pk=data["invoice"].pk)  # serialise concurrent payments
        if data["amount"] > inv.outstanding or inv.status != Invoice.Status.CONFIRMED:
            raise serializers.ValidationError({"amount": "Invoice balance changed; please retry."})
        data["invoice"] = inv
        payment = Payment.objects.create(recorded_by=self.context["request"].user, **data)
        inv.amount_paid += data["amount"]
        if inv.amount_paid >= inv.total:
            inv.status = Invoice.Status.PAID
        inv.save(update_fields=["amount_paid", "status"])
        return payment
