from datetime import date, timedelta
from decimal import Decimal

from django.core.exceptions import ValidationError as DjangoValidationError
from django.db import IntegrityError, transaction
from django.test import TestCase
from django.utils import timezone
from rest_framework.test import APIClient, APITestCase

from . import services
from .models import (Discount, Invoice, Plan, Product, Subscription, SubscriptionLine, TaxRule, User)
from .validators import BrightloopPasswordValidator


def make_sub(customer, plan, product, qty=2, price="1000", start=date(2026, 1, 1), status="active", **kw):
    sub = Subscription.objects.create(customer=customer, plan=plan, status=status, start_date=start,
                                      next_invoice_date=start if status == "active" else None, **kw)
    SubscriptionLine.objects.create(subscription=sub, product=product, quantity=qty, unit_price=Decimal(price))
    return sub


class Base(TestCase):
    def setUp(self):
        self.admin = User.objects.create_superuser("admin@t.io", "Admin@12345")
        self.staff = User.objects.create_user("staff@t.io", "Staff@12345", role="staff")
        self.cust = User.objects.create_user("c1@t.io", "Cust@12345")
        self.cust2 = User.objects.create_user("c2@t.io", "Cust@12345")
        self.product = Product.objects.create(name="CRM", sales_price=1000)
        self.plan = Plan.objects.create(name="Monthly", price=1000, billing_period="monthly", pausable=True, auto_close=True)
        TaxRule.objects.create(name="GST", rate=Decimal("18"))


class PasswordTests(TestCase):
    def test_rules(self):
        v = BrightloopPasswordValidator()
        for bad in ["Short1!a", "alllowercase1!", "ALLUPPERCASE1!", "NoSpecial123"]:
            with self.assertRaises(DjangoValidationError, msg=bad):
                v.validate(bad)
        v.validate("Goodpass1!")


class DateTests(TestCase):
    def test_month_end(self):
        self.assertEqual(services.add_months(date(2026, 1, 31), 1), date(2026, 2, 28))
        self.assertEqual(services.add_period(date(2026, 3, 1), "weekly"), date(2026, 3, 8))
        self.assertEqual(services.add_period(date(2026, 3, 1), "yearly"), date(2027, 3, 1))


class BillingTests(Base):
    def test_invoice_has_tax_and_totals(self):
        sub = make_sub(self.cust, self.plan, self.product)
        res = services.generate_invoices(as_of=date(2026, 1, 1))
        self.assertEqual(res["created"], 1)
        inv = Invoice.objects.get()
        self.assertEqual((inv.subtotal, inv.tax_total, inv.total), (Decimal("2000"), Decimal("360"), Decimal("2360")))
        self.assertEqual(inv.status, "draft")
        self.assertTrue(inv.number.startswith("INV-"))
        sub.refresh_from_db()
        self.assertEqual(sub.next_invoice_date, date(2026, 2, 1))

    def test_idempotent(self):
        make_sub(self.cust, self.plan, self.product)
        services.generate_invoices(as_of=date(2026, 1, 15))
        again = services.generate_invoices(as_of=date(2026, 1, 15))
        self.assertEqual(again["created"], 0)
        self.assertEqual(Invoice.objects.count(), 1)

    def test_backlog_catches_up_without_gaps(self):
        make_sub(self.cust, self.plan, self.product)
        services.generate_invoices(as_of=date(2026, 3, 15))
        starts = list(Invoice.objects.order_by("period_start").values_list("period_start", flat=True))
        self.assertEqual(starts, [date(2026, 1, 1), date(2026, 2, 1), date(2026, 3, 1)])

    def test_db_constraint_blocks_duplicates(self):
        sub = make_sub(self.cust, self.plan, self.product)
        services.generate_invoices(as_of=date(2026, 1, 1))
        with self.assertRaises(IntegrityError), transaction.atomic():
            Invoice.objects.create(subscription=sub, customer=self.cust, period_start=date(2026, 1, 1),
                                   period_end=date(2026, 1, 31), due_date=date(2026, 2, 15))

    def test_paused_and_inactive_not_billed(self):
        make_sub(self.cust, self.plan, self.product, is_paused=True)
        make_sub(self.cust2, self.plan, self.product, status="draft")
        self.assertEqual(services.generate_invoices(as_of=date(2026, 6, 1))["created"], 0)

    def test_percent_discount_applies_before_tax(self):
        Discount.objects.create(name="10%", kind="percent", value=10, apply_to="subscription")
        make_sub(self.cust, self.plan, self.product)
        services.generate_invoices(as_of=date(2026, 1, 1))
        inv = Invoice.objects.get()
        # 2000 - 200 = 1800, tax 324, total 2124
        self.assertEqual((inv.discount_total, inv.tax_total, inv.total), (Decimal("200"), Decimal("324"), Decimal("2124")))

    def test_discount_usage_limit_stops_it(self):
        d = Discount.objects.create(name="One shot", kind="fixed", value=100, usage_limit=1)
        make_sub(self.cust, self.plan, self.product)
        make_sub(self.cust2, self.plan, self.product)
        services.generate_invoices(as_of=date(2026, 1, 1))
        d.refresh_from_db()
        self.assertEqual(d.times_used, 1)
        self.assertEqual(Invoice.objects.filter(discount_total__gt=0).count(), 1)

    def test_expired_discount_ignored_and_min_quantity(self):
        Discount.objects.create(name="Old", kind="percent", value=50, end_date=date(2025, 12, 31))
        Discount.objects.create(name="Bulk", kind="percent", value=50, min_quantity=10)
        make_sub(self.cust, self.plan, self.product)
        services.generate_invoices(as_of=date(2026, 1, 1))
        self.assertEqual(Invoice.objects.get().discount_total, 0)

    def test_product_discount_only_hits_that_product(self):
        other = Product.objects.create(name="Add-on", sales_price=100)
        Discount.objects.create(name="CRM 50%", kind="percent", value=50, apply_to="product", product=self.product)
        sub = make_sub(self.cust, self.plan, self.product, qty=1)
        SubscriptionLine.objects.create(subscription=sub, product=other, quantity=1, unit_price=Decimal("100"))
        services.generate_invoices(as_of=date(2026, 1, 1))
        self.assertEqual(Invoice.objects.get().discount_total, Decimal("500"))

    def test_auto_close_after_expiry(self):
        sub = make_sub(self.cust, self.plan, self.product, expiry_date=date(2026, 1, 31))
        services.generate_invoices(as_of=date(2026, 3, 1))
        sub.refresh_from_db()
        self.assertEqual(sub.status, "closed")
        self.assertEqual(Invoice.objects.count(), 1)  # nothing billed after expiry


class LifecycleTests(Base):
    def test_valid_and_invalid_transitions(self):
        sub = make_sub(self.cust, self.plan, self.product, status="draft", quotation_valid_until=None)
        services.transition(sub, "quotation")
        services.transition(sub, "confirmed")
        services.transition(sub, "active")
        self.assertEqual(sub.next_invoice_date, sub.start_date)
        with self.assertRaises(Exception):
            services.transition(sub, "draft")


class ApiTests(APITestCase):
    def setUp(self):
        self.admin = User.objects.create_superuser("admin@t.io", "Admin@12345")
        self.staff = User.objects.create_user("staff@t.io", "Staff@12345", role="staff")
        self.c1 = User.objects.create_user("c1@t.io", "Cust@12345")
        self.c2 = User.objects.create_user("c2@t.io", "Cust@12345")
        self.product = Product.objects.create(name="CRM", sales_price=1000)
        self.plan = Plan.objects.create(name="Monthly", price=1000, billing_period="monthly")
        TaxRule.objects.create(name="GST", rate=Decimal("18"))

    def as_user(self, user):
        c = APIClient()
        c.force_authenticate(user)
        return c

    def test_register_validation_and_unique_email(self):
        c = APIClient()
        self.assertEqual(c.post("/api/auth/register/", {"email": "n@t.io", "password": "weak"}).status_code, 400)
        ok = c.post("/api/auth/register/", {"email": "n@t.io", "password": "Strong#Pass1"})
        self.assertEqual(ok.status_code, 201)
        dup = c.post("/api/auth/register/", {"email": "N@T.io", "password": "Strong#Pass1"})
        self.assertEqual(dup.status_code, 400)

    def test_login_with_email(self):
        r = APIClient().post("/api/auth/login/", {"email": "c1@t.io", "password": "Cust@12345"})
        self.assertEqual(r.status_code, 200)
        self.assertIn("access", r.data)

    def test_only_admin_creates_staff_and_discounts(self):
        body = {"email": "s2@t.io", "password": "Staff#Pass12"}
        self.assertEqual(self.as_user(self.staff).post("/api/auth/staff/", body).status_code, 403)
        self.assertEqual(self.as_user(self.c1).post("/api/auth/staff/", body).status_code, 403)
        self.assertEqual(self.as_user(self.admin).post("/api/auth/staff/", body).status_code, 201)
        d = {"name": "X", "kind": "percent", "value": "5", "apply_to": "subscription"}
        self.assertEqual(self.as_user(self.staff).post("/api/discounts/", d).status_code, 403)
        self.assertEqual(self.as_user(self.admin).post("/api/discounts/", d).status_code, 201)

    def test_customer_sees_only_own_data(self):
        make_sub(self.c1, self.plan, self.product)
        make_sub(self.c2, self.plan, self.product)
        services.generate_invoices(as_of=date(2026, 1, 1))
        c = self.as_user(self.c1)
        self.assertEqual(c.get("/api/subscriptions/").data["count"], 1)
        self.assertEqual(c.get("/api/invoices/").data["count"], 1)
        other = Invoice.objects.get(customer=self.c2)
        self.assertEqual(c.get(f"/api/invoices/{other.pk}/").status_code, 404)
        self.assertEqual(c.get("/api/dashboard/").status_code, 403)

    def test_payment_flow_partial_then_paid(self):
        make_sub(self.c1, self.plan, self.product, qty=1)
        services.generate_invoices(as_of=date(2026, 1, 1))
        inv = Invoice.objects.get()  # total 1180
        staff = self.as_user(self.staff)
        pay = {"invoice": inv.pk, "method": "upi", "amount": "500", "date": "2026-01-05", "note": "part"}
        self.assertEqual(staff.post("/api/payments/", pay).status_code, 400)  # still draft
        self.assertEqual(staff.post(f"/api/invoices/{inv.pk}/confirm/").status_code, 200)
        self.assertEqual(staff.post("/api/payments/", pay).status_code, 201)
        inv.refresh_from_db()
        self.assertEqual((inv.status, inv.outstanding), ("confirmed", Decimal("680")))
        self.assertEqual(staff.post("/api/payments/", {**pay, "amount": "9999"}).status_code, 400)
        self.assertEqual(staff.post("/api/payments/", {**pay, "amount": "680"}).status_code, 201)
        inv.refresh_from_db()
        self.assertEqual(inv.status, "paid")

    def test_create_subscription_with_variant_pricing_and_dashboard(self):
        from .models import ProductVariant
        v = ProductVariant.objects.create(product=self.product, attribute="Brand", value="Odoo", extra_price=560)
        r = self.as_user(self.staff).post("/api/subscriptions/", {
            "customer": self.c1.pk, "plan": self.plan.pk, "start_date": "2026-01-01",
            "lines": [{"product": self.product.pk, "variant": v.pk, "quantity": 3}]}, format="json")
        self.assertEqual(r.status_code, 201, r.data)
        self.assertEqual(r.data["lines"][0]["unit_price"], "1560.00")
        self.assertTrue(r.data["number"].startswith("SUB-"))
        self.assertEqual(r.data["status"], "draft")
        d = self.as_user(self.staff).get("/api/dashboard/")
        self.assertEqual(d.status_code, 200)
        self.assertIn("overdue_count", d.data)

    def test_password_reset_flow(self):
        from django.contrib.auth.tokens import default_token_generator
        from django.utils.encoding import force_bytes
        from django.utils.http import urlsafe_base64_encode
        c = APIClient()
        self.assertEqual(c.post("/api/auth/password-reset/", {"email": "c1@t.io"}).status_code, 200)
        self.assertEqual(c.post("/api/auth/password-reset/", {"email": "nobody@t.io"}).status_code, 200)
        uid = urlsafe_base64_encode(force_bytes(self.c1.pk))
        token = default_token_generator.make_token(self.c1)
        bad = c.post("/api/auth/password-reset/confirm/", {"uid": uid, "token": token, "password": "weak"})
        self.assertEqual(bad.status_code, 400)
        ok = c.post("/api/auth/password-reset/confirm/", {"uid": uid, "token": token, "password": "Brand#New123"})
        self.assertEqual(ok.status_code, 200)
