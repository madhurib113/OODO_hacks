"""Business logic: billing engine and subscription lifecycle. Views stay thin."""
import calendar
from datetime import date, timedelta
from decimal import ROUND_HALF_UP, Decimal

from django.db import IntegrityError, transaction
from django.db.models import F, Prefetch, Q
from django.utils import timezone
from rest_framework.exceptions import ValidationError

from .models import (Discount, Invoice, InvoiceLine, Plan, Subscription,
                     SubscriptionLine, TaxRule)

CENT = Decimal("0.01")
MAX_PERIODS_PER_RUN = 24  # safety valve for very old backlogs


def q2(x):
    return Decimal(x).quantize(CENT, rounding=ROUND_HALF_UP)


# ---------------------------------------------------------------- dates
def add_months(d, n):
    m = d.month - 1 + n
    y, m = d.year + m // 12, m % 12 + 1
    return date(y, m, min(d.day, calendar.monthrange(y, m)[1]))


def add_period(d, period):
    if period == Plan.Period.DAILY:
        return d + timedelta(days=1)
    if period == Plan.Period.WEEKLY:
        return d + timedelta(days=7)
    if period == Plan.Period.MONTHLY:
        return add_months(d, 1)
    return add_months(d, 12)


# ---------------------------------------------------------------- taxes
class TaxTable:
    """Loads active tax rules once. Product-specific rules override general ones."""

    def __init__(self):
        self._loaded = False

    def _load(self):
        self.general = Decimal("0")
        self.by_product = {}
        for r in TaxRule.objects.filter(is_active=True):
            if r.product_id:
                self.by_product[r.product_id] = self.by_product.get(r.product_id, Decimal("0")) + r.rate
            else:
                self.general += r.rate
        self._loaded = True

    def rate_for(self, product_id):
        if not self._loaded:
            self._load()
        return self.by_product.get(product_id, self.general)


# ---------------------------------------------------------------- billing engine
def _active_discounts(on_date):
    return list(
        Discount.objects.filter(is_active=True)
        .filter(Q(start_date__isnull=True) | Q(start_date__lte=on_date))
        .filter(Q(end_date__isnull=True) | Q(end_date__gte=on_date))
        .filter(Q(usage_limit__isnull=True) | Q(times_used__lt=F("usage_limit")))
        .order_by("id")
    )


def _claim_discount(discount):
    """Atomically take one use. Returns False if the limit was reached meanwhile."""
    return bool(
        Discount.objects.filter(pk=discount.pk)
        .filter(Q(usage_limit__isnull=True) | Q(times_used__lt=F("usage_limit")))
        .update(times_used=F("times_used") + 1)
    )


def _bill_period(sub, start, taxes, discounts, today):
    """Create one draft invoice for `sub` covering the period beginning on `start`."""
    end = add_period(start, sub.plan.billing_period) - timedelta(days=1)
    rows = [{"line": l, "base": q2(l.unit_price * l.quantity), "disc": Decimal("0")} for l in sub.lines.all()]

    for d in discounts:
        matched = [r for r in rows if d.apply_to == Discount.Scope.SUBSCRIPTION
                   or (d.product_id and r["line"].product_id == d.product_id)]
        if not matched:
            continue
        avail = [r["base"] - r["disc"] for r in matched]
        base, qty = sum(avail), sum(r["line"].quantity for r in matched)
        if base <= 0 or base < d.min_amount or qty < d.min_quantity:
            continue
        if not _claim_discount(d):
            continue
        amount = base * d.value / 100 if d.kind == Discount.Kind.PERCENT else d.value
        amount = min(q2(amount), base)
        remaining = amount
        for i, (r, a) in enumerate(zip(matched, avail)):
            share = remaining if i == len(matched) - 1 else q2(amount * a / base)
            share = min(share, a, remaining)
            r["disc"] += share
            remaining -= share

    subtotal = discount_total = tax_total = Decimal("0")
    inv_lines = []
    for r in rows:
        l = r["line"]
        net = r["base"] - r["disc"]
        rate = taxes.rate_for(l.product_id)
        tax = q2(net * rate / 100)
        label = l.product.name + (f" ({l.variant.attribute}: {l.variant.value})" if l.variant_id else "")
        inv_lines.append(InvoiceLine(description=label, quantity=l.quantity, unit_price=l.unit_price,
                                     discount=r["disc"], tax_rate=rate, tax_amount=tax, amount=net))
        subtotal += r["base"]
        discount_total += r["disc"]
        tax_total += tax

    inv = Invoice.objects.create(
        subscription=sub, customer_id=sub.customer_id, period_start=start, period_end=end,
        issue_date=today, due_date=today + timedelta(days=sub.payment_terms_days),
        subtotal=subtotal, discount_total=discount_total, tax_total=tax_total,
        total=subtotal - discount_total + tax_total,
    )
    for il in inv_lines:
        il.invoice = inv
    InvoiceLine.objects.bulk_create(inv_lines)
    return inv


def generate_invoices(as_of=None, customer_id=None, subscription_ids=None):
    """Bill every active, unpaused subscription whose next_invoice_date <= as_of.

    Idempotent: a DB unique constraint on (subscription, period_start) plus an
    existence check means re-running never double-bills; the cursor
    `next_invoice_date` moves forward in the same transaction so nothing is skipped.
    """
    today = timezone.localdate()
    as_of = as_of or today
    qs = (Subscription.objects.filter(status=Subscription.Status.ACTIVE, is_paused=False,
                                      next_invoice_date__isnull=False, next_invoice_date__lte=as_of)
          .select_related("plan")
          .prefetch_related(Prefetch("lines", queryset=SubscriptionLine.objects.select_related("product", "variant"))))
    if customer_id:
        qs = qs.filter(customer_id=customer_id)
    if subscription_ids:
        qs = qs.filter(pk__in=subscription_ids)

    taxes, discounts = TaxTable(), _active_discounts(as_of)
    result = {"created": 0, "skipped": 0, "invoice_ids": [], "closed": 0}

    for sub in qs.iterator(chunk_size=500):
        guard = 0
        while sub.next_invoice_date and sub.next_invoice_date <= as_of and guard < MAX_PERIODS_PER_RUN:
            guard += 1
            start = sub.next_invoice_date
            if sub.expiry_date and start > sub.expiry_date:
                break
            nxt = add_period(start, sub.plan.billing_period)
            try:
                with transaction.atomic():
                    if Invoice.objects.filter(subscription=sub, period_start=start).exists():
                        result["skipped"] += 1
                    else:
                        inv = _bill_period(sub, start, taxes, discounts, today)
                        result["created"] += 1
                        result["invoice_ids"].append(inv.pk)
                    Subscription.objects.filter(pk=sub.pk).update(next_invoice_date=nxt)
            except IntegrityError:  # lost a race with a parallel run: the other run billed it
                result["skipped"] += 1
                Subscription.objects.filter(pk=sub.pk).update(next_invoice_date=nxt)
            sub.next_invoice_date = nxt

    result["closed"] = close_expired(today)
    return result


def close_expired(today=None):
    today = today or timezone.localdate()
    return Subscription.objects.filter(
        status=Subscription.Status.ACTIVE, plan__auto_close=True, expiry_date__lt=today
    ).update(status=Subscription.Status.CLOSED)


# ---------------------------------------------------------------- subscription lifecycle
S = Subscription.Status
TRANSITIONS = {
    S.DRAFT: [S.QUOTATION],
    S.QUOTATION: [S.CONFIRMED, S.DRAFT],
    S.CONFIRMED: [S.ACTIVE, S.CLOSED],
    S.ACTIVE: [S.CLOSED],
    S.CLOSED: [],
}


def transition(sub, new_status):
    if new_status not in [s.value for s in TRANSITIONS[sub.status]]:
        raise ValidationError(f"Cannot move a subscription from {sub.status} to {new_status}.")
    today = timezone.localdate()
    if new_status in (S.CONFIRMED, S.QUOTATION) and not sub.lines.exists():
        raise ValidationError("Add at least one product line first.")
    if new_status == S.CONFIRMED and sub.quotation_valid_until and sub.quotation_valid_until < today:
        raise ValidationError("This quotation has expired.")
    if new_status == S.CLOSED and sub.status == S.ACTIVE and not sub.plan.closable:
        raise ValidationError("This plan cannot be closed early.")
    if new_status == S.ACTIVE and not sub.next_invoice_date:
        sub.next_invoice_date = sub.start_date
    sub.status = new_status
    sub.is_paused = False
    sub.save()
    return sub


def pause(sub):
    if sub.status != S.ACTIVE or not sub.plan.pausable:
        raise ValidationError("Only active subscriptions on pausable plans can be paused.")
    sub.is_paused = True
    sub.save(update_fields=["is_paused"])
    return sub


def resume(sub):
    if not sub.is_paused:
        raise ValidationError("Subscription is not paused.")
    sub.is_paused = False
    sub.save(update_fields=["is_paused"])
    return sub


def renew(sub):
    if not sub.plan.renewable:
        raise ValidationError("This plan cannot be renewed.")
    if sub.status not in (S.ACTIVE, S.CLOSED):
        raise ValidationError("Only active or closed subscriptions can be renewed.")
    today = timezone.localdate()
    period = sub.plan.billing_period
    if sub.status == S.CLOSED:
        sub.status = S.ACTIVE
        sub.next_invoice_date = today
        sub.expiry_date = add_period(today, period)
    else:
        sub.expiry_date = add_period(sub.expiry_date or today, period)
    sub.save()
    return sub
