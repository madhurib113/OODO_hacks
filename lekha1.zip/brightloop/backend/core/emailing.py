import json
import urllib.request

from django.conf import settings
from django.core.mail import send_mail


def send_email(subject, body, to):
    """Resend HTTP API when RESEND_API_KEY is set (free hosts often block SMTP); console otherwise."""
    if settings.RESEND_API_KEY:
        req = urllib.request.Request(
            "https://api.resend.com/emails",
            data=json.dumps({"from": settings.DEFAULT_FROM_EMAIL, "to": [to], "subject": subject, "text": body}).encode(),
            headers={"Authorization": f"Bearer {settings.RESEND_API_KEY}", "Content-Type": "application/json"},
            method="POST",
        )
        urllib.request.urlopen(req, timeout=10).read()
    else:
        send_mail(subject, body, settings.DEFAULT_FROM_EMAIL, [to])
