import re

from django.core.exceptions import ValidationError


class BrightloopPasswordValidator:
    """More than 8 characters, with an uppercase, a lowercase and a special character."""

    MIN_LENGTH = 9

    def validate(self, password, user=None):
        errors = []
        if len(password) < self.MIN_LENGTH:
            errors.append("Password must be more than 8 characters long.")
        if not re.search(r"[A-Z]", password):
            errors.append("Password must contain an uppercase letter.")
        if not re.search(r"[a-z]", password):
            errors.append("Password must contain a lowercase letter.")
        if not re.search(r"[^A-Za-z0-9]", password):
            errors.append("Password must contain a special character.")
        if errors:
            raise ValidationError(errors)

    def get_help_text(self):
        return "At least 9 characters with an uppercase letter, a lowercase letter and a special character."
