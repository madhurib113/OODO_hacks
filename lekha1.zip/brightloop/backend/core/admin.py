from django.contrib import admin

from . import models

for m in (models.User, models.Product, models.ProductVariant, models.Plan, models.QuotationTemplate,
          models.TaxRule, models.Discount, models.Subscription, models.Invoice, models.Payment):
    admin.site.register(m)
