import html
from datetime import date as date_cls, timedelta
from decimal import Decimal

from django.contrib.auth.tokens import default_token_generator
from django.conf import settings
from django.db.models import Count, DecimalField, ExpressionWrapper, F, Prefetch, Q, Sum
from django.db.models.functions import Coalesce, TruncMonth
from django.http import HttpResponse
from django.utils import timezone
from django.utils.encoding import force_bytes, force_str
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from django_filters import rest_framework as df
from rest_framework import mixins, status as http, viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import PermissionDenied, ValidationError
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken

from . import services
from .emailing import send_email
from .models import (Discount, Invoice, Payment, Plan, Product, ProductVariant, QuotationTemplate,
                     Subscription, SubscriptionLine, TaxRule, User)
from .permissions import (AdminWriteAuthRead, AdminWriteStaffRead, IsAdmin, IsStaffOrAdmin)
from .serializers import (DiscountSerializer, FromTemplateSerializer, InvoiceDetailSerializer,
                          InvoiceListSerializer, PasswordResetConfirmSerializer,
                          PasswordResetRequestSerializer, PaymentSerializer, PlanSerializer,
                          ProductSerializer, ProductVariantSerializer, QuotationTemplateSerializer,
                          RegisterSerializer, StaffCreateSerializer, SubscriptionSerializer,
                          TaxRuleSerializer, UserSerializer)


def is_customer(user):
    return user.role == User.Role.CUSTOMER


# ---------------------------------------------------------------- auth
class RegisterView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        s = RegisterSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        user = s.save()
        refresh = RefreshToken.for_user(user)
        return Response({"user": UserSerializer(user).data, "access": str(refresh.access_token),
                         "refresh": str(refresh)}, status=http.HTTP_201_CREATED)


class MeView(APIView):
    def get(self, request):
        return Response(UserSerializer(request.user).data)


class CreateStaffView(APIView):
    """Only the admin can add internal staff."""
    permission_classes = [IsAdmin]

    def post(self, request):
        s = StaffCreateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        return Response(UserSerializer(s.save()).data, status=http.HTTP_201_CREATED)


class PasswordResetRequestView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        s = PasswordResetRequestSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        user = User.objects.filter(email__iexact=s.validated_data["email"], is_active=True).first()
        if user:
            uid = urlsafe_base64_encode(force_bytes(user.pk))
            token = default_token_generator.make_token(user)
            link = f"{settings.FRONTEND_URL}/reset-password?uid={uid}&token={token}"
            try:
                send_email("Reset your Brightloop password",
                           f"Hi,\n\nUse this link to set a new password:\n{link}\n\nIf you did not ask for this, ignore this email.",
                           user.email)
            except Exception:  # never reveal delivery problems or whether the account exists
                pass
        return Response({"detail": "If that email is registered, a reset link is on its way."})


class PasswordResetConfirmView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        s = PasswordResetConfirmSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        try:
            user = User.objects.get(pk=force_str(urlsafe_base64_decode(s.validated_data["uid"])))
        except (User.DoesNotExist, ValueError, TypeError, OverflowError):
            raise ValidationError("Invalid or expired reset link.")
        if not default_token_generator.check_token(user, s.validated_data["token"]):
            raise ValidationError("Invalid or expired reset link.")
        user.set_password(s.validated_data["password"])
        user.save(update_fields=["password"])
        return Response({"detail": "Password updated. You can now sign in."})


class UserViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [IsStaffOrAdmin]
    serializer_class = UserSerializer
    queryset = User.objects.order_by("-id")
    filterset_fields = ["role"]
    search_fields = ["email", "first_name", "last_name", "company"]


# ---------------------------------------------------------------- catalog
class ProductViewSet(viewsets.ModelViewSet):
    permission_classes = [AdminWriteAuthRead]
    serializer_class = ProductSerializer
    queryset = Product.objects.prefetch_related("variants").order_by("-id")
    search_fields = ["name", "type"]
    filterset_fields = ["is_active", "type"]


class VariantViewSet(viewsets.ModelViewSet):
    permission_classes = [AdminWriteAuthRead]
    serializer_class = ProductVariantSerializer
    queryset = ProductVariant.objects.select_related("product").order_by("-id")
    filterset_fields = ["product"]


class PlanViewSet(viewsets.ModelViewSet):
    permission_classes = [AdminWriteAuthRead]
    serializer_class = PlanSerializer
    queryset = Plan.objects.order_by("-id")
    search_fields = ["name"]
    filterset_fields = ["billing_period"]


class TemplateViewSet(viewsets.ModelViewSet):
    permission_classes = [AdminWriteStaffRead]
    serializer_class = QuotationTemplateSerializer
    queryset = QuotationTemplate.objects.select_related("plan").prefetch_related("lines__product").order_by("-id")


class TaxRuleViewSet(viewsets.ModelViewSet):
    permission_classes = [AdminWriteStaffRead]
    serializer_class = TaxRuleSerializer
    queryset = TaxRule.objects.order_by("-id")


class DiscountViewSet(viewsets.ModelViewSet):
    permission_classes = [AdminWriteStaffRead]
    serializer_class = DiscountSerializer
    queryset = Discount.objects.order_by("-id")
    search_fields = ["name"]


# ---------------------------------------------------------------- subscriptions
class SubscriptionViewSet(viewsets.ModelViewSet):
    serializer_class = SubscriptionSerializer
    filterset_fields = ["status", "customer", "plan", "is_paused"]
    search_fields = ["number", "customer__email", "customer__company"]
    ordering_fields = ["id", "start_date", "expiry_date", "next_invoice_date"]

    def get_queryset(self):
        qs = (Subscription.objects.select_related("customer", "plan")
              .prefetch_related(Prefetch("lines", queryset=SubscriptionLine.objects.select_related("product", "variant")))
              .order_by("-id"))
        return qs.filter(customer=self.request.user) if is_customer(self.request.user) else qs

    def get_permissions(self):
        if self.action in ("create", "update", "partial_update", "destroy", "from_template"):
            return [IsStaffOrAdmin()]
        return [IsAuthenticated()]

    def perform_destroy(self, inst):
        if inst.status != Subscription.Status.DRAFT:
            raise ValidationError("Only draft subscriptions can be deleted. Close it instead.")
        inst.delete()

    def _respond(self, sub):
        return Response(self.get_serializer(self.get_queryset().get(pk=sub.pk)).data)

    @action(detail=False, methods=["post"], url_path="from-template")
    def from_template(self, request):
        s = FromTemplateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        sub = s.save()
        return Response(self.get_serializer(self.get_queryset().get(pk=sub.pk)).data, status=http.HTTP_201_CREATED)

    @action(detail=True, methods=["post"])
    def transition(self, request, pk=None):
        sub, target = self.get_object(), request.data.get("status")
        if is_customer(request.user) and target != Subscription.Status.CLOSED:
            raise PermissionDenied("Customers can only close their own subscriptions.")
        return self._respond(services.transition(sub, target))

    @action(detail=True, methods=["post"])
    def pause(self, request, pk=None):
        return self._respond(services.pause(self.get_object()))

    @action(detail=True, methods=["post"])
    def resume(self, request, pk=None):
        return self._respond(services.resume(self.get_object()))

    @action(detail=True, methods=["post"])
    def renew(self, request, pk=None):
        return self._respond(services.renew(self.get_object()))


# ---------------------------------------------------------------- invoices
class InvoiceFilter(df.FilterSet):
    overdue = df.BooleanFilter(method="f_overdue")
    outstanding = df.BooleanFilter(method="f_outstanding")
    due_from = df.DateFilter(field_name="due_date", lookup_expr="gte")
    due_to = df.DateFilter(field_name="due_date", lookup_expr="lte")
    issued_from = df.DateFilter(field_name="issue_date", lookup_expr="gte")
    issued_to = df.DateFilter(field_name="issue_date", lookup_expr="lte")

    class Meta:
        model = Invoice
        fields = ["status", "customer", "subscription"]

    def f_overdue(self, qs, name, value):
        if not value:
            return qs
        return qs.filter(status=Invoice.Status.CONFIRMED, due_date__lt=timezone.localdate(), amount_paid__lt=F("total"))

    def f_outstanding(self, qs, name, value):
        return qs.filter(status=Invoice.Status.CONFIRMED) if value else qs


def invoice_html(inv):
    e = html.escape
    rows = "".join(
        f"<tr><td>{e(l.description)}</td><td>{l.quantity}</td><td>{l.unit_price}</td><td>{l.discount}</td>"
        f"<td>{l.tax_rate}%</td><td>{l.amount + l.tax_amount}</td></tr>" for l in inv.lines.all())
    return f"""<!doctype html><html><head><meta charset="utf-8"><title>{e(inv.number)}</title>
<style>body{{font-family:Arial,sans-serif;max-width:760px;margin:30px auto;color:#222}}table{{width:100%;border-collapse:collapse}}
th,td{{border-bottom:1px solid #ddd;padding:8px;text-align:left}}.r{{text-align:right}}h1{{margin:0}}</style></head><body>
<h1>Brightloop Software</h1><p>Invoice <b>{e(inv.number)}</b> &middot; {e(inv.get_status_display())}</p>
<p>Billed to: {e(inv.customer.company or inv.customer.email)} ({e(inv.customer.email)})<br>
Subscription {e(inv.subscription.number)} &middot; Period {inv.period_start} to {inv.period_end}<br>
Issued {inv.issue_date} &middot; Due {inv.due_date}</p>
<table><tr><th>Item</th><th>Qty</th><th>Unit</th><th>Discount</th><th>Tax</th><th>Amount</th></tr>{rows}</table>
<p class="r">Subtotal {inv.subtotal}<br>Discount -{inv.discount_total}<br>Tax {inv.tax_total}<br>
<b>Total {inv.total}</b><br>Paid {inv.amount_paid}<br><b>Balance {inv.outstanding}</b></p></body></html>"""


class InvoiceViewSet(mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet):
    filterset_class = InvoiceFilter
    search_fields = ["number", "customer__email", "customer__company", "subscription__number"]
    ordering_fields = ["id", "issue_date", "due_date", "total"]

    def get_queryset(self):
        qs = Invoice.objects.select_related("customer", "subscription").order_by("-id")
        if self.action in ("retrieve", "print_view"):
            qs = qs.prefetch_related("lines")
        return qs.filter(customer=self.request.user) if is_customer(self.request.user) else qs

    def get_serializer_class(self):
        return InvoiceDetailSerializer if self.action == "retrieve" else InvoiceListSerializer

    def get_permissions(self):
        if self.action in ("confirm", "cancel", "send", "generate"):
            return [IsStaffOrAdmin()]
        return [IsAuthenticated()]

    @action(detail=False, methods=["post"])
    def generate(self, request):
        as_of = request.data.get("as_of")
        try:
            as_of = date_cls.fromisoformat(as_of) if as_of else None
        except ValueError:
            raise ValidationError({"as_of": "Use YYYY-MM-DD."})
        return Response(services.generate_invoices(as_of=as_of, customer_id=request.data.get("customer")))

    @action(detail=True, methods=["post"])
    def confirm(self, request, pk=None):
        inv = self.get_object()
        if inv.status != Invoice.Status.DRAFT:
            raise ValidationError("Only draft invoices can be confirmed.")
        inv.status = Invoice.Status.CONFIRMED
        inv.save(update_fields=["status"])
        return Response(InvoiceListSerializer(inv).data)

    @action(detail=True, methods=["post"])
    def cancel(self, request, pk=None):
        inv = self.get_object()
        if inv.status not in (Invoice.Status.DRAFT, Invoice.Status.CONFIRMED) or inv.amount_paid > 0:
            raise ValidationError("Only unpaid draft or confirmed invoices can be cancelled.")
        inv.status = Invoice.Status.CANCELLED
        inv.save(update_fields=["status"])
        return Response(InvoiceListSerializer(inv).data)

    @action(detail=True, methods=["post"])
    def send(self, request, pk=None):
        inv = self.get_object()
        if inv.status not in (Invoice.Status.CONFIRMED, Invoice.Status.PAID):
            raise ValidationError("Confirm the invoice before sending it.")
        try:
            send_email(f"Invoice {inv.number} from Brightloop",
                       f"Hello,\n\nInvoice {inv.number} for {inv.total} is due on {inv.due_date}.\nOutstanding: {inv.outstanding}.\n\nThank you,\nBrightloop Software",
                       inv.customer.email)
        except Exception:
            raise ValidationError("Email provider rejected the message. Check RESEND_API_KEY / sender settings.")
        inv.sent_at = timezone.now()
        inv.save(update_fields=["sent_at"])
        return Response(InvoiceListSerializer(inv).data)

    @action(detail=True, methods=["get"], url_path="print")
    def print_view(self, request, pk=None):
        return HttpResponse(invoice_html(self.get_object()))


# ---------------------------------------------------------------- payments
class PaymentFilter(df.FilterSet):
    date_from = df.DateFilter(field_name="date", lookup_expr="gte")
    date_to = df.DateFilter(field_name="date", lookup_expr="lte")

    class Meta:
        model = Payment
        fields = ["invoice", "method"]


class PaymentViewSet(mixins.ListModelMixin, mixins.RetrieveModelMixin, mixins.CreateModelMixin, viewsets.GenericViewSet):
    serializer_class = PaymentSerializer
    filterset_class = PaymentFilter
    search_fields = ["invoice__number", "invoice__customer__email", "note"]
    ordering_fields = ["id", "date", "amount"]

    def get_queryset(self):
        qs = Payment.objects.select_related("invoice", "invoice__customer").order_by("-date", "-id")
        return qs.filter(invoice__customer=self.request.user) if is_customer(self.request.user) else qs

    def get_permissions(self):
        return [IsStaffOrAdmin()] if self.action == "create" else [IsAuthenticated()]


# ---------------------------------------------------------------- finance dashboard
class DashboardView(APIView):
    permission_classes = [IsStaffOrAdmin]

    def get(self, request):
        today = timezone.localdate()
        p = request.query_params
        date_to = p.get("date_to") or today.isoformat()
        date_from = p.get("date_from") or (today - timedelta(days=365)).isoformat()
        customer = p.get("customer")
        sub_f = Q(customer_id=customer) if customer else Q()
        inv_f = Q(customer_id=customer) if customer else Q()
        pay_f = Q(invoice__customer_id=customer) if customer else Q()

        subs = Subscription.objects.filter(sub_f)
        by_status = {r["status"]: r["n"] for r in subs.values("status").annotate(n=Count("id"))}

        # Monthly recurring revenue, normalised across billing periods.
        line_total = ExpressionWrapper(F("quantity") * F("unit_price"), output_field=DecimalField(max_digits=16, decimal_places=2))
        per_period = (SubscriptionLine.objects.filter(subscription__status="active", subscription__is_paused=False)
                      .filter(Q(subscription__customer_id=customer) if customer else Q())
                      .values("subscription__plan__billing_period").annotate(t=Sum(line_total)))
        factor = {"daily": Decimal("30"), "weekly": Decimal("52") / 12, "monthly": Decimal("1"), "yearly": Decimal("1") / 12}
        mrr = sum((r["t"] or 0) * factor[r["subscription__plan__billing_period"]] for r in per_period)

        payments = Payment.objects.filter(pay_f, date__gte=date_from, date__lte=date_to)
        revenue = payments.aggregate(t=Coalesce(Sum("amount"), Decimal("0")))["t"]
        monthly = (payments.annotate(m=TruncMonth("date")).values("m").annotate(total=Sum("amount")).order_by("m"))
        by_method = payments.values("method").annotate(total=Sum("amount")).order_by("-total")

        open_inv = Invoice.objects.filter(inv_f, status=Invoice.Status.CONFIRMED)
        outstanding = open_inv.aggregate(t=Coalesce(Sum(F("total") - F("amount_paid")), Decimal("0")))["t"]
        overdue_qs = open_inv.filter(due_date__lt=today)
        overdue = overdue_qs.aggregate(n=Count("id"), t=Coalesce(Sum(F("total") - F("amount_paid")), Decimal("0")))
        invoiced = (Invoice.objects.filter(inv_f, issue_date__gte=date_from, issue_date__lte=date_to)
                    .exclude(status=Invoice.Status.CANCELLED).aggregate(t=Coalesce(Sum("total"), Decimal("0")))["t"])
        overdue_list = InvoiceListSerializer(overdue_qs.select_related("customer", "subscription").order_by("due_date")[:10], many=True).data

        return Response({
            "filters": {"date_from": date_from, "date_to": date_to, "customer": customer},
            "active_subscriptions": by_status.get("active", 0),
            "subscriptions_by_status": by_status,
            "mrr": round(mrr, 2),
            "revenue": revenue,
            "invoiced": invoiced,
            "outstanding": outstanding,
            "overdue_count": overdue["n"],
            "overdue_amount": overdue["t"],
            "revenue_by_month": [{"month": r["m"].strftime("%b %Y"), "total": r["total"]} for r in monthly],
            "revenue_by_method": list(by_method),
            "overdue_invoices": overdue_list,
        })
