from rest_framework.permissions import SAFE_METHODS, BasePermission

ADMIN, STAFF, CUSTOMER = "admin", "staff", "customer"


def _role(request):
    u = request.user
    return getattr(u, "role", None) if u and u.is_authenticated else None


class IsAdmin(BasePermission):
    def has_permission(self, request, view):
        return _role(request) == ADMIN


class IsStaffOrAdmin(BasePermission):
    def has_permission(self, request, view):
        return _role(request) in (ADMIN, STAFF)


class AdminWriteStaffRead(BasePermission):
    """Admin: everything. Staff: read only. Customers: nothing (tax rules, discounts)."""

    def has_permission(self, request, view):
        role = _role(request)
        if request.method in SAFE_METHODS:
            return role in (ADMIN, STAFF)
        return role == ADMIN


class AdminWriteAuthRead(BasePermission):
    """Admin: everything. Any logged-in user: read (catalog, plans)."""

    def has_permission(self, request, view):
        role = _role(request)
        if request.method in SAFE_METHODS:
            return role is not None
        return role == ADMIN
