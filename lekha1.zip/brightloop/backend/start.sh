#!/bin/sh
set -e
python manage.py makemigrations core --noinput  # no-op once migrations are committed
python manage.py migrate --noinput
if [ "$SEED_DEMO" = "1" ]; then
  python manage.py seed_demo --count "${SEED_COUNT:-5000}" --bill
fi
exec gunicorn config.wsgi:application --bind 0.0.0.0:${PORT:-8000} --workers 3 --timeout 60
