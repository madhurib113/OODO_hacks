# Brightloop Subscription Management System: R&D Document

## 1. Problem analysis
Brightloop runs on spreadsheets: renewals are missed, invoices are typed by hand, payments are matched by scrolling bank
statements, and nobody knows recurring revenue. The platform must cover one billing month end to end: sign-up, catalog,
quotation, subscription, billing day, discounts, payments, finance reporting.

### Functional requirements
1. Accounts: unique email, password rule (more than 8 chars, upper, lower, special), reset by email link.
2. Roles: Admin (everything, only one who adds staff), Staff (limited), Customer (own subscriptions and invoices only).
3. Catalog: product (name, type, sales price, cost price, notes), variants with extra price, plans (price, period, min quantity, dates, close/pause/renew flags).
4. Quotation templates with validity days.
5. Subscriptions: number, customer, plan, dates, payment terms, lines; Draft → Quotation → Confirmed → Active → Closed.
6. Billing: bulk invoice creation from subscriptions, automatic tax rules, Draft → Confirmed → Paid, cancel/send/print, never twice, never skipped.
7. Discounts: fixed or percent, minimums, dates, usage limit, per product or per subscription, applied automatically.
8. Payments: method, amount, date, note against an invoice; paid / outstanding / overdue views.
9. Finance dashboard: active subscriptions, revenue, outstanding, overdue, with filters.

### Non-functional requirements
| Area | Target | How |
|---|---|---|
| Performance | every page < 2 s with thousands of rows | pagination, indexes, select_related, aggregate SQL; seeded with 5,000 subscriptions |
| Security | hashed passwords, RBAC on every endpoint, validation | Django PBKDF2, DRF permission classes, serializer validation, JWT |
| Reliability | billing is idempotent | DB unique constraint + transactional cursor + row-locked payments |
| Usability | easy, responsive, dark mode, clear states | daisyUI, empty/error/loading states, toasts, demo logins |
| Maintainability | tests, docs | billing/permission/payment tests, README, Swagger |
| Portability | runs on its own | docker compose |

## 2. Options considered
| Layer | Options | Decision | Why |
|---|---|---|---|
| Backend | Django+DRF, FastAPI, Node/Express | **Django + DRF** | built-in auth, validators, token generator, ORM, migrations; fastest to a correct billing core solo |
| Auth | sessions, JWT (SimpleJWT) | **JWT** | clean SPA integration, role claims via `/auth/me` |
| DB | SQLite, Neon Postgres, Supabase | **SQLite dev, Neon prod** | free, Postgres semantics for constraints and locking |
| Frontend | React+Vite, Next.js, Vue | **React + Vite** | quick SPA, large ecosystem |
| UI kit | daisyUI, shadcn, MUI | **Tailwind + daisyUI** | polished themed components with dark mode in minutes |
| Data fetching | TanStack Query, SWR, plain axios | **TanStack Query** | caching, pagination placeholders, invalidation after billing |
| Charts | Recharts, Chart.js | **Recharts** | declarative React charts |
| Email | SMTP, Resend, Brevo | **Resend HTTP API** | free hosts block SMTP; console fallback locally |
| Hosting | Render, Railway, Fly | **Render (API) + Vercel (UI)** | free tiers (Render sleeps when idle) |
| AI | in-product AI vs none | **none in product** | correctness beats gimmicks in billing; AI used as a coding assistant only |

Free-tier limits change; verify before relying on them. This comparison is from general knowledge, not live lookups.

## 3. Key design decisions
* **Idempotent billing.** `UniqueConstraint(subscription, period_start)`; each period is billed inside `transaction.atomic()` that also advances `next_invoice_date`. A crash rolls both back; a re-run skips existing periods; a race hits `IntegrityError` and is treated as already billed.
* **Backlog catch-up.** If the job did not run for two months, the loop bills period by period (max 24 per run) so none are skipped.
* **Discount usage limits.** `UPDATE ... WHERE times_used < usage_limit` claims one use atomically, so concurrent runs cannot over-spend a limit. The claim rolls back with the invoice if creation fails.
* **Tax.** Rules are loaded once per run. Product-specific rules override general rules; rules at the same level add (e.g. CGST + SGST).
* **Payments.** `select_for_update` on the invoice; overpayment rejected; status becomes Paid when balance reaches zero.
* **Roles.** Permission classes per viewset; customers get filtered querysets so another customer's ID returns 404.
* **Performance.** List serializers avoid N+1 (prefetched lines, cached tax table), dashboard uses aggregates, composite indexes on (status, next_invoice_date), (status, due_date), (customer, status).

## 4. Data model
User(role) · Product · ProductVariant · Plan · QuotationTemplate(+Line) · TaxRule · Discount ·
Subscription(number, status) · SubscriptionLine · Invoice(unique subscription+period_start) · InvoiceLine · Payment

## 5. Risks and mitigations
| Risk | Mitigation |
|---|---|
| Render cold start during demo | open the API URL 3 minutes before recording |
| Email provider restrictions | console backend locally; show the reset link in the log on video |
| Scope creep in 6 h | cut order: charts polish, template UI, pause/renew. Never cut: idempotent billing, role access, dashboard, payment recording |

## 6. Six-hour plan (IST)
| Time | Block | Output |
|---|---|---|
| 08:45–09:15 | Setup | repo, projects, accounts |
| 09:15–11:15 | Backend | auth, catalog, subscriptions, billing, payments, dashboard |
| 11:15–13:15 | Frontend | login, catalog, subscription flow, invoices, payments, dashboard |
| 13:15–13:45 | Seed, test, performance | 5,000 subscriptions, tests, timings |
| 13:45–14:15 | Deploy and Docker | Vercel + Render + `docker compose up` |
| 14:15–14:45 | README, video, submit | repo public, video uploaded |
