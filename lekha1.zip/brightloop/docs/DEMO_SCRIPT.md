# Demo video script (about 4 minutes)

1. **Hook (15 s)** "Brightloop bills on spreadsheets. This replaces them." Show the login page, click the Admin demo button.
2. **Sign-up and rules (20 s)** Register with a weak password to show the rule message, then a strong one. Mention unique email and the reset link.
3. **Launch a plan (30 s)** Catalog: open the ERP Connector, show the Odoo variant (+560). Plans tab: show pausable, renewable, auto-close flags.
4. **Quote to subscription (35 s)** Subscriptions > From template, pick customer. Move Quotation → Confirmed → Active.
5. **Billing day (45 s)** Invoices > Run billing. Point at "created / already billed". **Click Run billing again: 0 created.** Say "database constraint, never billed twice". Open an invoice: tax and discount already applied.
6. **Discounts (20 s)** Pricing rules: show the 10% volume rule and the usage-limited welcome discount; open an invoice that used it.
7. **Money in (30 s)** Confirm an invoice, Pay: record a partial UPI payment, then the remainder, status flips to Paid. Show Outstanding and Overdue tabs.
8. **Finance lead (30 s)** Dashboard: active subscriptions, MRR, revenue, outstanding, overdue, filters. Change the date range.
9. **Roles (25 s)** Log in as customer: only own data. Log in as staff: discount and staff creation are blocked (view-only banner).
10. **Performance and quality (20 s)** Open the browser Network tab on the 5,000-subscription list: show the response time. Show Swagger and the passing test run.
11. **Close (10 s)** "Runs with one command: docker compose up."
