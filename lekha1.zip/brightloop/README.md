# Brightloop Subscription Management System

One platform for the whole subscription lifecycle: products and plans, quotations, subscriptions,
automatic recurring billing, discounts, taxes, payments and a finance dashboard.

**Stack:** Django 5 + Django REST Framework + JWT · React (Vite) + Tailwind + daisyUI + TanStack Query + Recharts ·
SQLite locally, PostgreSQL (Neon) in production · Swagger docs · Docker Compose.

## Run it (pick one)

### A. Docker, one command
```bash
docker compose up --build
```
App http://localhost:5173 · API docs http://localhost:8000/api/docs/ · it seeds 5,000 subscriptions on first start.

### B. Local dev
```bash
# backend
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
python manage.py makemigrations core && python manage.py migrate
python manage.py seed_demo --count 5000 --bill          # demo data + billing run + payments
python manage.py runserver

# frontend (second terminal)
cd frontend
cp .env.example .env
npm install && npm run dev                              # http://localhost:5173
```
Tests: `cd backend && python manage.py test`

**Demo logins:** `admin@brightloop.test / Admin@12345` · `staff@brightloop.test / Staff@12345` · `customer@brightloop.test / Customer@123`

## How each requirement is met

| Requirement | Where |
|---|---|
| Unique email, password >8 chars with upper, lower, special | `core/validators.py`, case-insensitive email check in `RegisterSerializer`, unique DB column |
| Password reset link by email | `/api/auth/password-reset/` + `/confirm/` (Django token generator); Resend HTTP API or console |
| Admin / Staff / Customer; only admin adds staff | `core/permissions.py`; `POST /api/auth/staff/` is admin-only; customer querysets are filtered to their own rows |
| Products, variants (Odoo +560), plans, flags | `Product`, `ProductVariant.extra_price`, `Plan(auto_close, closable, pausable, renewable)` |
| Quotation templates with validity | `QuotationTemplate` + `POST /api/subscriptions/from-template/` |
| Subscription numbers and status flow | `SUB-000001`; `services.transition()` enforces Draft → Quotation → Confirmed → Active → Closed |
| Bulk invoice generation, automatic tax | `services.generate_invoices()`, `TaxRule` (product rules override general; same-level rules add up) |
| Never billed twice or skipped | DB `UniqueConstraint(subscription, period_start)` + existence check + cursor `next_invoice_date` advanced in the same transaction; backlog is caught up period by period |
| Invoice confirm / cancel / send / print, Draft → Confirmed → Paid | `/api/invoices/{id}/confirm|cancel|send|print/` |
| Discounts (fixed / %, minimums, dates, usage limit, product or subscription) | `Discount`; applied automatically at billing; usage claimed atomically so the limit cannot be exceeded |
| Payments with method, amount, date, note | `POST /api/payments/` (row-locked, cannot overpay); invoice flips to Paid when settled |
| Paid vs outstanding vs overdue | invoice filters `?status=paid`, `?outstanding=true`, `?overdue=true` |
| Finance dashboard with filters | `GET /api/dashboard/?date_from=&date_to=&customer=` |
| Every page under 2 s with thousands of rows | server-side pagination (25/page), `select_related`/`prefetch_related`, composite indexes, aggregate queries |
| API contract | Swagger at `/api/docs/` |

## Deploy on free tiers
1. **Neon**: create a project, copy the connection string into `DATABASE_URL`.
2. **Render** (web service, root `backend`): build `pip install -r requirements.txt && python manage.py collectstatic --noinput`,
   start `./start.sh`. Env: `SECRET_KEY`, `DEBUG=0`, `DATABASE_URL`, `ALLOWED_HOSTS=*`, `CORS_ALLOWED_ORIGINS=https://<your-vercel-app>`,
   `CSRF_TRUSTED_ORIGINS=https://<your-render-app>`, `FRONTEND_URL=https://<your-vercel-app>`,
   `SEED_DEMO=1`, `SEED_COUNT=5000` (seeds once; remove afterwards). Render's free tier sleeps: open it a few minutes before the demo.
3. **Vercel** (root `frontend`, framework Vite): env `VITE_API_URL=https://<your-render-app>/api`. Add a `vercel.json` rewrite if deep links 404:
   `{"rewrites":[{"source":"/(.*)","destination":"/"}]}`.
4. **Email**: create a Resend key, set `RESEND_API_KEY`. Resend's shared sender only delivers to your own address until you verify a domain,
   so for the demo use your own email as the customer or show the console log locally.

## Design notes and assumptions
* Money is `Decimal` everywhere, rounded half-up to 2 places per line.
* A cancelled invoice keeps its period slot (nothing is silently re-billed). Re-issue by creating a manual correction.
* Discounts reduce the taxable amount; tax is computed on the net.
* Customers can pause, resume, renew and close their own subscriptions where the plan allows it.
* The invoice number is assigned right after insert (`INV-000123`).
