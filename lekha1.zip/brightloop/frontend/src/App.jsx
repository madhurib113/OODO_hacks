import { useEffect, useState } from "react";
import { Link, NavLink, Navigate, Outlet, Route, Routes, useNavigate } from "react-router-dom";
import { Banknote, LayoutDashboard, LogOut, Menu, Moon, Package, Receipt, Repeat, Sun, Tag, Users } from "lucide-react";
import { useAuth } from "./auth";
import { Spinner, Toaster } from "./components/ui";
import { Forgot, Login, Register, ResetPassword } from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import Subscriptions from "./pages/Subscriptions";
import Invoices from "./pages/Invoices";
import Payments from "./pages/Payments";
import Team from "./pages/Team";
import { Discounts, Plans, Products, Taxes, Templates, Variants } from "./pages/Catalog";

function Layout() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const [theme, setTheme] = useState(localStorage.getItem("theme") || "light");
  useEffect(() => { document.documentElement.setAttribute("data-theme", theme); localStorage.setItem("theme", theme); }, [theme]);
  const staff = user.role !== "customer";
  const admin = user.role === "admin";
  const links = [
    staff && ["/", "Dashboard", LayoutDashboard],
    [staff ? "/subscriptions" : "/", staff ? "Subscriptions" : "My subscriptions", Repeat],
    ["/invoices", staff ? "Invoices" : "My invoices", Receipt],
    ["/payments", "Payments", Banknote],
    staff && ["/products", "Catalog", Package],
    staff && ["/discounts", "Pricing rules", Tag],
    staff && ["/users", admin ? "Users & staff" : "Users", Users],
  ].filter(Boolean);

  const Menu_ = ({ cls = "" }) => (
    <ul className={`menu gap-1 ${cls}`}>
      {links.map(([to, label, Icon]) => (
        <li key={label}><NavLink to={to} end={to === "/"} className={({ isActive }) => (isActive ? "menu-active" : "")}><Icon size={16} /> {label}</NavLink></li>))}
    </ul>
  );
  return (
    <div className="min-h-screen bg-base-200">
      <div className="navbar bg-base-100 shadow-sm sticky top-0 z-40">
        <div className="navbar-start">
          <div className="dropdown lg:hidden">
            <button tabIndex={0} className="btn btn-ghost btn-square" aria-label="Menu"><Menu /></button>
            <div tabIndex={0} className="dropdown-content bg-base-100 rounded-box shadow z-50 w-60 p-2 mt-3"><Menu_ /></div>
          </div>
          <Link to="/" className="btn btn-ghost text-xl text-primary"><Repeat size={20} /> Brightloop</Link>
        </div>
        <div className="navbar-center hidden lg:flex"><Menu_ cls="menu-horizontal" /></div>
        <div className="navbar-end gap-1">
          <span className="hidden md:block text-xs text-right mr-2"><b>{user.first_name || user.email}</b><br /><span className="capitalize text-base-content/60">{user.role}</span></span>
          <button className="btn btn-ghost btn-circle" aria-label="Toggle dark mode" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>{theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}</button>
          <button className="btn btn-ghost btn-circle" aria-label="Sign out" onClick={() => { logout(); nav("/login"); }}><LogOut size={18} /></button>
        </div>
      </div>
      <main className="max-w-7xl mx-auto p-4 md:p-6"><Outlet /></main>
    </div>
  );
}

function CatalogTabs() {
  const [tab, setTab] = useState("products");
  const { user } = useAuth();
  const tabs = { products: Products, variants: Variants, plans: Plans, templates: Templates };
  const T = tabs[tab];
  return (<>
    <div role="tablist" className="tabs tabs-box mb-4 w-fit">{Object.keys(tabs).map((k) => <button key={k} role="tab" className={`tab capitalize ${tab === k ? "tab-active" : ""}`} onClick={() => setTab(k)}>{k}</button>)}</div>
    {user.role !== "admin" && <div className="alert alert-info text-sm mb-4">View only. Only the admin can change the catalog.</div>}
    <T />
  </>);
}
function PricingTabs() {
  const [tab, setTab] = useState("discounts");
  const { user } = useAuth();
  const T = tab === "discounts" ? Discounts : Taxes;
  return (<>
    <div role="tablist" className="tabs tabs-box mb-4 w-fit">{["discounts", "taxes"].map((k) => <button key={k} role="tab" className={`tab capitalize ${tab === k ? "tab-active" : ""}`} onClick={() => setTab(k)}>{k}</button>)}</div>
    {user.role !== "admin" && <div className="alert alert-info text-sm mb-4">View only. Only the admin can create discount and tax rules.</div>}
    <T />
  </>);
}

function Protected({ roles }) {
  const { user, loading } = useAuth();
  if (loading) return <Spinner />;
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/" replace />;
  return <Layout />;
}
const Home = () => { const { user } = useAuth(); return user.role === "customer" ? <Subscriptions /> : <Dashboard />; };

export default function App() {
  return (
    <>
      <Toaster />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot" element={<Forgot />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route element={<Protected />}>
          <Route path="/" element={<Home />} />
          <Route path="/invoices" element={<Invoices />} />
          <Route path="/payments" element={<Payments />} />
        </Route>
        <Route element={<Protected roles={["admin", "staff"]} />}>
          <Route path="/subscriptions" element={<Subscriptions />} />
          <Route path="/products" element={<CatalogTabs />} />
          <Route path="/discounts" element={<PricingTabs />} />
          <Route path="/users" element={<Team />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  );
}
