import axios from "axios";

export const API = import.meta.env.VITE_API_URL || "http://localhost:8000/api";
export const api = axios.create({ baseURL: API });

api.interceptors.request.use((c) => {
  const t = localStorage.getItem("access");
  if (t) c.headers.Authorization = `Bearer ${t}`;
  return c;
});

let refreshing = null;
api.interceptors.response.use(
  (r) => r,
  async (err) => {
    const orig = err.config;
    const refresh = localStorage.getItem("refresh");
    if (err.response?.status === 401 && refresh && !orig._retry && !orig.url.includes("/auth/")) {
      orig._retry = true;
      try {
        refreshing = refreshing || axios.post(`${API}/auth/refresh/`, { refresh });
        const { data } = await refreshing;
        refreshing = null;
        localStorage.setItem("access", data.access);
        orig.headers.Authorization = `Bearer ${data.access}`;
        return api(orig);
      } catch {
        refreshing = null;
        ["access","refresh"].forEach((k) => localStorage.removeItem(k));
        window.location.href = "/login";
      }
    }
    throw err;
  }
);

// Flatten Django REST Framework error payloads into one readable sentence.
export function errMsg(e) {
  const d = e?.response?.data;
  if (!d) return e?.message || "Something went wrong";
  if (typeof d === "string") return d.length > 200 ? "Server error" : d;
  const parts = [];
  const walk = (v, k) => {
    if (Array.isArray(v)) v.forEach((x) => walk(x, k));
    else if (v && typeof v === "object") Object.entries(v).forEach(([kk, vv]) => walk(vv, kk));
    else parts.push(k && k !== "detail" && k !== "non_field_errors" ? `${k}: ${v}` : String(v));
  };
  walk(d);
  return parts.join(" · ") || "Something went wrong";
}

export const rows = (data) => (Array.isArray(data) ? data : data?.results || []);
export const money = (v) =>
  new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 2 }).format(Number(v || 0));
export const today = () => new Date().toISOString().slice(0, 10);
