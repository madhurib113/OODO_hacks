import { createContext, useContext, useEffect, useState } from "react";
import { api } from "./api";

const Ctx = createContext(null);
export const useAuth = () => useContext(Ctx);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(!!localStorage.getItem("access"));

  useEffect(() => {
    if (!localStorage.getItem("access")) return;
    api.get("/auth/me/").then((r) => setUser(r.data)).catch(() => localStorage.clear()).finally(() => setLoading(false));
  }, []);

  const store = (d) => {
    localStorage.setItem("access", d.access);
    localStorage.setItem("refresh", d.refresh);
  };
  const login = async (email, password) => {
    const { data } = await api.post("/auth/login/", { email, password });
    store(data);
    setUser((await api.get("/auth/me/")).data);
  };
  const register = async (payload) => {
    const { data } = await api.post("/auth/register/", payload);
    store(data);
    setUser(data.user);
  };
  const logout = () => {
    ["access","refresh"].forEach((k) => localStorage.removeItem(k));
    setUser(null);
  };
  return <Ctx.Provider value={{ user, loading, login, register, logout }}>{children}</Ctx.Provider>;
}
