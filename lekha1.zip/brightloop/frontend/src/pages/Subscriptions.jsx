import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { FilePlus2, Plus, Search, Trash2 } from "lucide-react";
import { api, errMsg, money, rows, today } from "../api";
import { useAuth } from "../auth";
import { Badge, Empty, ErrorBox, Field, Modal, PageHeader, Pager, Spinner, toast, useOptions } from "../components/ui";

const NEXT = { draft: ["quotation", "Make quotation"], quotation: ["confirmed", "Confirm"], confirmed: ["active", "Activate"] };

export default function Subscriptions() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const isStaff = user.role !== "customer";
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");
  const [modal, setModal] = useState(null); // "new" | "template" | subscription (details)

  const list = useQuery({
    queryKey: ["subscriptions", page, search, status],
    queryFn: async () => (await api.get("/subscriptions/", { params: { page, search: search || undefined, status: status || undefined } })).data,
    placeholderData: (p) => p,
  });
  const act = useMutation({
    mutationFn: ({ id, action, body }) => api.post(`/subscriptions/${id}/${action}/`, body),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["subscriptions"] }); qc.invalidateQueries({ queryKey: ["dashboard"] }); toast("Updated"); },
    onError: (e) => toast(errMsg(e), "error"),
  });
  const remove = useMutation({
    mutationFn: (id) => api.delete(`/subscriptions/${id}/`),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["subscriptions"] }); toast("Deleted"); },
    onError: (e) => toast(errMsg(e), "error"),
  });

  const Actions = ({ s }) => (
    <div className="flex flex-wrap gap-1 justify-end">
      {isStaff && NEXT[s.status] && (
        <button className="btn btn-xs btn-primary" onClick={() => act.mutate({ id: s.id, action: "transition", body: { status: NEXT[s.status][0] } })}>{NEXT[s.status][1]}</button>
      )}
      {s.status === "active" && !s.is_paused && s.plan_pausable && <button className="btn btn-xs" onClick={() => act.mutate({ id: s.id, action: "pause" })}>Pause</button>}
      {s.is_paused && <button className="btn btn-xs" onClick={() => act.mutate({ id: s.id, action: "resume" })}>Resume</button>}
      {["active", "closed"].includes(s.status) && s.plan_renewable && <button className="btn btn-xs" onClick={() => act.mutate({ id: s.id, action: "renew" })}>Renew</button>}
      {["confirmed", "active"].includes(s.status) && s.plan_closable && (
        <button className="btn btn-xs btn-outline btn-error" onClick={() => confirm("Close this subscription?") && act.mutate({ id: s.id, action: "transition", body: { status: "closed" } })}>Close</button>
      )}
      {isStaff && s.status === "draft" && <button className="btn btn-xs btn-ghost text-error" aria-label="Delete" onClick={() => confirm("Delete draft?") && remove.mutate(s.id)}><Trash2 size={14} /></button>}
    </div>
  );

  const data = rows(list.data);
  return (
    <>
      <PageHeader title={isStaff ? "Subscriptions" : "My subscriptions"} sub="Draft → Quotation → Confirmed → Active → Closed">
        <label className="input input-bordered input-sm flex items-center gap-2"><Search size={14} />
          <input placeholder="Search number or customer" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} /></label>
        <select className="select select-bordered select-sm" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
          <option value="">All statuses</option>{["draft", "quotation", "confirmed", "active", "closed"].map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        {isStaff && <>
          <button className="btn btn-sm" onClick={() => setModal("template")}><FilePlus2 size={16} /> From template</button>
          <button className="btn btn-sm btn-primary" onClick={() => setModal("new")}><Plus size={16} /> New</button></>}
      </PageHeader>

      {list.isLoading ? <Spinner /> : list.isError ? <ErrorBox error={list.error} /> : data.length === 0 ? <Empty text="No subscriptions found" /> : (
        <div className="card bg-base-100 shadow overflow-x-auto">
          <table className="table">
            <thead><tr><th>Number</th>{isStaff && <th>Customer</th>}<th>Plan</th><th>Status</th><th>Next invoice</th><th className="text-right">Per period</th><th /></tr></thead>
            <tbody>{data.map((s) => (
              <tr key={s.id} className="hover">
                <td><button className="link font-semibold" onClick={() => setModal(s)}>{s.number}</button></td>
                {isStaff && <td>{s.customer_company || s.customer_email}</td>}
                <td>{s.plan_name}<div className="text-xs text-base-content/60 capitalize">{s.billing_period}</div></td>
                <td><Badge value={s.status} />{s.is_paused && <span className="badge badge-outline ml-1">paused</span>}</td>
                <td>{s.next_invoice_date || "—"}</td>
                <td className="text-right">{money(s.total)}</td>
                <td><Actions s={s} /></td>
              </tr>))}
            </tbody>
          </table>
        </div>)}
      {list.data?.count != null && <Pager page={page} setPage={setPage} count={list.data.count} />}

      {modal === "new" && <NewSubscription onClose={() => setModal(null)} />}
      {modal === "template" && <FromTemplate onClose={() => setModal(null)} />}
      {modal && typeof modal === "object" && <Details s={modal} onClose={() => setModal(null)} />}
    </>
  );
}

function Details({ s, onClose }) {
  return (
    <Modal title={`${s.number} · ${s.plan_name}`} onClose={onClose} wide>
      <div className="grid sm:grid-cols-3 gap-2 text-sm mb-3">
        <div><span className="text-base-content/60">Customer</span><br />{s.customer_email}</div>
        <div><span className="text-base-content/60">Start / Expiry</span><br />{s.start_date} → {s.expiry_date || "open"}</div>
        <div><span className="text-base-content/60">Payment terms</span><br />{s.payment_terms_days} days</div>
      </div>
      <table className="table table-sm"><thead><tr><th>Product</th><th>Qty</th><th>Unit</th><th>Tax</th><th className="text-right">Amount</th></tr></thead>
        <tbody>{s.lines.map((l) => <tr key={l.id}><td>{l.product_name}{l.variant_name && <div className="text-xs text-base-content/60">{l.variant_name}</div>}</td>
          <td>{l.quantity}</td><td>{money(l.unit_price)}</td><td>{l.tax_rate}%</td><td className="text-right">{money(l.amount)}</td></tr>)}</tbody></table>
    </Modal>
  );
}

function NewSubscription({ onClose }) {
  const qc = useQueryClient();
  const products = useOptions("/products/");
  const plans = useOptions("/plans/");
  const [f, setF] = useState({ customer: "", plan: "", start_date: today(), expiry_date: "", payment_terms_days: 15 });
  const [lines, setLines] = useState([{ product: "", variant: "", quantity: 1 }]);
  const setLine = (i, k, v) => setLines((ls) => ls.map((l, j) => (j === i ? { ...l, [k]: v, ...(k === "product" ? { variant: "" } : {}) } : l)));
  const plan = (plans.data || []).find((p) => String(p.id) === String(f.plan));

  const create = useMutation({
    mutationFn: () => api.post("/subscriptions/", {
      ...f, expiry_date: f.expiry_date || null,
      lines: lines.filter((l) => l.product).map((l) => ({ product: l.product, variant: l.variant || null, quantity: Number(l.quantity) })),
    }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["subscriptions"] }); toast("Subscription created"); onClose(); },
    onError: (e) => toast(errMsg(e), "error"),
  });
  return (
    <Modal title="New subscription" onClose={onClose} wide>
      <form onSubmit={(e) => { e.preventDefault(); create.mutate(); }} className="grid gap-2 sm:grid-cols-2">
        <Field f={{ label: "Customer", required: true, optionsFrom: "/users/", optionsParams: { role: "customer", page_size: 200 }, optionLabel: "email" }} value={f.customer} onChange={(v) => setF({ ...f, customer: v })} />
        <Field f={{ label: "Plan", required: true, optionsFrom: "/plans/", help: plan && `Min quantity ${plan.min_quantity} · bills ${plan.billing_period}` }} value={f.plan} onChange={(v) => setF({ ...f, plan: v })} />
        <Field f={{ label: "Start date", type: "date", required: true }} value={f.start_date} onChange={(v) => setF({ ...f, start_date: v })} />
        <Field f={{ label: "Expiry date", type: "date" }} value={f.expiry_date} onChange={(v) => setF({ ...f, expiry_date: v })} />
        <Field f={{ label: "Payment terms (days)", type: "number", min: 0 }} value={f.payment_terms_days} onChange={(v) => setF({ ...f, payment_terms_days: v })} />
        <div className="sm:col-span-2 mt-2">
          <div className="font-semibold mb-1">Lines</div>
          {lines.map((l, i) => {
            const prod = (products.data || []).find((p) => String(p.id) === String(l.product));
            return (
              <div key={i} className="grid grid-cols-12 gap-2 mb-2">
                <select className="select select-bordered select-sm col-span-5" value={l.product} onChange={(e) => setLine(i, "product", e.target.value)} required={i === 0}>
                  <option value="">Product…</option>{(products.data || []).map((p) => <option key={p.id} value={p.id}>{p.name} · {money(p.sales_price)}</option>)}</select>
                <select className="select select-bordered select-sm col-span-4" value={l.variant} disabled={!prod?.variants?.length} onChange={(e) => setLine(i, "variant", e.target.value)}>
                  <option value="">{prod?.variants?.length ? "Variant…" : "No variants"}</option>{prod?.variants?.map((v) => <option key={v.id} value={v.id}>{v.value} (+{money(v.extra_price)})</option>)}</select>
                <input type="number" min={plan?.min_quantity || 1} className="input input-bordered input-sm col-span-2" value={l.quantity} onChange={(e) => setLine(i, "quantity", e.target.value)} />
                <button type="button" className="btn btn-ghost btn-sm col-span-1 text-error" aria-label="Remove line" onClick={() => setLines((ls) => ls.filter((_, j) => j !== i))}><Trash2 size={14} /></button>
              </div>);
          })}
          <button type="button" className="btn btn-xs" onClick={() => setLines([...lines, { product: "", variant: "", quantity: 1 }])}><Plus size={12} /> Add line</button>
        </div>
        <div className="sm:col-span-2 modal-action"><button type="button" className="btn" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" disabled={create.isPending}>Create draft</button></div>
      </form>
    </Modal>
  );
}

function FromTemplate({ onClose }) {
  const qc = useQueryClient();
  const [f, setF] = useState({ template: "", customer: "", start_date: today() });
  const create = useMutation({
    mutationFn: () => api.post("/subscriptions/from-template/", f),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["subscriptions"] }); toast("Quotation created from template"); onClose(); },
    onError: (e) => toast(errMsg(e), "error"),
  });
  return (
    <Modal title="Quotation from template" onClose={onClose}>
      <form onSubmit={(e) => { e.preventDefault(); create.mutate(); }} className="grid gap-2">
        <Field f={{ label: "Template", required: true, optionsFrom: "/templates/", help: "Plan, product lines and validity come from the template" }} value={f.template} onChange={(v) => setF({ ...f, template: v })} />
        <Field f={{ label: "Customer", required: true, optionsFrom: "/users/", optionsParams: { role: "customer", page_size: 200 }, optionLabel: "email" }} value={f.customer} onChange={(v) => setF({ ...f, customer: v })} />
        <Field f={{ label: "Start date", type: "date", required: true }} value={f.start_date} onChange={(v) => setF({ ...f, start_date: v })} />
        <div className="modal-action"><button type="button" className="btn" onClick={onClose}>Cancel</button><button className="btn btn-primary" disabled={create.isPending}>Create quotation</button></div>
      </form>
    </Modal>
  );
}
