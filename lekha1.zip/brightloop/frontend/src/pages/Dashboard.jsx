import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { AlertTriangle, IndianRupee, Repeat, Wallet } from "lucide-react";
import { api, money } from "../api";
import { Badge, Empty, ErrorBox, Field, PageHeader, Spinner } from "../components/ui";

const Stat = ({ icon: I, label, value, tone = "text-primary", hint }) => (
  <div className="stat bg-base-100 rounded-box shadow">
    <div className={`stat-figure ${tone}`}><I size={28} /></div>
    <div className="stat-title">{label}</div>
    <div className={`stat-value text-2xl ${tone}`}>{value}</div>
    {hint && <div className="stat-desc">{hint}</div>}
  </div>
);

export default function Dashboard() {
  const [filters, setFilters] = useState({ date_from: "", date_to: "", customer: "" });
  const q = useQuery({
    queryKey: ["dashboard", filters],
    queryFn: async () => (await api.get("/dashboard/", { params: Object.fromEntries(Object.entries(filters).filter(([, v]) => v)) })).data,
    placeholderData: (p) => p,
  });
  const set = (k) => (v) => setFilters((f) => ({ ...f, [k]: v }));
  const d = q.data;
  return (
    <>
      <PageHeader title="Finance dashboard" sub="Live view of recurring revenue, collections and overdue invoices" />
      <div className="card bg-base-100 shadow mb-5"><div className="card-body py-3 grid gap-2 sm:grid-cols-3">
        <Field f={{ label: "From", type: "date" }} value={filters.date_from} onChange={set("date_from")} />
        <Field f={{ label: "To", type: "date" }} value={filters.date_to} onChange={set("date_to")} />
        <Field f={{ label: "Customer", optionsFrom: "/users/", optionsParams: { role: "customer", page_size: 100 }, optionLabel: "email" }} value={filters.customer} onChange={set("customer")} />
      </div></div>

      {q.isLoading ? <Spinner /> : q.isError ? <ErrorBox error={q.error} /> : (
        <>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4 mb-5">
            <Stat icon={Repeat} label="Active subscriptions" value={d.active_subscriptions.toLocaleString()} hint={`MRR ${money(d.mrr)}`} />
            <Stat icon={IndianRupee} label="Revenue collected" value={money(d.revenue)} tone="text-success" hint={`Invoiced ${money(d.invoiced)}`} />
            <Stat icon={Wallet} label="Outstanding" value={money(d.outstanding)} tone="text-warning" hint="Confirmed, unpaid invoices" />
            <Stat icon={AlertTriangle} label="Overdue" value={`${d.overdue_count} · ${money(d.overdue_amount)}`} tone="text-error" hint="Past due date" />
          </div>
          <div className="grid gap-4 lg:grid-cols-3 mb-5">
            <div className="card bg-base-100 shadow lg:col-span-2"><div className="card-body">
              <h2 className="card-title text-base">Revenue by month</h2>
              {d.revenue_by_month.length === 0 ? <Empty text="No payments in this range" /> : (
                <div style={{ height: 260 }}><ResponsiveContainer>
                  <BarChart data={d.revenue_by_month.map((r) => ({ ...r, total: Number(r.total) }))}>
                    <CartesianGrid strokeDasharray="3 3" opacity={0.3} /><XAxis dataKey="month" fontSize={12} /><YAxis fontSize={12} width={70} />
                    <Tooltip formatter={(v) => money(v)} /><Bar dataKey="total" fill="oklch(60% 0.2 275)" radius={[6, 6, 0, 0]} />
                  </BarChart></ResponsiveContainer></div>)}
            </div></div>
            <div className="card bg-base-100 shadow"><div className="card-body">
              <h2 className="card-title text-base">Subscriptions by status</h2>
              <ul className="space-y-2">{Object.entries(d.subscriptions_by_status).map(([s, n]) => (
                <li key={s} className="flex justify-between items-center"><Badge value={s} /><b>{n.toLocaleString()}</b></li>))}</ul>
              <h2 className="card-title text-base mt-4">Payments by method</h2>
              <ul className="space-y-1 text-sm">{d.revenue_by_method.map((m) => (
                <li key={m.method} className="flex justify-between"><span className="capitalize">{m.method.replace("_", " ")}</span><b>{money(m.total)}</b></li>))}</ul>
            </div></div>
          </div>
          <div className="card bg-base-100 shadow"><div className="card-body">
            <h2 className="card-title text-base">Most overdue invoices</h2>
            {d.overdue_invoices.length === 0 ? <Empty text="Nothing overdue. Nice." /> : (
              <div className="overflow-x-auto"><table className="table table-sm">
                <thead><tr><th>Invoice</th><th>Customer</th><th>Due</th><th className="text-right">Balance</th></tr></thead>
                <tbody>{d.overdue_invoices.map((i) => (
                  <tr key={i.id}><td>{i.number}</td><td>{i.customer_company || i.customer_email}</td>
                    <td className="text-error">{i.due_date}</td><td className="text-right">{money(i.outstanding)}</td></tr>))}</tbody>
              </table></div>)}
          </div></div>
        </>
      )}
    </>
  );
}
