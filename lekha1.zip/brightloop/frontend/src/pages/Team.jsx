import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { UserPlus } from "lucide-react";
import { api, errMsg, rows } from "../api";
import { Badge, Empty, Field, Modal, PageHeader, Pager, Spinner, toast } from "../components/ui";

export default function Team() {
  const qc = useQueryClient();
  const [page, setPage] = useState(1);
  const [role, setRole] = useState("");
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ first_name: "", email: "", password: "" });
  const q = useQuery({ queryKey: ["users", page, role], queryFn: async () => (await api.get("/users/", { params: { page, role: role || undefined } })).data, placeholderData: (p) => p });
  const create = useMutation({
    mutationFn: () => api.post("/auth/staff/", f),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["users"] }); toast("Staff member added"); setOpen(false); setF({ first_name: "", email: "", password: "" }); },
    onError: (e) => toast(errMsg(e), "error"),
  });
  const data = rows(q.data);
  return (
    <>
      <PageHeader title="Users" sub="Only the admin can add staff">
        <select className="select select-bordered select-sm" value={role} onChange={(e) => { setRole(e.target.value); setPage(1); }}>
          <option value="">All roles</option><option value="admin">Admin</option><option value="staff">Staff</option><option value="customer">Customer</option></select>
        <button className="btn btn-primary btn-sm" onClick={() => setOpen(true)}><UserPlus size={16} /> Add staff</button>
      </PageHeader>
      {q.isLoading ? <Spinner /> : data.length === 0 ? <Empty /> : (
        <div className="card bg-base-100 shadow overflow-x-auto"><table className="table">
          <thead><tr><th>Name</th><th>Email</th><th>Company</th><th>Role</th></tr></thead>
          <tbody>{data.map((u) => <tr key={u.id} className="hover"><td>{u.first_name || "—"}</td><td>{u.email}</td><td>{u.company || "—"}</td><td><Badge value={u.role} /></td></tr>)}</tbody>
        </table></div>)}
      {q.data?.count != null && <Pager page={page} setPage={setPage} count={q.data.count} />}
      {open && (
        <Modal title="Add staff member" onClose={() => setOpen(false)}>
          <form onSubmit={(e) => { e.preventDefault(); create.mutate(); }} className="grid gap-2">
            <Field f={{ label: "Name" }} value={f.first_name} onChange={(v) => setF({ ...f, first_name: v })} />
            <Field f={{ label: "Email", type: "email", required: true }} value={f.email} onChange={(v) => setF({ ...f, email: v })} />
            <Field f={{ label: "Temporary password", type: "password", required: true, help: "9+ characters, upper, lower and a special character" }} value={f.password} onChange={(v) => setF({ ...f, password: v })} />
            <div className="modal-action"><button type="button" className="btn" onClick={() => setOpen(false)}>Cancel</button><button className="btn btn-primary" disabled={create.isPending}>Add</button></div>
          </form>
        </Modal>)}
    </>
  );
}
