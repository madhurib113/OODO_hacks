import { useState } from "react";
import { Link, Navigate, useNavigate, useSearchParams } from "react-router-dom";
import { Repeat } from "lucide-react";
import { api, errMsg } from "../api";
import { useAuth } from "../auth";
import { toast } from "../components/ui";

function Shell({ title, subtitle, children, footer }) {
  return (
    <div className="min-h-screen grid place-items-center bg-gradient-to-br from-primary/10 via-base-200 to-secondary/10 p-4">
      <div className="card bg-base-100 shadow-xl w-full max-w-md">
        <div className="card-body">
          <div className="flex items-center gap-2 text-primary font-bold text-xl"><Repeat /> Brightloop</div>
          <h1 className="text-2xl font-bold mt-2">{title}</h1>
          <p className="text-base-content/60 text-sm -mt-1">{subtitle}</p>
          <div className="mt-3">{children}</div>
          <div className="text-sm text-center mt-2">{footer}</div>
        </div>
      </div>
    </div>
  );
}

const PW_HINT = "At least 9 characters with an uppercase letter, a lowercase letter and a special character.";

export function Login() {
  const { user, login } = useAuth();
  const nav = useNavigate();
  const [f, setF] = useState({ email: "", password: "" });
  const [busy, setBusy] = useState(false);
  if (user) return <Navigate to="/" replace />;
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try { await login(f.email, f.password); nav("/"); }
    catch (err) { toast(err.response?.status === 401 ? "Wrong email or password" : errMsg(err), "error"); }
    finally { setBusy(false); }
  };
  const demo = (email, password) => setF({ email, password });
  return (
    <Shell title="Welcome back" subtitle="Sign in to manage subscriptions and invoices"
      footer={<><Link className="link" to="/forgot">Forgot password?</Link> · <Link className="link" to="/register">Create account</Link></>}>
      <form onSubmit={submit} className="grid gap-3">
        <input className="input input-bordered w-full" type="email" placeholder="Email" required autoComplete="username" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
        <input className="input input-bordered w-full" type="password" placeholder="Password" required autoComplete="current-password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} />
        <button className="btn btn-primary" disabled={busy}>{busy ? <span className="loading loading-spinner" /> : "Sign in"}</button>
      </form>
      <div className="divider text-xs">Demo accounts (click to fill)</div>
      <div className="flex gap-2 justify-center flex-wrap">
        <button className="btn btn-xs btn-outline" onClick={() => demo("admin@brightloop.test", "Admin@12345")}>Admin</button>
        <button className="btn btn-xs btn-outline" onClick={() => demo("staff@brightloop.test", "Staff@12345")}>Staff</button>
        <button className="btn btn-xs btn-outline" onClick={() => demo("customer@brightloop.test", "Customer@123")}>Customer</button>
      </div>
    </Shell>
  );
}

export function Register() {
  const { user, register } = useAuth();
  const nav = useNavigate();
  const [f, setF] = useState({ first_name: "", company: "", email: "", password: "" });
  const [busy, setBusy] = useState(false);
  if (user) return <Navigate to="/" replace />;
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try { await register(f); toast("Account created"); nav("/"); }
    catch (err) { toast(errMsg(err), "error"); }
    finally { setBusy(false); }
  };
  return (
    <Shell title="Create your account" subtitle="One account per email address" footer={<>Already registered? <Link className="link" to="/login">Sign in</Link></>}>
      <form onSubmit={submit} className="grid gap-3">
        <input className="input input-bordered w-full" placeholder="Your name" value={f.first_name} onChange={set("first_name")} />
        <input className="input input-bordered w-full" placeholder="Company (optional)" value={f.company} onChange={set("company")} />
        <input className="input input-bordered w-full" type="email" placeholder="Email" required value={f.email} onChange={set("email")} />
        <input className="input input-bordered w-full" type="password" placeholder="Password" required autoComplete="new-password" value={f.password} onChange={set("password")} />
        <p className="text-xs text-base-content/60 -mt-1">{PW_HINT}</p>
        <button className="btn btn-primary" disabled={busy}>{busy ? <span className="loading loading-spinner" /> : "Sign up"}</button>
      </form>
    </Shell>
  );
}

export function Forgot() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const submit = async (e) => {
    e.preventDefault();
    try { await api.post("/auth/password-reset/", { email }); setSent(true); } catch (err) { toast(errMsg(err), "error"); }
  };
  return (
    <Shell title="Reset your password" subtitle="We will email you a reset link" footer={<Link className="link" to="/login">Back to sign in</Link>}>
      {sent ? <div className="alert alert-success text-sm">If that email is registered, a reset link is on its way.</div> : (
        <form onSubmit={submit} className="grid gap-3">
          <input className="input input-bordered w-full" type="email" placeholder="Registered email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          <button className="btn btn-primary">Send reset link</button>
        </form>
      )}
    </Shell>
  );
}

export function ResetPassword() {
  const [q] = useSearchParams();
  const nav = useNavigate();
  const [password, setPassword] = useState("");
  const submit = async (e) => {
    e.preventDefault();
    try {
      await api.post("/auth/password-reset/confirm/", { uid: q.get("uid"), token: q.get("token"), password });
      toast("Password updated. Please sign in."); nav("/login");
    } catch (err) { toast(errMsg(err), "error"); }
  };
  return (
    <Shell title="Choose a new password" subtitle={PW_HINT} footer={<Link className="link" to="/login">Back to sign in</Link>}>
      <form onSubmit={submit} className="grid gap-3">
        <input className="input input-bordered w-full" type="password" placeholder="New password" required autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} />
        <button className="btn btn-primary">Update password</button>
      </form>
    </Shell>
  );
}
