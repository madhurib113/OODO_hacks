import { money } from "../api";
import Crud from "../components/Crud";
import { Badge } from "../components/ui";

const yes = (v) => (v ? <span className="badge badge-success badge-sm">yes</span> : <span className="badge badge-ghost badge-sm">no</span>);

export const Products = () => (
  <Crud title="Products" sub="Sales price, cost price and variants" path="/products/"
    columns={[
      { key: "name", label: "Name" }, { key: "type", label: "Type" },
      { key: "sales_price", label: "Sales", render: (r) => money(r.sales_price) },
      { key: "cost_price", label: "Cost", render: (r) => money(r.cost_price) },
      { key: "variants", label: "Variants", render: (r) => r.variants.length ? r.variants.map((v) => `${v.value} (+${v.extra_price})`).join(", ") : "—" },
    ]}
    fields={[
      { name: "name", label: "Name", required: true }, { name: "type", label: "Type", default: "software" },
      { name: "sales_price", label: "Sales price", type: "number", required: true, min: 0 },
      { name: "cost_price", label: "Cost price", type: "number", min: 0, default: 0 },
      { name: "notes", label: "Notes", type: "textarea" },
    ]} />
);

export const Variants = () => (
  <Crud title="Variants" sub="e.g. choosing the Odoo brand adds 560 to the price" path="/variants/" searchable={false}
    columns={[
      { key: "product", label: "Product", render: (r) => r.product_name || r.product },
      { key: "attribute", label: "Attribute" }, { key: "value", label: "Value" },
      { key: "extra_price", label: "Extra price", render: (r) => money(r.extra_price) },
    ]}
    fields={[
      { name: "product", label: "Product", required: true, optionsFrom: "/products/" },
      { name: "attribute", label: "Attribute", default: "Brand", required: true },
      { name: "value", label: "Value", required: true },
      { name: "extra_price", label: "Extra price", type: "number", default: 0 },
    ]} />
);

export const Plans = () => (
  <Crud title="Plans" sub="Price, billing period and lifecycle rules" path="/plans/"
    columns={[
      { key: "name", label: "Name" }, { key: "price", label: "Price", render: (r) => money(r.price) },
      { key: "billing_period", label: "Billing", render: (r) => <Badge value={r.billing_period} /> },
      { key: "min_quantity", label: "Min qty" },
      { key: "dates", label: "Available", render: (r) => `${r.start_date || "—"} → ${r.end_date || "open"}` },
      { key: "auto_close", label: "Auto-close", render: (r) => yes(r.auto_close) }, { key: "closable", label: "Closable", render: (r) => yes(r.closable) },
      { key: "pausable", label: "Pausable", render: (r) => yes(r.pausable) }, { key: "renewable", label: "Renewable", render: (r) => yes(r.renewable) },
    ]}
    fields={[
      { name: "name", label: "Name", required: true },
      { name: "price", label: "Price", type: "number", required: true, min: 0 },
      { name: "billing_period", label: "Billing period", type: "select", required: true, default: "monthly",
        options: ["daily", "weekly", "monthly", "yearly"].map((v) => ({ value: v, label: v })) },
      { name: "min_quantity", label: "Minimum quantity", type: "number", default: 1, min: 1 },
      { name: "start_date", label: "Available from", type: "date" }, { name: "end_date", label: "Available until", type: "date" },
      { name: "auto_close", label: "Close automatically at end", type: "checkbox" },
      { name: "closable", label: "Can be closed early", type: "checkbox", default: true },
      { name: "pausable", label: "Can be paused", type: "checkbox" },
      { name: "renewable", label: "Can be renewed", type: "checkbox", default: true },
    ]} />
);

export const Taxes = () => (
  <Crud title="Tax rules" sub="Applied automatically on every invoice. Product rules override general ones; rules of the same kind add up." path="/taxes/" searchable={false}
    columns={[
      { key: "name", label: "Name" }, { key: "rate", label: "Rate", render: (r) => `${r.rate}%` },
      { key: "product", label: "Applies to", render: (r) => (r.product ? `Product #${r.product}` : "All products") },
      { key: "is_active", label: "Active", render: (r) => yes(r.is_active) },
    ]}
    fields={[
      { name: "name", label: "Name", required: true, help: "e.g. GST 18%" },
      { name: "rate", label: "Rate (%)", type: "number", required: true, min: 0 },
      { name: "product", label: "Only for product (optional)", optionsFrom: "/products/" },
      { name: "is_active", label: "Active", type: "checkbox", default: true },
    ]} />
);

export const Discounts = () => (
  <Crud title="Discounts" sub="Applied to the next invoice automatically until they expire or run out" path="/discounts/"
    columns={[
      { key: "name", label: "Name" },
      { key: "value", label: "Value", render: (r) => (r.kind === "percent" ? `${r.value}%` : money(r.value)) },
      { key: "apply_to", label: "Applies to", render: (r) => (r.apply_to === "product" ? `Product #${r.product}` : "Whole subscription") },
      { key: "min", label: "Minimum", render: (r) => `${money(r.min_amount)} / ${r.min_quantity} qty` },
      { key: "dates", label: "Valid", render: (r) => `${r.start_date || "—"} → ${r.end_date || "open"}` },
      { key: "usage", label: "Used", render: (r) => `${r.times_used}${r.usage_limit ? ` / ${r.usage_limit}` : ""}` },
      { key: "is_active", label: "Active", render: (r) => yes(r.is_active) },
    ]}
    fields={[
      { name: "name", label: "Name", required: true },
      { name: "kind", label: "Type", type: "select", required: true, default: "percent", options: [{ value: "percent", label: "Percentage" }, { value: "fixed", label: "Fixed amount" }] },
      { name: "value", label: "Value", type: "number", required: true, min: 0 },
      { name: "apply_to", label: "Applies to", type: "select", required: true, default: "subscription", options: [{ value: "subscription", label: "Whole subscription" }, { value: "product", label: "Specific product" }] },
      { name: "product", label: "Product", optionsFrom: "/products/", hidden: (v) => v.apply_to !== "product" },
      { name: "min_amount", label: "Minimum purchase amount", type: "number", default: 0 },
      { name: "min_quantity", label: "Minimum quantity", type: "number", default: 0 },
      { name: "start_date", label: "Start date", type: "date" }, { name: "end_date", label: "End date", type: "date" },
      { name: "usage_limit", label: "Usage limit", type: "number", help: "Empty = unlimited" },
      { name: "is_active", label: "Active", type: "checkbox", default: true },
    ]} />
);

export const Templates = () => {
  return (
    <Crud title="Quotation templates" sub="Reusable plan + product lines with a validity period" path="/templates/" searchable={false}
      columns={[
        { key: "name", label: "Name" }, { key: "plan_name", label: "Plan" }, { key: "validity_days", label: "Valid for", render: (r) => `${r.validity_days} days` },
        { key: "lines", label: "Lines", render: (r) => r.lines.map((l) => `${l.quantity} × ${l.product_name}`).join(", ") || "—" },
      ]}
      fields={[
        { name: "name", label: "Name", required: true },
        { name: "plan", label: "Plan", required: true, optionsFrom: "/plans/" },
        { name: "validity_days", label: "Validity (days)", type: "number", default: 30, required: true },
        { name: "product", label: "First product line", optionsFrom: "/products/", help: "More lines can be added via the API / admin" },
        { name: "quantity", label: "Quantity", type: "number", default: 1 },
      ]}
      prepare={(b) => {
        const { product, quantity, ...rest } = b;
        return product ? { ...rest, lines: [{ product, quantity: Number(quantity) || 1 }] } : rest;
      }} />
  );
};
