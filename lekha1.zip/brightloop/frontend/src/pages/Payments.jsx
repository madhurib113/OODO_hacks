import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search } from "lucide-react";
import { api, money, rows } from "../api";
import { Empty, ErrorBox, PageHeader, Pager, Spinner } from "../components/ui";

export default function Payments() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [method, setMethod] = useState("");
  const q = useQuery({
    queryKey: ["payments", page, search, method],
    queryFn: async () => (await api.get("/payments/", { params: { page, search: search || undefined, method: method || undefined } })).data,
    placeholderData: (p) => p,
  });
  const data = rows(q.data);
  return (
    <>
      <PageHeader title="Payments" sub="Every payment, matched to its invoice">
        <label className="input input-bordered input-sm flex items-center gap-2"><Search size={14} />
          <input placeholder="Invoice, customer, note" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} /></label>
        <select className="select select-bordered select-sm" value={method} onChange={(e) => { setMethod(e.target.value); setPage(1); }}>
          <option value="">All methods</option>{["card", "upi", "bank_transfer", "cash", "cheque"].map((m) => <option key={m} value={m}>{m.replace("_", " ")}</option>)}
        </select>
      </PageHeader>
      {q.isLoading ? <Spinner /> : q.isError ? <ErrorBox error={q.error} /> : data.length === 0 ? <Empty text="No payments recorded yet" /> : (
        <div className="card bg-base-100 shadow overflow-x-auto"><table className="table">
          <thead><tr><th>Date</th><th>Invoice</th><th>Customer</th><th>Method</th><th>Note</th><th className="text-right">Amount</th></tr></thead>
          <tbody>{data.map((p) => <tr key={p.id} className="hover"><td>{p.date}</td><td>{p.invoice_number}</td><td>{p.customer_email}</td>
            <td className="capitalize">{p.method.replace("_", " ")}</td><td className="text-base-content/70">{p.note || "—"}</td><td className="text-right font-medium">{money(p.amount)}</td></tr>)}</tbody>
        </table></div>)}
      {q.data?.count != null && <Pager page={page} setPage={setPage} count={q.data.count} />}
    </>
  );
}
