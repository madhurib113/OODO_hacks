import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Ban, CheckCheck, CreditCard, Mail, Printer, Search, Zap } from "lucide-react";
import { api, errMsg, money, rows, today } from "../api";
import { useAuth } from "../auth";
import { Badge, Empty, ErrorBox, Field, Modal, PageHeader, Pager, Spinner, toast } from "../components/ui";

export default function Invoices() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const isStaff = user.role !== "customer";
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [view, setView] = useState(""); // "" | status | overdue | outstanding
  const [paying, setPaying] = useState(null);
  const [detail, setDetail] = useState(null);
  const [asOf, setAsOf] = useState(today());

  const params = { page, search: search || undefined };
  if (view === "overdue") params.overdue = true;
  else if (view === "outstanding") params.outstanding = true;
  else if (view) params.status = view;

  const list = useQuery({ queryKey: ["invoices", params], queryFn: async () => (await api.get("/invoices/", { params })).data, placeholderData: (p) => p });
  const refresh = () => { qc.invalidateQueries({ queryKey: ["invoices"] }); qc.invalidateQueries({ queryKey: ["dashboard"] }); qc.invalidateQueries({ queryKey: ["payments"] }); };
  const act = useMutation({
    mutationFn: ({ id, action }) => api.post(`/invoices/${id}/${action}/`),
    onSuccess: (_, v) => { refresh(); toast(`Invoice ${{ confirm: "confirmed", cancel: "cancelled", send: "sent" }[v.action]}`); },
    onError: (e) => toast(errMsg(e), "error"),
  });
  const generate = useMutation({
    mutationFn: () => api.post("/invoices/generate/", { as_of: asOf }),
    onSuccess: ({ data }) => { refresh(); qc.invalidateQueries({ queryKey: ["subscriptions"] }); toast(`Billing run: ${data.created} created, ${data.skipped} already billed, ${data.closed} auto-closed`); },
    onError: (e) => toast(errMsg(e), "error"),
  });
  const print = async (id) => {
    const w = window.open("", "_blank");
    try { const { data } = await api.get(`/invoices/${id}/print/`, { responseType: "text" }); w.document.write(data); w.document.close(); w.focus(); w.print(); }
    catch (e) { w.close(); toast(errMsg(e), "error"); }
  };

  const data = rows(list.data);
  return (
    <>
      <PageHeader title={isStaff ? "Invoices" : "My invoices"} sub="Draft → Confirmed → Paid">
        <label className="input input-bordered input-sm flex items-center gap-2"><Search size={14} />
          <input placeholder="Search" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} /></label>
        {isStaff && <div className="join">
          <input type="date" className="input input-bordered input-sm join-item" value={asOf} onChange={(e) => setAsOf(e.target.value)} aria-label="Bill up to" />
          <button className="btn btn-primary btn-sm join-item" disabled={generate.isPending} onClick={() => generate.mutate()}>
            {generate.isPending ? <span className="loading loading-spinner loading-xs" /> : <Zap size={16} />} Run billing</button></div>}
      </PageHeader>

      <div role="tablist" className="tabs tabs-box mb-4 w-fit">
        {[["", "All"], ["draft", "Draft"], ["outstanding", "Outstanding"], ["overdue", "Overdue"], ["paid", "Paid"], ["cancelled", "Cancelled"]].map(([k, l]) => (
          <button key={k} role="tab" className={`tab ${view === k ? "tab-active" : ""}`} onClick={() => { setView(k); setPage(1); }}>{l}</button>))}
      </div>

      {list.isLoading ? <Spinner /> : list.isError ? <ErrorBox error={list.error} /> : data.length === 0 ? <Empty text="No invoices in this view" /> : (
        <div className="card bg-base-100 shadow overflow-x-auto">
          <table className="table">
            <thead><tr><th>Invoice</th>{isStaff && <th>Customer</th>}<th>Period</th><th>Due</th><th>Status</th><th className="text-right">Total</th><th className="text-right">Balance</th><th /></tr></thead>
            <tbody>{data.map((i) => (
              <tr key={i.id} className="hover">
                <td><button className="link font-semibold" onClick={() => setDetail(i.id)}>{i.number}</button><div className="text-xs text-base-content/60">{i.subscription_number}</div></td>
                {isStaff && <td>{i.customer_company || i.customer_email}</td>}
                <td className="text-xs">{i.period_start} → {i.period_end}</td>
                <td className={i.is_overdue ? "text-error font-semibold" : ""}>{i.due_date}</td>
                <td><Badge value={i.is_overdue ? "overdue" : i.status} /></td>
                <td className="text-right">{money(i.total)}</td><td className="text-right">{money(i.outstanding)}</td>
                <td className="whitespace-nowrap text-right">
                  {isStaff && i.status === "draft" && <button className="btn btn-xs btn-primary" onClick={() => act.mutate({ id: i.id, action: "confirm" })}><CheckCheck size={14} /> Confirm</button>}
                  {isStaff && i.status === "confirmed" && <button className="btn btn-xs btn-success" onClick={() => setPaying(i)}><CreditCard size={14} /> Pay</button>}
                  {isStaff && ["confirmed", "paid"].includes(i.status) && <button className="btn btn-xs btn-ghost" aria-label="Send" onClick={() => act.mutate({ id: i.id, action: "send" })}><Mail size={14} /></button>}
                  <button className="btn btn-xs btn-ghost" aria-label="Print" onClick={() => print(i.id)}><Printer size={14} /></button>
                  {isStaff && ["draft", "confirmed"].includes(i.status) && Number(i.amount_paid) === 0 && <button className="btn btn-xs btn-ghost text-error" aria-label="Cancel" onClick={() => confirm("Cancel this invoice?") && act.mutate({ id: i.id, action: "cancel" })}><Ban size={14} /></button>}
                </td>
              </tr>))}
            </tbody>
          </table>
        </div>)}
      {list.data?.count != null && <Pager page={page} setPage={setPage} count={list.data.count} />}
      {paying && <PayModal inv={paying} onClose={() => setPaying(null)} onDone={refresh} />}
      {detail && <InvoiceDetail id={detail} onClose={() => setDetail(null)} />}
    </>
  );
}

function InvoiceDetail({ id, onClose }) {
  const q = useQuery({ queryKey: ["invoice", id], queryFn: async () => (await api.get(`/invoices/${id}/`)).data });
  return (
    <Modal title={q.data ? `Invoice ${q.data.number}` : "Invoice"} onClose={onClose} wide>
      {!q.data ? <Spinner /> : <>
        <table className="table table-sm"><thead><tr><th>Item</th><th>Qty</th><th>Unit</th><th>Discount</th><th>Tax</th><th className="text-right">Amount</th></tr></thead>
          <tbody>{q.data.lines.map((l) => <tr key={l.id}><td>{l.description}</td><td>{l.quantity}</td><td>{money(l.unit_price)}</td><td>{money(l.discount)}</td><td>{l.tax_rate}%</td><td className="text-right">{money(Number(l.amount) + Number(l.tax_amount))}</td></tr>)}</tbody></table>
        <div className="text-right mt-3 text-sm space-y-0.5">
          <div>Subtotal {money(q.data.subtotal)}</div><div>Discount −{money(q.data.discount_total)}</div><div>Tax {money(q.data.tax_total)}</div>
          <div className="font-bold text-base">Total {money(q.data.total)}</div><div>Paid {money(q.data.amount_paid)}</div><div className="font-semibold">Balance {money(q.data.outstanding)}</div>
        </div></>}
    </Modal>
  );
}

function PayModal({ inv, onClose, onDone }) {
  const [f, setF] = useState({ method: "upi", amount: inv.outstanding, date: today(), note: "" });
  const pay = useMutation({
    mutationFn: () => api.post("/payments/", { invoice: inv.id, ...f }),
    onSuccess: () => { onDone(); toast("Payment recorded"); onClose(); },
    onError: (e) => toast(errMsg(e), "error"),
  });
  return (
    <Modal title={`Record payment · ${inv.number}`} onClose={onClose}>
      <p className="text-sm mb-2">Outstanding balance: <b>{money(inv.outstanding)}</b></p>
      <form onSubmit={(e) => { e.preventDefault(); pay.mutate(); }} className="grid gap-2">
        <Field f={{ label: "Method", type: "select", required: true, options: [["card", "Card"], ["upi", "UPI"], ["bank_transfer", "Bank transfer"], ["cash", "Cash"], ["cheque", "Cheque"]].map(([value, label]) => ({ value, label })) }} value={f.method} onChange={(v) => setF({ ...f, method: v })} />
        <Field f={{ label: "Amount", type: "number", required: true, min: 0.01 }} value={f.amount} onChange={(v) => setF({ ...f, amount: v })} />
        <Field f={{ label: "Date", type: "date", required: true }} value={f.date} onChange={(v) => setF({ ...f, date: v })} />
        <Field f={{ label: "Note", type: "text" }} value={f.note} onChange={(v) => setF({ ...f, note: v })} />
        <div className="modal-action"><button type="button" className="btn" onClick={onClose}>Cancel</button><button className="btn btn-success" disabled={pay.isPending}>Record payment</button></div>
      </form>
    </Modal>
  );
}
