import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Pencil, Trash2, Search } from "lucide-react";
import { api, errMsg, rows } from "../api";
import { useAuth } from "../auth";
import { Empty, ErrorBox, Field, Modal, PageHeader, Pager, Spinner, toast } from "./ui";

/** Generic list + create/edit/delete page driven by config. Writes are shown only to the admin. */
export default function Crud({ title, sub, path, columns, fields, canWrite = (u) => u.role === "admin", searchable = true, prepare }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState(null); // {} = new
  const writable = canWrite(user);

  const list = useQuery({
    queryKey: [path, page, search],
    queryFn: async () => (await api.get(path, { params: { page, search: search || undefined } })).data,
    placeholderData: (p) => p,
  });
  const save = useMutation({
    mutationFn: (body) => (body.id ? api.patch(`${path}${body.id}/`, body) : api.post(path, body)),
    onSuccess: () => { qc.invalidateQueries({ queryKey: [path] }); qc.invalidateQueries({ queryKey: ["options"] }); setEditing(null); toast("Saved"); },
    onError: (e) => toast(errMsg(e), "error"),
  });
  const del = useMutation({
    mutationFn: (id) => api.delete(`${path}${id}/`),
    onSuccess: () => { qc.invalidateQueries({ queryKey: [path] }); toast("Deleted"); },
    onError: (e) => toast(errMsg(e).includes("protected") ? "In use elsewhere, cannot delete" : errMsg(e), "error"),
  });

  const data = rows(list.data);
  return (
    <>
      <PageHeader title={title} sub={sub}>
        {searchable && (
          <label className="input input-bordered input-sm flex items-center gap-2">
            <Search size={14} />
            <input placeholder="Search" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} />
          </label>
        )}
        {writable && <button className="btn btn-primary btn-sm" onClick={() => setEditing({})}><Plus size={16} /> New</button>}
      </PageHeader>

      {list.isLoading ? <Spinner /> : list.isError ? <ErrorBox error={list.error} /> : data.length === 0 ? <Empty text={`No ${title.toLowerCase()} yet`} /> : (
        <div className="card bg-base-100 shadow overflow-x-auto">
          <table className="table">
            <thead><tr>{columns.map((c) => <th key={c.key}>{c.label}</th>)}{writable && <th />}</tr></thead>
            <tbody>
              {data.map((r) => (
                <tr key={r.id} className="hover">
                  {columns.map((c) => <td key={c.key}>{c.render ? c.render(r) : String(r[c.key] ?? "—")}</td>)}
                  {writable && (
                    <td className="text-right whitespace-nowrap">
                      <button className="btn btn-ghost btn-xs" aria-label="Edit" onClick={() => setEditing(r)}><Pencil size={14} /></button>
                      <button className="btn btn-ghost btn-xs text-error" aria-label="Delete" onClick={() => confirm("Delete this record?") && del.mutate(r.id)}><Trash2 size={14} /></button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {list.data?.count != null && <Pager page={page} setPage={setPage} count={list.data.count} />}

      {editing && <CrudForm title={editing.id ? `Edit ${title}` : `New ${title}`} fields={fields} initial={editing} busy={save.isPending}
        onClose={() => setEditing(null)} onSubmit={(b) => save.mutate(prepare ? prepare(b) : b)} />}
    </>
  );
}

function CrudForm({ title, fields, initial, onSubmit, onClose, busy }) {
  const [v, setV] = useState(() => {
    const base = {};
    fields.forEach((f) => { base[f.name] = initial[f.name] ?? f.default ?? (f.type === "checkbox" ? false : ""); });
    return { ...base, id: initial.id };
  });
  const submit = (e) => {
    e.preventDefault();
    const body = { id: v.id };
    fields.forEach((f) => { if (!f.hidden?.(v)) body[f.name] = v[f.name] === "" ? null : v[f.name]; });
    onSubmit(body);
  };
  return (
    <Modal title={title} onClose={onClose}>
      <form onSubmit={submit} className="grid gap-2 sm:grid-cols-2">
        {fields.filter((f) => !f.hidden?.(v)).map((f) => (
          <div key={f.name} className={f.type === "textarea" ? "sm:col-span-2" : ""}>
            <Field f={f} value={v[f.name]} onChange={(val) => setV((s) => ({ ...s, [f.name]: val }))} />
          </div>
        ))}
        <div className="sm:col-span-2 modal-action">
          <button type="button" className="btn" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" disabled={busy}>{busy ? <span className="loading loading-spinner loading-sm" /> : "Save"}</button>
        </div>
      </form>
    </Modal>
  );
}
