import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { X, Inbox, ChevronLeft, ChevronRight } from "lucide-react";
import { api, rows } from "../api";

// ---- toasts (tiny pub/sub, no dependency)
let push = () => {};
export const toast = (msg, type = "success") => push({ msg, type, id: Math.random() });
export function Toaster() {
  const [items, setItems] = useState([]);
  useEffect(() => {
    push = (t) => {
      setItems((x) => [...x, t]);
      setTimeout(() => setItems((x) => x.filter((i) => i.id !== t.id)), 4500);
    };
  }, []);
  return (
    <div className="toast toast-end z-[100]">
      {items.map((t) => (
        <div key={t.id} className={`alert ${t.type === "error" ? "alert-error" : "alert-success"} max-w-sm text-sm`}>
          <span>{t.msg}</span>
        </div>
      ))}
    </div>
  );
}

export function Modal({ title, onClose, children, wide }) {
  return (
    <div className="modal modal-open" role="dialog" aria-modal="true" aria-label={title}>
      <div className={`modal-box ${wide ? "max-w-3xl" : ""}`}>
        <button className="btn btn-sm btn-circle btn-ghost absolute right-3 top-3" onClick={onClose} aria-label="Close">
          <X size={16} />
        </button>
        <h3 className="font-bold text-lg mb-4">{title}</h3>
        {children}
      </div>
      <div className="modal-backdrop" onClick={onClose} />
    </div>
  );
}

export const Spinner = () => (
  <div className="flex justify-center py-16">
    <span className="loading loading-spinner loading-lg text-primary" />
  </div>
);

export const Empty = ({ text = "Nothing here yet" }) => (
  <div className="flex flex-col items-center py-16 text-base-content/60 gap-2">
    <Inbox size={40} />
    <p>{text}</p>
  </div>
);

export const ErrorBox = ({ error }) => (
  <div className="alert alert-error my-4">
    <span>{error?.response?.data?.detail || error?.message || "Failed to load"}</span>
  </div>
);

const COLORS = {
  draft: "badge-ghost", quotation: "badge-info", confirmed: "badge-warning", active: "badge-success",
  closed: "badge-neutral", paid: "badge-success", cancelled: "badge-error", overdue: "badge-error",
};
export const Badge = ({ value }) => <span className={`badge ${COLORS[value] || "badge-ghost"} capitalize`}>{value}</span>;

export function Pager({ page, setPage, count, size = 25 }) {
  const pages = Math.max(1, Math.ceil(count / size));
  return (
    <div className="flex items-center justify-between mt-4 text-sm">
      <span className="text-base-content/60">{count.toLocaleString()} records</span>
      <div className="join">
        <button className="btn btn-sm join-item" disabled={page <= 1} onClick={() => setPage(page - 1)} aria-label="Previous page">
          <ChevronLeft size={16} />
        </button>
        <span className="btn btn-sm join-item pointer-events-none">{page} / {pages}</span>
        <button className="btn btn-sm join-item" disabled={page >= pages} onClick={() => setPage(page + 1)} aria-label="Next page">
          <ChevronRight size={16} />
        </button>
      </div>
    </div>
  );
}

export const PageHeader = ({ title, children, sub }) => (
  <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
    <div>
      <h1 className="text-2xl font-bold">{title}</h1>
      {sub && <p className="text-sm text-base-content/60">{sub}</p>}
    </div>
    <div className="flex flex-wrap gap-2">{children}</div>
  </div>
);

// ---- remote options for selects
export function useOptions(path, params = {}) {
  return useQuery({
    queryKey: ["options", path, params],
    queryFn: async () => rows((await api.get(path, { params: { page_size: 200, ...params } })).data),
    enabled: !!path,
    staleTime: 60000,
  });
}

export function Field({ f, value, onChange }) {
  const opts = useOptions(f.optionsFrom, f.optionsParams);
  const common = { className: "input input-bordered w-full", required: f.required, value: value ?? "" };
  let input;
  if (f.type === "checkbox")
    input = <input type="checkbox" className="toggle toggle-primary" checked={!!value} onChange={(e) => onChange(e.target.checked)} />;
  else if (f.type === "select" || f.optionsFrom) {
    const list = f.options || (opts.data || []).map((o) => ({ value: o.id, label: f.label_fn ? f.label_fn(o) : o[f.optionLabel || "name"] ?? o.email }));
    input = (
      <select className="select select-bordered w-full" required={f.required} value={value ?? ""} onChange={(e) => onChange(e.target.value)}>
        <option value="">{f.required ? "Select…" : "— none —"}</option>
        {list.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    );
  } else if (f.type === "textarea")
    input = <textarea {...common} className="textarea textarea-bordered w-full" onChange={(e) => onChange(e.target.value)} />;
  else
    input = <input {...common} type={f.type || "text"} step={f.type === "number" ? "0.01" : undefined} min={f.min} onChange={(e) => onChange(e.target.value)} />;
  return (
    <label className="form-control w-full">
      <div className="label"><span className="label-text font-medium">{f.label}</span></div>
      {input}
      {f.help && <div className="label"><span className="label-text-alt text-base-content/60">{f.help}</span></div>}
    </label>
  );
}
