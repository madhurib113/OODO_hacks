# Brightloop Subscription Management System

One platform for the whole subscription lifecycle: products and plans, quotations, subscriptions,
automatic recurring billing, discounts, taxes, payments and a finance dashboard.

**Stack:** Django 5 + Django REST Framework + JWT · React (Vite) + Tailwind + daisyUI + TanStack Query + Recharts ·
SQLite locally, PostgreSQL (Neon) in production · Swagger docs · Docker Compose.

## Run it (pick one)

### A. Docker, one command
```bash
docker compose up --build
```
App http://localhost:5173 · API docs http://localhost:8000/api/docs/ · it seeds 5,000 subscriptions on first start.

### B. Local dev
```bash
# backend
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
python manage.py migrate                                 # migrations are committed in core/migrations
python manage.py seed_demo --count 5000 --bill          # demo data + billing run + payments
python manage.py runserver

# frontend (second terminal)
cd frontend
cp .env.example .env
npm install && npm run dev                              # http://localhost:5173
```
Tests: `cd backend && python manage.py test`

Scheduled billing (cron / Render cron job): `python manage.py run_billing` (logged as a *scheduled* billing run).

API paths work with or without a trailing slash (`/api/add-ons` and `/api/add-ons/`).

**Demo logins:** `admin@brightloop.test / Admin@12345` · `staff@brightloop.test / Staff@12345` · `customer@brightloop.test / Customer@123`

## How each requirement is met

| Requirement | Where |
|---|---|
| Unique email, password >8 chars with upper, lower, special | `core/validators.py`, case-insensitive email check in `RegisterSerializer`, unique DB column |
| Password reset link by email | `/api/auth/password-reset/` + `/confirm/` (Django token generator); Resend HTTP API or console |
| Admin / Staff / Customer; only admin adds staff | `core/permissions.py`; `POST /api/auth/staff/` is admin-only; customer querysets are filtered to their own rows |
| Products, variants (Odoo +560), plans, flags | `Product`, `ProductVariant.extra_price`, `Plan(auto_close, closable, pausable, renewable)` |
| Quotation templates with validity | `QuotationTemplate` (reusable) + `POST /api/quotations/from-template/` |
| Standalone quotations | `Quotation` / `QuotationLine` (own numbers `QUO-000001`, `validity_days`, `valid_until`, `days_remaining`); `Draft → Sent → Converted / Cancelled`; `POST /api/quotations/{id}/convert/` creates a Confirmed subscription once, only while valid |
| Add-on catalogue | `AddOn` (name, price, active, `eligible_products`, `eligible_plans`; empty = no restriction) via `GET/POST /api/add-ons/` (admin writes, everyone reads, customers see active only; `?subscription=<id>` lists what that subscription may take) |
| Add-ons on subscriptions | `SubscriptionAddOn` (quantity, **price snapshot**, active flag, start/end date). `POST /api/subscriptions/{id}/add-ons/`, `PATCH /api/subscription-add-ons/{id}/`. Customers manage their own, staff manage any. Billed on every invoice they are effective for |
| Largest-saving discount | `services.resolve_discount()`: all eligible rules are evaluated, **only the one that saves the most is applied** (ties: lowest id; no stacking). The winner is stored on `Invoice.applied_discount` |
| Billing audit log | `BillingRun` + `BillingRunItem`, written by every `generate_invoices()` call: timestamp, trigger (manual / scheduled / seed), user, created / skipped / failed / closed counts, and a reason per subscription. `GET /api/billing-runs/`, `GET /api/billing-runs/{id}/items/?outcome=` (staff) |
| Subscription numbers and status flow | `SUB-000001`; `services.transition()` enforces Draft → Quotation → Confirmed → Active → Closed |
| Bulk invoice generation, automatic tax | `services.generate_invoices()`, `TaxRule` (product rules override general; same-level rules add up) |
| Never billed twice or skipped | DB `UniqueConstraint(subscription, period_start)` + existence check + cursor `next_invoice_date` advanced in the same transaction; backlog is caught up period by period |
| Invoice confirm / cancel / send / print, Draft → Confirmed → Paid | `/api/invoices/{id}/confirm|cancel|send|print/` |
| Discounts (fixed / %, minimums, dates, usage limit, product or subscription) | `Discount`; applied automatically at billing (largest-saving rule only, see above); usage claimed atomically so the limit cannot be exceeded; losing rules consume no usage |
| Payments with method, amount, date, note | `POST /api/payments/` (row-locked, cannot overpay); invoice flips to Paid when settled |
| Paid vs outstanding vs overdue | invoice filters `?status=paid`, `?outstanding=true`, `?overdue=true` |
| Finance dashboard with filters | `GET /api/dashboard/?date_from=&date_to=&customer=` |
| Every page under 2 s with thousands of rows | server-side pagination (25/page), `select_related`/`prefetch_related`, composite indexes, aggregate queries |
| API contract | Swagger at `/api/docs/` |

## Deploy on free tiers
1. **Neon**: create a project, copy the connection string into `DATABASE_URL`.
2. **Render** (web service, root `backend`): build `pip install -r requirements.txt && python manage.py collectstatic --noinput`,
   start `./start.sh`. Env: `SECRET_KEY`, `DEBUG=0`, `DATABASE_URL`, `ALLOWED_HOSTS=*`, `CORS_ALLOWED_ORIGINS=https://<your-vercel-app>`,
   `CSRF_TRUSTED_ORIGINS=https://<your-render-app>`, `FRONTEND_URL=https://<your-vercel-app>`,
   `SEED_DEMO=1`, `SEED_COUNT=5000` (seeds once; remove afterwards). Render's free tier sleeps: open it a few minutes before the demo.
3. **Vercel** (root `frontend`, framework Vite): env `VITE_API_URL=https://<your-render-app>/api`. Add a `vercel.json` rewrite if deep links 404:
   `{"rewrites":[{"source":"/(.*)","destination":"/"}]}`.
4. **Email**: create a Resend key, set `RESEND_API_KEY`. Resend's shared sender only delivers to your own address until you verify a domain,
   so for the demo use your own email as the customer or show the console log locally.

## Design notes and assumptions
* Money is `Decimal` everywhere, rounded half-up to 2 places per line.
* A cancelled invoice keeps its period slot (nothing is silently re-billed). Re-issue by creating a manual correction.
* Discounts reduce the taxable amount; tax is computed on the net.
* Customers can pause, resume, renew and close their own subscriptions where the plan allows it.
* The invoice number is assigned right after insert (`INV-000123`).
* **Discount policy.** Per invoice, every eligible rule (product or subscription scoped, thresholds, dates, usage left) is priced against the
  invoice's rows and the single biggest saving wins. If that rule's last use was taken by a concurrent run, the next best is tried.
* **Add-ons** are billed as their own invoice lines at the general tax rate. Subscription-scoped discounts cover them; product-scoped ones do not.
  Removing an add-on sets `is_active=false` and an end date of today, so it stops being billed from now on; history is kept.
* **Billing failures are isolated.** If one subscription raises an error it is logged as *failed* in the run, its billing cursor is not advanced
  (the next run retries it) and the rest of the run continues.
* **Quotations vs the subscription "quotation" status.** A `Quotation` is a separate offer that only becomes a subscription through `convert`.
  The older `Draft → Quotation → Confirmed` status path on `Subscription` and `POST /api/subscriptions/from-template/` still work and are unchanged.
* **Migrations** are committed (`backend/core/migrations/0001_initial.py`). If you change a model, run `python manage.py makemigrations core`.
