from django.contrib import admin

from . import models

for m in (models.User, models.Product, models.ProductVariant, models.Plan, models.QuotationTemplate,
          models.TaxRule, models.Discount, models.AddOn, models.Subscription, models.SubscriptionAddOn,
          models.Quotation, models.QuotationLine, models.Invoice, models.Payment, models.BillingRun,
          models.BillingRunItem):
    admin.site.register(m)
