import io
from datetime import date, timedelta
from decimal import Decimal

from django.core.exceptions import ValidationError as DjangoValidationError
from django.db import IntegrityError, transaction
from django.test import TestCase
from django.utils import timezone
from rest_framework.test import APIClient, APITestCase

from unittest.mock import patch

from django.core.management import call_command

from . import services
from .models import (AddOn, BillingRun, BillingRunItem, Discount, Invoice, Plan, Product, Quotation, QuotationLine,
                     QuotationTemplate, QuotationTemplateLine, Subscription, SubscriptionAddOn, SubscriptionLine,
                     TaxRule, User)
from .validators import BrightloopPasswordValidator


def make_sub(customer, plan, product, qty=2, price="1000", start=date(2026, 1, 1), status="active", **kw):
    sub = Subscription.objects.create(customer=customer, plan=plan, status=status, start_date=start,
                                      next_invoice_date=start if status == "active" else None, **kw)
    SubscriptionLine.objects.create(subscription=sub, product=product, quantity=qty, unit_price=Decimal(price))
    return sub


class Base(TestCase):
    def setUp(self):
        self.admin = User.objects.create_superuser("admin@t.io", "Admin@12345")
        self.staff = User.objects.create_user("staff@t.io", "Staff@12345", role="staff")
        self.cust = User.objects.create_user("c1@t.io", "Cust@12345")
        self.cust2 = User.objects.create_user("c2@t.io", "Cust@12345")
        self.product = Product.objects.create(name="CRM", sales_price=1000)
        self.plan = Plan.objects.create(name="Monthly", price=1000, billing_period="monthly", pausable=True, auto_close=True)
        TaxRule.objects.create(name="GST", rate=Decimal("18"))


class PasswordTests(TestCase):
    def test_rules(self):
        v = BrightloopPasswordValidator()
        for bad in ["Short1!a", "alllowercase1!", "ALLUPPERCASE1!", "NoSpecial123"]:
            with self.assertRaises(DjangoValidationError, msg=bad):
                v.validate(bad)
        v.validate("Goodpass1!")


class DateTests(TestCase):
    def test_month_end(self):
        self.assertEqual(services.add_months(date(2026, 1, 31), 1), date(2026, 2, 28))
        self.assertEqual(services.add_period(date(2026, 3, 1), "weekly"), date(2026, 3, 8))
        self.assertEqual(services.add_period(date(2026, 3, 1), "yearly"), date(2027, 3, 1))


class BillingTests(Base):
    def test_invoice_has_tax_and_totals(self):
        sub = make_sub(self.cust, self.plan, self.product)
        res = services.generate_invoices(as_of=date(2026, 1, 1))
        self.assertEqual(res["created"], 1)
        inv = Invoice.objects.get()
        self.assertEqual((inv.subtotal, inv.tax_total, inv.total), (Decimal("2000"), Decimal("360"), Decimal("2360")))
        self.assertEqual(inv.status, "draft")
        self.assertTrue(inv.number.startswith("INV-"))
        sub.refresh_from_db()
        self.assertEqual(sub.next_invoice_date, date(2026, 2, 1))

    def test_idempotent(self):
        make_sub(self.cust, self.plan, self.product)
        services.generate_invoices(as_of=date(2026, 1, 15))
        again = services.generate_invoices(as_of=date(2026, 1, 15))
        self.assertEqual(again["created"], 0)
        self.assertEqual(Invoice.objects.count(), 1)

    def test_backlog_catches_up_without_gaps(self):
        make_sub(self.cust, self.plan, self.product)
        services.generate_invoices(as_of=date(2026, 3, 15))
        starts = list(Invoice.objects.order_by("period_start").values_list("period_start", flat=True))
        self.assertEqual(starts, [date(2026, 1, 1), date(2026, 2, 1), date(2026, 3, 1)])

    def test_db_constraint_blocks_duplicates(self):
        sub = make_sub(self.cust, self.plan, self.product)
        services.generate_invoices(as_of=date(2026, 1, 1))
        with self.assertRaises(IntegrityError), transaction.atomic():
            Invoice.objects.create(subscription=sub, customer=self.cust, period_start=date(2026, 1, 1),
                                   period_end=date(2026, 1, 31), due_date=date(2026, 2, 15))

    def test_paused_and_inactive_not_billed(self):
        make_sub(self.cust, self.plan, self.product, is_paused=True)
        make_sub(self.cust2, self.plan, self.product, status="draft")
        self.assertEqual(services.generate_invoices(as_of=date(2026, 6, 1))["created"], 0)

    def test_percent_discount_applies_before_tax(self):
        Discount.objects.create(name="10%", kind="percent", value=10, apply_to="subscription")
        make_sub(self.cust, self.plan, self.product)
        services.generate_invoices(as_of=date(2026, 1, 1))
        inv = Invoice.objects.get()
        # 2000 - 200 = 1800, tax 324, total 2124
        self.assertEqual((inv.discount_total, inv.tax_total, inv.total), (Decimal("200"), Decimal("324"), Decimal("2124")))

    def test_discount_usage_limit_stops_it(self):
        d = Discount.objects.create(name="One shot", kind="fixed", value=100, usage_limit=1)
        make_sub(self.cust, self.plan, self.product)
        make_sub(self.cust2, self.plan, self.product)
        services.generate_invoices(as_of=date(2026, 1, 1))
        d.refresh_from_db()
        self.assertEqual(d.times_used, 1)
        self.assertEqual(Invoice.objects.filter(discount_total__gt=0).count(), 1)

    def test_expired_discount_ignored_and_min_quantity(self):
        Discount.objects.create(name="Old", kind="percent", value=50, end_date=date(2025, 12, 31))
        Discount.objects.create(name="Bulk", kind="percent", value=50, min_quantity=10)
        make_sub(self.cust, self.plan, self.product)
        services.generate_invoices(as_of=date(2026, 1, 1))
        self.assertEqual(Invoice.objects.get().discount_total, 0)

    def test_product_discount_only_hits_that_product(self):
        other = Product.objects.create(name="Add-on", sales_price=100)
        Discount.objects.create(name="CRM 50%", kind="percent", value=50, apply_to="product", product=self.product)
        sub = make_sub(self.cust, self.plan, self.product, qty=1)
        SubscriptionLine.objects.create(subscription=sub, product=other, quantity=1, unit_price=Decimal("100"))
        services.generate_invoices(as_of=date(2026, 1, 1))
        self.assertEqual(Invoice.objects.get().discount_total, Decimal("500"))

    def test_auto_close_after_expiry(self):
        sub = make_sub(self.cust, self.plan, self.product, expiry_date=date(2026, 1, 31))
        services.generate_invoices(as_of=date(2026, 3, 1))
        sub.refresh_from_db()
        self.assertEqual(sub.status, "closed")
        self.assertEqual(Invoice.objects.count(), 1)  # nothing billed after expiry


class LifecycleTests(Base):
    def test_valid_and_invalid_transitions(self):
        sub = make_sub(self.cust, self.plan, self.product, status="draft", quotation_valid_until=None)
        services.transition(sub, "quotation")
        services.transition(sub, "confirmed")
        services.transition(sub, "active")
        self.assertEqual(sub.next_invoice_date, sub.start_date)
        with self.assertRaises(Exception):
            services.transition(sub, "draft")


class ApiTests(APITestCase):
    def setUp(self):
        self.admin = User.objects.create_superuser("admin@t.io", "Admin@12345")
        self.staff = User.objects.create_user("staff@t.io", "Staff@12345", role="staff")
        self.c1 = User.objects.create_user("c1@t.io", "Cust@12345")
        self.c2 = User.objects.create_user("c2@t.io", "Cust@12345")
        self.product = Product.objects.create(name="CRM", sales_price=1000)
        self.plan = Plan.objects.create(name="Monthly", price=1000, billing_period="monthly")
        TaxRule.objects.create(name="GST", rate=Decimal("18"))

    def as_user(self, user):
        c = APIClient()
        c.force_authenticate(user)
        return c

    def test_register_validation_and_unique_email(self):
        c = APIClient()
        self.assertEqual(c.post("/api/auth/register/", {"email": "n@t.io", "password": "weak"}).status_code, 400)
        ok = c.post("/api/auth/register/", {"email": "n@t.io", "password": "Strong#Pass1"})
        self.assertEqual(ok.status_code, 201)
        dup = c.post("/api/auth/register/", {"email": "N@T.io", "password": "Strong#Pass1"})
        self.assertEqual(dup.status_code, 400)

    def test_login_with_email(self):
        r = APIClient().post("/api/auth/login/", {"email": "c1@t.io", "password": "Cust@12345"})
        self.assertEqual(r.status_code, 200)
        self.assertIn("access", r.data)

    def test_only_admin_creates_staff_and_discounts(self):
        body = {"email": "s2@t.io", "password": "Staff#Pass12"}
        self.assertEqual(self.as_user(self.staff).post("/api/auth/staff/", body).status_code, 403)
        self.assertEqual(self.as_user(self.c1).post("/api/auth/staff/", body).status_code, 403)
        self.assertEqual(self.as_user(self.admin).post("/api/auth/staff/", body).status_code, 201)
        d = {"name": "X", "kind": "percent", "value": "5", "apply_to": "subscription"}
        self.assertEqual(self.as_user(self.staff).post("/api/discounts/", d).status_code, 403)
        self.assertEqual(self.as_user(self.admin).post("/api/discounts/", d).status_code, 201)

    def test_customer_sees_only_own_data(self):
        make_sub(self.c1, self.plan, self.product)
        make_sub(self.c2, self.plan, self.product)
        services.generate_invoices(as_of=date(2026, 1, 1))
        c = self.as_user(self.c1)
        self.assertEqual(c.get("/api/subscriptions/").data["count"], 1)
        self.assertEqual(c.get("/api/invoices/").data["count"], 1)
        other = Invoice.objects.get(customer=self.c2)
        self.assertEqual(c.get(f"/api/invoices/{other.pk}/").status_code, 404)
        self.assertEqual(c.get("/api/dashboard/").status_code, 403)

    def test_payment_flow_partial_then_paid(self):
        make_sub(self.c1, self.plan, self.product, qty=1)
        services.generate_invoices(as_of=date(2026, 1, 1))
        inv = Invoice.objects.get()  # total 1180
        staff = self.as_user(self.staff)
        pay = {"invoice": inv.pk, "method": "upi", "amount": "500", "date": "2026-01-05", "note": "part"}
        self.assertEqual(staff.post("/api/payments/", pay).status_code, 400)  # still draft
        self.assertEqual(staff.post(f"/api/invoices/{inv.pk}/confirm/").status_code, 200)
        self.assertEqual(staff.post("/api/payments/", pay).status_code, 201)
        inv.refresh_from_db()
        self.assertEqual((inv.status, inv.outstanding), ("confirmed", Decimal("680")))
        self.assertEqual(staff.post("/api/payments/", {**pay, "amount": "9999"}).status_code, 400)
        self.assertEqual(staff.post("/api/payments/", {**pay, "amount": "680"}).status_code, 201)
        inv.refresh_from_db()
        self.assertEqual(inv.status, "paid")

    def test_create_subscription_with_variant_pricing_and_dashboard(self):
        from .models import ProductVariant
        v = ProductVariant.objects.create(product=self.product, attribute="Brand", value="Odoo", extra_price=560)
        r = self.as_user(self.staff).post("/api/subscriptions/", {
            "customer": self.c1.pk, "plan": self.plan.pk, "start_date": "2026-01-01",
            "lines": [{"product": self.product.pk, "variant": v.pk, "quantity": 3}]}, format="json")
        self.assertEqual(r.status_code, 201, r.data)
        self.assertEqual(r.data["lines"][0]["unit_price"], "1560.00")
        self.assertTrue(r.data["number"].startswith("SUB-"))
        self.assertEqual(r.data["status"], "draft")
        d = self.as_user(self.staff).get("/api/dashboard/")
        self.assertEqual(d.status_code, 200)
        self.assertIn("overdue_count", d.data)

    def test_password_reset_flow(self):
        from django.contrib.auth.tokens import default_token_generator
        from django.utils.encoding import force_bytes
        from django.utils.http import urlsafe_base64_encode
        c = APIClient()
        self.assertEqual(c.post("/api/auth/password-reset/", {"email": "c1@t.io"}).status_code, 200)
        self.assertEqual(c.post("/api/auth/password-reset/", {"email": "nobody@t.io"}).status_code, 200)
        uid = urlsafe_base64_encode(force_bytes(self.c1.pk))
        token = default_token_generator.make_token(self.c1)
        bad = c.post("/api/auth/password-reset/confirm/", {"uid": uid, "token": token, "password": "weak"})
        self.assertEqual(bad.status_code, 400)
        ok = c.post("/api/auth/password-reset/confirm/", {"uid": uid, "token": token, "password": "Brand#New123"})
        self.assertEqual(ok.status_code, 200)


# =====================================================================================================
# Largest-saving discount policy
# =====================================================================================================
class DiscountPolicyTests(Base):
    """Base sub: 2 x 1000 = 2000 before tax. Eligible rules compete; only the biggest saving is applied."""

    def bill(self):
        sub = make_sub(self.cust, self.plan, self.product)
        services.generate_invoices(as_of=date(2026, 1, 1))
        return Invoice.objects.get(subscription=sub)

    def test_only_the_largest_saving_applies_and_nothing_stacks(self):
        Discount.objects.create(name="10%", kind="percent", value=10)                      # saves 200
        Discount.objects.create(name="Flat 500", kind="fixed", value=500)                  # saves 500  <- winner
        Discount.objects.create(name="CRM 5%", kind="percent", value=5, apply_to="product", product=self.product)  # 100
        inv = self.bill()
        self.assertEqual(inv.discount_total, Decimal("500"))          # not 800
        self.assertEqual(inv.applied_discount.name, "Flat 500")
        self.assertEqual((inv.tax_total, inv.total), (Decimal("270"), Decimal("1770")))  # tax on 2000 - 500
        self.assertEqual(dict(Discount.objects.values_list("name", "times_used")),
                         {"10%": 0, "Flat 500": 1, "CRM 5%": 0})       # losers consume no usage

    def test_percentage_can_beat_fixed(self):
        Discount.objects.create(name="Flat 500", kind="fixed", value=500)
        Discount.objects.create(name="50%", kind="percent", value=50)                      # saves 1000
        inv = self.bill()
        self.assertEqual((inv.discount_total, inv.applied_discount.name), (Decimal("1000"), "50%"))

    def test_product_rule_competes_with_subscription_rule(self):
        Discount.objects.create(name="Sub 10%", kind="percent", value=10)                  # 200
        Discount.objects.create(name="CRM 50%", kind="percent", value=50, apply_to="product", product=self.product)  # 1000
        inv = self.bill()
        self.assertEqual((inv.discount_total, inv.applied_discount.name), (Decimal("1000"), "CRM 50%"))

    def test_ineligible_rules_do_not_compete(self):
        Discount.objects.create(name="Huge but needs 10 seats", kind="percent", value=90, min_quantity=10)
        Discount.objects.create(name="Huge but needs 99999", kind="percent", value=90, min_amount=99999)
        Discount.objects.create(name="Huge but expired", kind="percent", value=90, end_date=date(2025, 1, 1))
        Discount.objects.create(name="Huge but off", kind="percent", value=90, is_active=False)
        Discount.objects.create(name="Small", kind="fixed", value=100)
        inv = self.bill()
        self.assertEqual((inv.discount_total, inv.applied_discount.name), (Decimal("100"), "Small"))

    def test_tie_goes_to_lowest_id(self):
        a = Discount.objects.create(name="A", kind="fixed", value=100)
        b = Discount.objects.create(name="B", kind="fixed", value=100)
        inv = self.bill()
        a.refresh_from_db(); b.refresh_from_db()
        self.assertEqual(inv.applied_discount_id, a.id)
        self.assertEqual((a.times_used, b.times_used), (1, 0))

    def test_falls_back_to_next_best_if_winner_was_used_up_concurrently(self):
        Discount.objects.create(name="Big", kind="fixed", value=500)
        Discount.objects.create(name="Small", kind="fixed", value=100)
        with patch.object(services, "_claim_discount", side_effect=lambda d: d.name != "Big"):
            inv = self.bill()
        self.assertEqual((inv.discount_total, inv.applied_discount.name), (Decimal("100"), "Small"))

    def test_no_discount_means_no_applied_rule(self):
        inv = self.bill()
        self.assertEqual((inv.discount_total, inv.applied_discount), (Decimal("0"), None))

    def test_discount_never_exceeds_the_amount(self):
        Discount.objects.create(name="Giant", kind="fixed", value=99999)
        inv = self.bill()
        self.assertEqual((inv.discount_total, inv.total), (Decimal("2000"), Decimal("0")))


# =====================================================================================================
# Add-ons in billing
# =====================================================================================================
class AddOnBillingTests(Base):
    def setUp(self):
        super().setUp()
        self.support = AddOn.objects.create(name="Priority Support", price=250)
        self.sub = make_sub(self.cust, self.plan, self.product)  # 2 x 1000

    def attach(self, qty=2, **kw):
        return SubscriptionAddOn.objects.create(subscription=self.sub, add_on=self.support, quantity=qty,
                                                unit_price=self.support.price, start_date=date(2025, 1, 1), **kw)

    def bill(self):
        services.generate_invoices(as_of=date(2026, 1, 1))
        return Invoice.objects.get(subscription=self.sub)

    def test_add_on_is_billed_with_general_tax(self):
        self.attach(qty=2)  # 500
        inv = self.bill()
        self.assertEqual((inv.subtotal, inv.tax_total, inv.total), (Decimal("2500"), Decimal("450"), Decimal("2950")))
        self.assertEqual(sorted(inv.lines.values_list("description", flat=True)), ["Add-on: Priority Support", "CRM"])

    def test_inactive_or_ended_add_on_is_not_billed(self):
        self.attach(is_active=False)
        self.attach(end_date=date(2025, 12, 31))
        inv = self.bill()
        self.assertEqual(inv.subtotal, Decimal("2000"))

    def test_add_on_starting_after_the_period_is_not_billed(self):
        SubscriptionAddOn.objects.create(subscription=self.sub, add_on=self.support, quantity=1,
                                         unit_price=250, start_date=date(2026, 2, 1))
        self.assertEqual(self.bill().subtotal, Decimal("2000"))

    def test_price_snapshot_survives_catalogue_price_change(self):
        self.attach(qty=1)
        self.support.price = Decimal("999")
        self.support.save()
        self.assertEqual(self.bill().subtotal, Decimal("2250"))

    def test_subscription_discount_covers_add_ons_but_product_discount_does_not(self):
        self.attach(qty=2)  # 500
        Discount.objects.create(name="Sub 10%", kind="percent", value=10)
        inv = self.bill()
        self.assertEqual(inv.discount_total, Decimal("250"))  # 10% of 2500
        Invoice.objects.all().delete()
        Discount.objects.all().delete()
        Subscription.objects.filter(pk=self.sub.pk).update(next_invoice_date=date(2026, 1, 1))
        Discount.objects.create(name="CRM 50%", kind="percent", value=50, apply_to="product", product=self.product)
        self.assertEqual(self.bill().discount_total, Decimal("1000"))  # CRM line only


# =====================================================================================================
# Billing run audit log
# =====================================================================================================
class BillingRunTests(Base):
    def test_every_run_is_persisted_with_counts_and_items(self):
        a = make_sub(self.cust, self.plan, self.product)
        b = make_sub(self.cust2, self.plan, self.product)
        res = services.generate_invoices(as_of=date(2026, 1, 1))
        run = BillingRun.objects.get()
        self.assertEqual(res["run_id"], run.pk)
        self.assertEqual((run.status, run.trigger, run.as_of), ("completed", "manual", date(2026, 1, 1)))
        self.assertEqual((run.created_count, run.skipped_count, run.failed_count), (2, 0, 0))
        self.assertIsNotNone(run.finished_at)
        items = list(run.items.order_by("subscription_id"))
        self.assertEqual([i.subscription_id for i in items], [a.pk, b.pk])
        for i in items:
            self.assertEqual((i.outcome, i.period_start), ("created", date(2026, 1, 1)))
            self.assertIsNotNone(i.invoice_id)
            self.assertIn(i.invoice.number, i.reason)

    def test_empty_run_is_still_logged(self):
        services.generate_invoices(as_of=date(2026, 1, 1))
        self.assertEqual(BillingRun.objects.count(), 1)
        self.assertEqual(BillingRunItem.objects.count(), 0)

    def test_rerun_logs_skipped_with_reason_and_creates_nothing(self):
        sub = make_sub(self.cust, self.plan, self.product)
        services.generate_invoices(as_of=date(2026, 1, 1))
        Subscription.objects.filter(pk=sub.pk).update(next_invoice_date=date(2026, 1, 1))  # simulate a lost cursor
        res = services.generate_invoices(as_of=date(2026, 1, 1))
        self.assertEqual((res["created"], res["skipped"]), (0, 1))
        self.assertEqual(Invoice.objects.count(), 1)
        run2 = BillingRun.objects.first()
        item = run2.items.get()
        self.assertEqual((item.outcome, run2.skipped_count), ("skipped", 1))
        self.assertIn("already exists", item.reason)

    def test_paused_subscription_is_logged_as_skipped(self):
        sub = make_sub(self.cust, self.plan, self.product, is_paused=True)
        res = services.generate_invoices(as_of=date(2026, 1, 1))
        self.assertEqual((res["created"], res["skipped"]), (0, 1))
        item = BillingRunItem.objects.get()
        self.assertEqual((item.subscription_id, item.outcome, item.reason), (sub.pk, "skipped", "Subscription is paused"))

    def test_backlog_logs_one_item_per_period(self):
        make_sub(self.cust, self.plan, self.product)
        services.generate_invoices(as_of=date(2026, 3, 15))
        run = BillingRun.objects.get()
        self.assertEqual(run.created_count, 3)
        self.assertEqual(list(run.items.order_by("id").values_list("period_start", flat=True)),
                         [date(2026, 1, 1), date(2026, 2, 1), date(2026, 3, 1)])

    def test_one_failure_is_recorded_and_does_not_stop_the_run(self):
        bad = make_sub(self.cust, self.plan, self.product)
        good = make_sub(self.cust2, self.plan, self.product)
        real = services._bill_period

        def flaky(sub, *a, **k):
            if sub.pk == bad.pk:
                raise RuntimeError("boom")
            return real(sub, *a, **k)

        with patch.object(services, "_bill_period", side_effect=flaky):
            res = services.generate_invoices(as_of=date(2026, 1, 1))
        self.assertEqual((res["created"], res["failed"]), (1, 1))
        run = BillingRun.objects.get()
        self.assertEqual((run.status, run.created_count, run.failed_count), ("completed", 1, 1))
        failed = run.items.get(outcome="failed")
        self.assertEqual(failed.subscription_id, bad.pk)
        self.assertIn("boom", failed.reason)
        bad.refresh_from_db()
        self.assertEqual(bad.next_invoice_date, date(2026, 1, 1))     # cursor untouched: next run retries
        self.assertFalse(Invoice.objects.filter(subscription=bad).exists())
        self.assertTrue(Invoice.objects.filter(subscription=good).exists())
        # ...and the retry succeeds once the problem is gone
        services.generate_invoices(as_of=date(2026, 1, 1))
        self.assertTrue(Invoice.objects.filter(subscription=bad).exists())

    def test_scheduled_command_records_its_trigger(self):
        make_sub(self.cust, self.plan, self.product)
        call_command("run_billing", "--as-of", "2026-01-01", stdout=io.StringIO())
        run = BillingRun.objects.get()
        self.assertEqual((run.trigger, run.created_count), ("scheduled", 1))

    def test_api_run_records_user_and_exposes_log_to_staff_only(self):
        make_sub(self.cust, self.plan, self.product)
        staff, cust = APIClient(), APIClient()
        staff.force_authenticate(self.staff)
        cust.force_authenticate(self.cust)
        r = staff.post("/api/invoices/generate/", {"as_of": "2026-01-01"}, format="json")
        self.assertEqual((r.status_code, r.data["created"]), (200, 1))
        run = BillingRun.objects.get()
        self.assertEqual((run.triggered_by_id, run.trigger), (self.staff.pk, "manual"))
        lst = staff.get("/api/billing-runs/")
        self.assertEqual((lst.status_code, lst.data["count"]), (200, 1))
        self.assertEqual(lst.data["results"][0]["triggered_by_email"], "staff@t.io")
        items = staff.get(f"/api/billing-runs/{run.pk}/items/?outcome=created")
        self.assertEqual((items.status_code, items.data["count"]), (200, 1))
        self.assertEqual(staff.get(f"/api/billing-runs/{run.pk}/items/?outcome=failed").data["count"], 0)
        self.assertEqual(cust.get("/api/billing-runs/").status_code, 403)
        self.assertEqual(cust.post("/api/invoices/generate/", {}, format="json").status_code, 403)


# =====================================================================================================
# Add-on catalogue + subscription add-on API
# =====================================================================================================
class AddOnApiTests(APITestCase):
    def setUp(self):
        self.admin = User.objects.create_superuser("admin@t.io", "Admin@12345")
        self.staff = User.objects.create_user("staff@t.io", "Staff@12345", role="staff")
        self.c1 = User.objects.create_user("c1@t.io", "Cust@12345")
        self.c2 = User.objects.create_user("c2@t.io", "Cust@12345")
        self.product = Product.objects.create(name="CRM", sales_price=1000)
        self.other_product = Product.objects.create(name="Books", sales_price=900)
        self.monthly = Plan.objects.create(name="Monthly", price=1000, billing_period="monthly")
        self.yearly = Plan.objects.create(name="Yearly", price=9000, billing_period="yearly")
        self.sub = make_sub(self.c1, self.monthly, self.product, qty=1, start=date(2026, 1, 1))
        self.sub2 = make_sub(self.c2, self.monthly, self.product, qty=1, start=date(2026, 1, 1))
        self.support = AddOn.objects.create(name="Support", price=250)
        self.yearly_only = AddOn.objects.create(name="Yearly only", price=100)
        self.yearly_only.eligible_plans.set([self.yearly])
        self.books_only = AddOn.objects.create(name="Books only", price=100)
        self.books_only.eligible_products.set([self.other_product])
        self.retired = AddOn.objects.create(name="Retired", price=50, is_active=False)

    def as_user(self, user):
        c = APIClient()
        c.force_authenticate(user)
        return c

    # ---- catalogue
    def test_catalogue_permissions(self):
        body = {"name": "Extra seats", "price": "75.00", "eligible_plans": [self.monthly.pk]}
        self.assertEqual(self.as_user(self.staff).post("/api/add-ons/", body, format="json").status_code, 403)
        self.assertEqual(self.as_user(self.c1).post("/api/add-ons/", body, format="json").status_code, 403)
        r = self.as_user(self.admin).post("/api/add-ons/", body, format="json")
        self.assertEqual(r.status_code, 201, r.data)
        self.assertEqual(r.data["eligible_plan_names"], ["Monthly"])
        # works without a trailing slash too (the spec writes it that way)
        self.assertEqual(self.as_user(self.admin).post("/api/add-ons", {**body, "name": "B"}, format="json").status_code, 201)

    def test_customers_only_see_active_add_ons_staff_see_all(self):
        names = lambda u: {a["name"] for a in self.as_user(u).get("/api/add-ons/").data["results"]}
        self.assertNotIn("Retired", names(self.c1))
        self.assertIn("Retired", names(self.staff))

    def test_eligible_filter_for_a_subscription(self):
        r = self.as_user(self.c1).get(f"/api/add-ons/?subscription={self.sub.pk}")
        self.assertEqual({a["name"] for a in r.data["results"]}, {"Support"})
        # a customer cannot probe another customer's subscription
        self.assertEqual(self.as_user(self.c1).get(f"/api/add-ons/?subscription={self.sub2.pk}").data["count"], 0)

    # ---- attaching
    def test_attach_snapshots_price_and_blocks_duplicates(self):
        c = self.as_user(self.staff)
        r = c.post(f"/api/subscriptions/{self.sub.pk}/add-ons/", {"add_on": self.support.pk, "quantity": 3}, format="json")
        self.assertEqual(r.status_code, 201, r.data)
        self.assertEqual((r.data["unit_price"], r.data["amount"], r.data["is_active"]), ("250.00", "750.00", True))
        self.support.price = Decimal("999"); self.support.save()
        self.assertEqual(SubscriptionAddOn.objects.get().unit_price, Decimal("250"))
        again = c.post(f"/api/subscriptions/{self.sub.pk}/add-ons/", {"add_on": self.support.pk}, format="json")
        self.assertEqual(again.status_code, 400)
        no_slash = c.post(f"/api/subscriptions/{self.sub2.pk}/add-ons", {"add_on": self.support.pk}, format="json")
        self.assertEqual(no_slash.status_code, 201)

    def test_ineligible_inactive_and_closed_are_rejected(self):
        c = self.as_user(self.staff)
        url = f"/api/subscriptions/{self.sub.pk}/add-ons/"
        for bad in (self.yearly_only, self.books_only, self.retired):
            self.assertEqual(c.post(url, {"add_on": bad.pk}, format="json").status_code, 400, bad.name)
        self.assertEqual(c.post(url, {"add_on": self.support.pk, "quantity": 0}, format="json").status_code, 400)
        Subscription.objects.filter(pk=self.sub.pk).update(status="closed")
        self.assertEqual(c.post(url, {"add_on": self.support.pk}, format="json").status_code, 400)

    def test_customer_manages_own_add_ons_only(self):
        c1 = self.as_user(self.c1)
        r = c1.post(f"/api/subscriptions/{self.sub.pk}/add-ons/", {"add_on": self.support.pk}, format="json")
        self.assertEqual(r.status_code, 201)
        self.assertEqual(c1.post(f"/api/subscriptions/{self.sub2.pk}/add-ons/", {"add_on": self.support.pk}, format="json").status_code, 404)
        sa_id = r.data["id"]
        self.assertEqual(self.as_user(self.c2).patch(f"/api/subscription-add-ons/{sa_id}/", {"quantity": 9}, format="json").status_code, 404)
        self.assertEqual(c1.get("/api/subscription-add-ons/").data["count"], 1)
        self.assertEqual(self.as_user(self.c2).get("/api/subscription-add-ons/").data["count"], 0)

    # ---- updating
    def test_patch_quantity_deactivate_and_reactivate(self):
        sa = services.attach_add_on(self.sub, self.support, 1)
        c = self.as_user(self.c1)
        url = f"/api/subscription-add-ons/{sa.pk}/"
        r = c.patch(url, {"quantity": 4, "unit_price": "1.00"}, format="json")  # price is not editable
        self.assertEqual((r.status_code, r.data["quantity"], r.data["unit_price"]), (200, 4, "250.00"))
        self.assertEqual(c.patch(url, {"quantity": 0}, format="json").status_code, 400)
        off = c.patch(url, {"is_active": False}, format="json")
        self.assertEqual(off.data["is_active"], False)
        self.assertEqual(off.data["end_date"], timezone.localdate().isoformat())  # deactivating stops billing from today
        on = c.patch(url, {"is_active": True}, format="json")
        self.assertEqual((on.data["is_active"], on.data["end_date"]), (True, None))
        self.assertEqual(c.delete(url).status_code, 405)

    def test_subscription_payload_lists_add_ons_and_includes_them_in_total(self):
        services.attach_add_on(self.sub, self.support, 2)  # +500 on a 1000 line
        r = self.as_user(self.staff).get(f"/api/subscriptions/{self.sub.pk}/")
        self.assertEqual(len(r.data["add_ons"]), 1)
        self.assertEqual(r.data["total"], "1500.00")
        self.assertEqual(len(self.as_user(self.staff).get(f"/api/subscriptions/{self.sub.pk}/add-ons/").data), 1)


# =====================================================================================================
# Standalone quotations
# =====================================================================================================
class QuotationApiTests(APITestCase):
    def setUp(self):
        self.admin = User.objects.create_superuser("admin@t.io", "Admin@12345")
        self.staff = User.objects.create_user("staff@t.io", "Staff@12345", role="staff")
        self.c1 = User.objects.create_user("c1@t.io", "Cust@12345")
        self.c2 = User.objects.create_user("c2@t.io", "Cust@12345")
        self.product = Product.objects.create(name="CRM", sales_price=1000)
        self.plan = Plan.objects.create(name="Monthly", price=1000, billing_period="monthly")
        self.today = date.today()

    def as_user(self, user):
        c = APIClient()
        c.force_authenticate(user)
        return c

    def make(self, status="sent", customer=None, **kw):
        kw.setdefault("start_date", self.today + timedelta(days=7))
        q = Quotation.objects.create(customer=customer or self.c1, plan=self.plan, status=status, **kw)
        QuotationLine.objects.create(quotation=q, product=self.product, quantity=3, unit_price=Decimal("1000"))
        return q

    def test_staff_creates_draft_with_validity_tracking(self):
        r = self.as_user(self.staff).post("/api/quotations/", {
            "customer": self.c1.pk, "plan": self.plan.pk, "start_date": "2099-01-01", "validity_days": 14,
            "lines": [{"product": self.product.pk, "quantity": 2}]}, format="json")
        self.assertEqual(r.status_code, 201, r.data)
        self.assertTrue(r.data["number"].startswith("QUO-"))
        self.assertEqual((r.data["status"], r.data["total"], r.data["validity_days"]), ("draft", "2000.00", 14))
        self.assertEqual(r.data["valid_until"], (self.today + timedelta(days=14)).isoformat())
        self.assertEqual((r.data["days_remaining"], r.data["is_expired"]), (14, False))
        self.assertEqual(Subscription.objects.count(), 0)  # a quotation is not a subscription

    def test_customer_cannot_create_and_never_sees_drafts_or_others(self):
        body = {"customer": self.c1.pk, "plan": self.plan.pk, "start_date": "2099-01-01"}
        self.assertEqual(self.as_user(self.c1).post("/api/quotations/", body, format="json").status_code, 403)
        draft, sent, other = self.make("draft"), self.make("sent"), self.make("sent", customer=self.c2)
        c = self.as_user(self.c1)
        self.assertEqual([q["id"] for q in c.get("/api/quotations/").data["results"]], [sent.pk])
        self.assertEqual(c.get(f"/api/quotations/{draft.pk}/").status_code, 404)
        self.assertEqual(c.get(f"/api/quotations/{other.pk}/").status_code, 404)

    def test_send_then_convert_creates_confirmed_subscription(self):
        q = self.make("draft")
        self.assertEqual(self.as_user(self.staff).post(f"/api/quotations/{q.pk}/send/").data["status"], "sent")
        r = self.as_user(self.c1).post(f"/api/quotations/{q.pk}/convert/")
        self.assertEqual(r.status_code, 201, r.data)
        sub = Subscription.objects.get()
        self.assertEqual((sub.status, sub.customer_id, sub.plan_id, sub.start_date), ("confirmed", self.c1.pk, self.plan.pk, q.start_date))
        self.assertEqual(sub.quotation_valid_until, q.valid_until)
        line = sub.lines.get()
        self.assertEqual((line.product_id, line.quantity, line.unit_price), (self.product.pk, 3, Decimal("1000")))
        q.refresh_from_db()
        self.assertEqual((q.status, q.subscription_id), ("converted", sub.pk))
        self.assertIsNotNone(q.converted_at)
        self.assertEqual(r.data["quotation"]["status"], "converted")
        self.assertEqual(r.data["subscription"]["status"], "confirmed")
        self.assertEqual(r.data["quotation"]["subscription_number"], sub.number)

    def test_convert_works_without_trailing_slash_and_only_once(self):
        q = self.make("sent")
        c = self.as_user(self.staff)
        self.assertEqual(c.post(f"/api/quotations/{q.pk}/convert").status_code, 201)
        self.assertEqual(c.post(f"/api/quotations/{q.pk}/convert/").status_code, 400)
        self.assertEqual(Subscription.objects.count(), 1)

    def test_expired_and_cancelled_quotations_cannot_be_converted(self):
        old = self.make("sent", issue_date=self.today - timedelta(days=60), validity_days=30)
        self.assertTrue(Quotation.objects.get(pk=old.pk).is_expired)
        r = self.as_user(self.staff).post(f"/api/quotations/{old.pk}/convert/")
        self.assertEqual(r.status_code, 400)
        self.assertIn("expired", str(r.data).lower())
        cancelled = self.make("sent")
        self.as_user(self.staff).post(f"/api/quotations/{cancelled.pk}/cancel/")
        self.assertEqual(self.as_user(self.staff).post(f"/api/quotations/{cancelled.pk}/convert/").status_code, 400)
        self.assertEqual(Subscription.objects.count(), 0)

    def test_valid_through_the_last_day(self):
        edge = self.make("sent", issue_date=self.today - timedelta(days=30), validity_days=30)  # valid_until == today
        self.assertFalse(Quotation.objects.get(pk=edge.pk).is_expired)
        self.assertEqual(self.as_user(self.staff).post(f"/api/quotations/{edge.pk}/convert/").status_code, 201)

    def test_customer_cannot_convert_someone_elses_quotation(self):
        q = self.make("sent", customer=self.c2)
        self.assertEqual(self.as_user(self.c1).post(f"/api/quotations/{q.pk}/convert/").status_code, 404)

    def test_cannot_edit_or_delete_once_converted_and_send_needs_lines(self):
        empty = Quotation.objects.create(customer=self.c1, plan=self.plan, start_date=self.today)
        staff = self.as_user(self.staff)
        self.assertEqual(staff.post(f"/api/quotations/{empty.pk}/send/").status_code, 400)
        q = self.make("sent")
        staff.post(f"/api/quotations/{q.pk}/convert/")
        self.assertEqual(staff.patch(f"/api/quotations/{q.pk}/", {"notes": "x"}, format="json").status_code, 400)
        self.assertEqual(staff.delete(f"/api/quotations/{q.pk}/").status_code, 400)
        self.assertEqual(staff.delete(f"/api/quotations/{empty.pk}/").status_code, 204)

    def test_from_template_builds_a_draft_quotation(self):
        t = QuotationTemplate.objects.create(name="Pack", validity_days=21, plan=self.plan)
        QuotationTemplateLine.objects.create(template=t, product=self.product, quantity=5)
        r = self.as_user(self.staff).post("/api/quotations/from-template/", {
            "template": t.pk, "customer": self.c1.pk, "start_date": "2099-01-01"}, format="json")
        self.assertEqual(r.status_code, 201, r.data)
        self.assertEqual((r.data["status"], r.data["validity_days"], r.data["total"]), ("draft", 21, "5000.00"))
        self.assertEqual(Subscription.objects.count(), 0)

    def test_converted_subscription_can_then_be_activated_and_billed(self):
        q = self.make("sent")
        sub_id = self.as_user(self.staff).post(f"/api/quotations/{q.pk}/convert/").data["subscription"]["id"]
        sub = Subscription.objects.get(pk=sub_id)
        services.transition(sub, "active")
        res = services.generate_invoices(as_of=sub.start_date)
        self.assertEqual(res["created"], 1)
