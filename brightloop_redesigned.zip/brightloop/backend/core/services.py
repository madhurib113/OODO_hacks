"""Business logic: billing engine and subscription lifecycle. Views stay thin."""
import calendar
from datetime import date, timedelta
from decimal import ROUND_HALF_UP, Decimal

from django.db import IntegrityError, transaction
from django.db.models import F, Prefetch, Q
from django.utils import timezone
from rest_framework.exceptions import ValidationError

from .models import (AddOn, BillingRun, BillingRunItem, Discount, Invoice, InvoiceLine, Plan, Quotation,
                     Subscription, SubscriptionAddOn, SubscriptionLine, TaxRule)

CENT = Decimal("0.01")
MAX_PERIODS_PER_RUN = 24  # safety valve for very old backlogs


def q2(x):
    return Decimal(x).quantize(CENT, rounding=ROUND_HALF_UP)


# ---------------------------------------------------------------- dates
def add_months(d, n):
    m = d.month - 1 + n
    y, m = d.year + m // 12, m % 12 + 1
    return date(y, m, min(d.day, calendar.monthrange(y, m)[1]))


def add_period(d, period):
    if period == Plan.Period.DAILY:
        return d + timedelta(days=1)
    if period == Plan.Period.WEEKLY:
        return d + timedelta(days=7)
    if period == Plan.Period.MONTHLY:
        return add_months(d, 1)
    return add_months(d, 12)


# ---------------------------------------------------------------- taxes
class TaxTable:
    """Loads active tax rules once. Product-specific rules override general ones."""

    def __init__(self):
        self._loaded = False

    def _load(self):
        self.general = Decimal("0")
        self.by_product = {}
        for r in TaxRule.objects.filter(is_active=True):
            if r.product_id:
                self.by_product[r.product_id] = self.by_product.get(r.product_id, Decimal("0")) + r.rate
            else:
                self.general += r.rate
        self._loaded = True

    def rate_for(self, product_id):
        if not self._loaded:
            self._load()
        return self.by_product.get(product_id, self.general)


# ---------------------------------------------------------------- billing engine
ZERO = Decimal("0.00")


def _active_discounts(on_date):
    return list(
        Discount.objects.filter(is_active=True)
        .filter(Q(start_date__isnull=True) | Q(start_date__lte=on_date))
        .filter(Q(end_date__isnull=True) | Q(end_date__gte=on_date))
        .filter(Q(usage_limit__isnull=True) | Q(times_used__lt=F("usage_limit")))
        .order_by("id")
    )


def _claim_discount(discount):
    """Atomically take one use. Returns False if the limit was reached meanwhile."""
    return bool(
        Discount.objects.filter(pk=discount.pk)
        .filter(Q(usage_limit__isnull=True) | Q(times_used__lt=F("usage_limit")))
        .update(times_used=F("times_used") + 1)
    )


def _build_rows(sub, start, end):
    """Everything billable for one period: product lines plus add-ons effective in that period."""
    rows = []
    for l in sub.lines.all():
        label = l.product.name + (f" ({l.variant.attribute}: {l.variant.value})" if l.variant_id else "")
        rows.append({"product_id": l.product_id, "qty": l.quantity, "unit": l.unit_price, "label": label,
                     "base": q2(l.unit_price * l.quantity), "disc": ZERO})
    for a in sub.add_ons.all():
        if a.covers(start, end):
            # product_id None: add-ons take the general tax rate and are never hit by product-scoped discounts
            rows.append({"product_id": None, "qty": a.quantity, "unit": a.unit_price,
                         "label": f"Add-on: {a.add_on.name}", "base": q2(a.unit_price * a.quantity), "disc": ZERO})
    return rows


def _evaluate_discount(d, rows):
    """What would `d` save on these rows if it were the only rule? None if it is not eligible."""
    matched = [r for r in rows if d.apply_to == Discount.Scope.SUBSCRIPTION
               or (d.product_id and r["product_id"] == d.product_id)]
    if not matched:
        return None
    avail = [r["base"] - r["disc"] for r in matched]
    base, qty = sum(avail, ZERO), sum(r["qty"] for r in matched)
    if base <= 0 or base < d.min_amount or qty < d.min_quantity:
        return None
    amount = base * d.value / 100 if d.kind == Discount.Kind.PERCENT else d.value
    amount = min(q2(amount), base)
    if amount <= 0:
        return None
    return {"amount": amount, "matched": matched, "avail": avail, "base": base}


def _allocate(ev):
    """Spread a discount over the rows it matched, proportionally, so the shares add up exactly."""
    remaining = ev["amount"]
    for i, (r, a) in enumerate(zip(ev["matched"], ev["avail"])):
        share = remaining if i == len(ev["matched"]) - 1 else q2(ev["amount"] * a / ev["base"])
        share = min(share, a, remaining)
        r["disc"] += share
        remaining -= share


def resolve_discount(rows, discounts):
    """Largest-saving policy: of all eligible rules, apply only the one that saves the most money.

    Rules are never stacked. Ties go to the lowest id so results are deterministic. If the best rule's
    usage limit was used up by a concurrent run, the next best one is tried. Returns the applied Discount or None.
    """
    candidates = []
    for d in discounts:
        ev = _evaluate_discount(d, rows)
        if ev:
            candidates.append((d, ev))
    candidates.sort(key=lambda c: (-c[1]["amount"], c[0].id))
    for d, ev in candidates:
        if _claim_discount(d):
            _allocate(ev)
            return d
    return None


def _bill_period(sub, start, taxes, discounts, today):
    """Create one draft invoice for `sub` covering the period beginning on `start`."""
    end = add_period(start, sub.plan.billing_period) - timedelta(days=1)
    rows = _build_rows(sub, start, end)
    applied = resolve_discount(rows, discounts)

    subtotal = discount_total = tax_total = Decimal("0")
    inv_lines = []
    for r in rows:
        net = r["base"] - r["disc"]
        rate = taxes.rate_for(r["product_id"])
        tax = q2(net * rate / 100)
        inv_lines.append(InvoiceLine(description=r["label"], quantity=r["qty"], unit_price=r["unit"],
                                     discount=r["disc"], tax_rate=rate, tax_amount=tax, amount=net))
        subtotal += r["base"]
        discount_total += r["disc"]
        tax_total += tax

    inv = Invoice.objects.create(
        subscription=sub, customer_id=sub.customer_id, period_start=start, period_end=end,
        issue_date=today, due_date=today + timedelta(days=sub.payment_terms_days),
        subtotal=subtotal, discount_total=discount_total, tax_total=tax_total,
        total=subtotal - discount_total + tax_total, applied_discount=applied,
    )
    for il in inv_lines:
        il.invoice = inv
    InvoiceLine.objects.bulk_create(inv_lines)
    return inv


def _short(exc):
    return f"{type(exc).__name__}: {exc}"[:500]


def generate_invoices(as_of=None, customer_id=None, subscription_ids=None,
                      trigger=BillingRun.Trigger.MANUAL, user=None):
    """Bill every active, unpaused subscription whose next_invoice_date <= as_of.

    Idempotent: a DB unique constraint on (subscription, period_start) plus an
    existence check means re-running never double-bills; the cursor
    `next_invoice_date` moves forward in the same transaction so nothing is skipped.

    Every call is persisted as a BillingRun with one BillingRunItem per subscription/period outcome
    (created, skipped, failed + reason). A failure on one subscription is recorded and does not stop the run;
    its cursor is left untouched so the next run retries it.
    """
    today = timezone.localdate()
    as_of = as_of or today
    run = BillingRun.objects.create(
        trigger=trigger, as_of=as_of,
        triggered_by=user if user is not None and getattr(user, "is_authenticated", False) else None)
    items = []

    def log(sub, outcome, reason, start=None, invoice=None):
        items.append(BillingRunItem(run=run, subscription_id=sub.pk, subscription_number=sub.number or "",
                                    invoice=invoice, period_start=start, outcome=outcome, reason=reason))

    def scoped(qs):
        if customer_id:
            qs = qs.filter(customer_id=customer_id)
        if subscription_ids:
            qs = qs.filter(pk__in=subscription_ids)
        return qs

    due = dict(status=Subscription.Status.ACTIVE, next_invoice_date__isnull=False, next_invoice_date__lte=as_of)
    qs = scoped(Subscription.objects.filter(is_paused=False, **due).order_by("id")
                .select_related("plan")
                .prefetch_related(Prefetch("lines", queryset=SubscriptionLine.objects.select_related("product", "variant")),
                                  Prefetch("add_ons", queryset=SubscriptionAddOn.objects.select_related("add_on"))))
    result = {"created": 0, "skipped": 0, "failed": 0, "invoice_ids": [], "closed": 0, "run_id": run.pk}

    try:
        taxes, discounts = TaxTable(), _active_discounts(as_of)

        for sub in scoped(Subscription.objects.filter(is_paused=True, **due)).only("id", "number", "next_invoice_date"):
            result["skipped"] += 1
            log(sub, BillingRunItem.Outcome.SKIPPED, "Subscription is paused", sub.next_invoice_date)

        for sub in qs.iterator(chunk_size=500):
            guard = 0
            while sub.next_invoice_date and sub.next_invoice_date <= as_of and guard < MAX_PERIODS_PER_RUN:
                guard += 1
                start = sub.next_invoice_date
                if sub.expiry_date and start > sub.expiry_date:
                    result["skipped"] += 1
                    log(sub, BillingRunItem.Outcome.SKIPPED,
                        f"Period starts {start}, after the expiry date {sub.expiry_date}", start)
                    break
                nxt = add_period(start, sub.plan.billing_period)
                try:
                    with transaction.atomic():
                        if Invoice.objects.filter(subscription=sub, period_start=start).exists():
                            result["skipped"] += 1
                            log(sub, BillingRunItem.Outcome.SKIPPED, "An invoice already exists for this period", start)
                        else:
                            inv = _bill_period(sub, start, taxes, discounts, today)
                            result["created"] += 1
                            result["invoice_ids"].append(inv.pk)
                            log(sub, BillingRunItem.Outcome.CREATED, f"Invoice {inv.number} created", start, inv)
                        Subscription.objects.filter(pk=sub.pk).update(next_invoice_date=nxt)
                except IntegrityError:  # lost a race with a parallel run: the other run billed it
                    result["skipped"] += 1
                    log(sub, BillingRunItem.Outcome.SKIPPED, "Billed concurrently by another run", start)
                    Subscription.objects.filter(pk=sub.pk).update(next_invoice_date=nxt)
                except Exception as exc:  # isolate the failure; cursor stays put so the next run retries
                    result["failed"] += 1
                    log(sub, BillingRunItem.Outcome.FAILED, _short(exc), start)
                    break
                sub.next_invoice_date = nxt

        result["closed"] = close_expired(today)
    except Exception as exc:
        _finish_run(run, items, result, BillingRun.Status.FAILED, _short(exc))
        raise
    _finish_run(run, items, result, BillingRun.Status.COMPLETED)
    return result


def _finish_run(run, items, result, status, error=""):
    BillingRunItem.objects.bulk_create(items, batch_size=1000)
    run.status, run.error, run.finished_at = status, error, timezone.now()
    run.created_count, run.skipped_count = result["created"], result["skipped"]
    run.failed_count, run.closed_count = result["failed"], result["closed"]
    run.save()


def close_expired(today=None):
    today = today or timezone.localdate()
    return Subscription.objects.filter(
        status=Subscription.Status.ACTIVE, plan__auto_close=True, expiry_date__lt=today
    ).update(status=Subscription.Status.CLOSED)


# ---------------------------------------------------------------- subscription lifecycle
S = Subscription.Status
TRANSITIONS = {
    S.DRAFT: [S.QUOTATION],
    S.QUOTATION: [S.CONFIRMED, S.DRAFT],
    S.CONFIRMED: [S.ACTIVE, S.CLOSED],
    S.ACTIVE: [S.CLOSED],
    S.CLOSED: [],
}


def transition(sub, new_status):
    if new_status not in [s.value for s in TRANSITIONS[sub.status]]:
        raise ValidationError(f"Cannot move a subscription from {sub.status} to {new_status}.")
    today = timezone.localdate()
    if new_status in (S.CONFIRMED, S.QUOTATION) and not sub.lines.exists():
        raise ValidationError("Add at least one product line first.")
    if new_status == S.CONFIRMED and sub.quotation_valid_until and sub.quotation_valid_until < today:
        raise ValidationError("This quotation has expired.")
    if new_status == S.CLOSED and sub.status == S.ACTIVE and not sub.plan.closable:
        raise ValidationError("This plan cannot be closed early.")
    if new_status == S.ACTIVE and not sub.next_invoice_date:
        sub.next_invoice_date = sub.start_date
    sub.status = new_status
    sub.is_paused = False
    sub.save()
    return sub


def pause(sub):
    if sub.status != S.ACTIVE or not sub.plan.pausable:
        raise ValidationError("Only active subscriptions on pausable plans can be paused.")
    sub.is_paused = True
    sub.save(update_fields=["is_paused"])
    return sub


def resume(sub):
    if not sub.is_paused:
        raise ValidationError("Subscription is not paused.")
    sub.is_paused = False
    sub.save(update_fields=["is_paused"])
    return sub


def renew(sub):
    if not sub.plan.renewable:
        raise ValidationError("This plan cannot be renewed.")
    if sub.status not in (S.ACTIVE, S.CLOSED):
        raise ValidationError("Only active or closed subscriptions can be renewed.")
    today = timezone.localdate()
    period = sub.plan.billing_period
    if sub.status == S.CLOSED:
        sub.status = S.ACTIVE
        sub.next_invoice_date = today
        sub.expiry_date = add_period(today, period)
    else:
        sub.expiry_date = add_period(sub.expiry_date or today, period)
    sub.save()
    return sub


# ---------------------------------------------------------------- add-ons
def eligible_add_ons(sub, qs=None):
    """Active add-ons this subscription may take. Empty eligibility sets mean "no restriction"."""
    qs = AddOn.objects.all() if qs is None else qs
    product_ids = list(sub.lines.values_list("product_id", flat=True))
    return (qs.filter(is_active=True)
            .filter(Q(eligible_plans__isnull=True) | Q(eligible_plans=sub.plan_id))
            .filter(Q(eligible_products__isnull=True) | Q(eligible_products__in=product_ids))
            .distinct())


def attach_add_on(sub, add_on, quantity=1, start_date=None):
    if sub.status == S.CLOSED:
        raise ValidationError("Add-ons cannot be added to a closed subscription.")
    if not eligible_add_ons(sub, AddOn.objects.filter(pk=add_on.pk)).exists():
        raise ValidationError("This add-on is inactive or not available for this subscription's plan and products.")
    if sub.add_ons.filter(add_on=add_on, is_active=True).exists():
        raise ValidationError("This add-on is already on the subscription. Change its quantity instead.")
    return SubscriptionAddOn.objects.create(
        subscription=sub, add_on=add_on, quantity=quantity, unit_price=add_on.price,  # price snapshot
        start_date=start_date or timezone.localdate())


def update_add_on(sa, quantity=None, is_active=None, end_date=None, end_date_given=False):
    today = timezone.localdate()
    if sa.subscription.status == S.CLOSED:
        raise ValidationError("This subscription is closed; its add-ons can no longer be changed.")
    if quantity is not None:
        sa.quantity = quantity
    if end_date_given:
        sa.end_date = end_date
    if is_active is not None and is_active != sa.is_active:
        if is_active:
            if sa.subscription.add_ons.filter(add_on=sa.add_on, is_active=True).exclude(pk=sa.pk).exists():
                raise ValidationError("This add-on is already active on the subscription.")
            if not sa.add_on.is_active:
                raise ValidationError("This add-on has been withdrawn from the catalogue.")
            if not end_date_given:
                sa.end_date = None
        elif not end_date_given and (sa.end_date is None or sa.end_date > today):
            sa.end_date = today  # deactivating stops billing from today
        sa.is_active = is_active
    if sa.end_date and sa.end_date < sa.start_date:
        raise ValidationError("End date cannot be before the start date.")
    sa.save()
    return sa


# ---------------------------------------------------------------- quotations
@transaction.atomic
def convert_quotation(quotation):
    """Turn an accepted quotation into a Confirmed subscription (copying lines and agreed prices)."""
    q = Quotation.objects.select_for_update().select_related("plan").get(pk=quotation.pk)
    if q.status == Quotation.Status.CONVERTED:
        raise ValidationError("This quotation has already been converted.")
    if q.status == Quotation.Status.CANCELLED:
        raise ValidationError("A cancelled quotation cannot be converted.")
    if q.is_expired:
        raise ValidationError(f"This quotation expired on {q.valid_until}.")
    lines = list(q.lines.select_related("product", "variant"))
    if not lines:
        raise ValidationError("Add at least one product line before converting.")
    if any(l.quantity < q.plan.min_quantity for l in lines):
        raise ValidationError(f"Minimum quantity for this plan is {q.plan.min_quantity}.")
    if q.plan.start_date and q.start_date < q.plan.start_date:
        raise ValidationError(f"This plan is available from {q.plan.start_date}.")
    if q.plan.end_date and q.start_date > q.plan.end_date:
        raise ValidationError(f"This plan ended on {q.plan.end_date}.")
    sub = Subscription.objects.create(
        customer_id=q.customer_id, plan=q.plan, template_id=q.template_id, status=Subscription.Status.CONFIRMED,
        start_date=q.start_date, expiry_date=q.expiry_date, payment_terms_days=q.payment_terms_days,
        quotation_valid_until=q.valid_until, notes=q.notes)
    SubscriptionLine.objects.bulk_create([
        SubscriptionLine(subscription=sub, product=l.product, variant=l.variant, quantity=l.quantity,
                         unit_price=l.unit_price) for l in lines])
    q.status, q.subscription, q.converted_at = Quotation.Status.CONVERTED, sub, timezone.now()
    q.save()
    return sub
