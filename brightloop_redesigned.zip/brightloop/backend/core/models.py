from datetime import timedelta
from decimal import Decimal

from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.core.validators import MinValueValidator
from django.db import models
from django.utils import timezone

ZERO = Decimal("0.00")


# ---------------------------------------------------------------- users
class UserManager(BaseUserManager):
    use_in_migrations = True

    def _create(self, email, password, **extra):
        if not email:
            raise ValueError("Email is required")
        user = self.model(email=self.normalize_email(email).lower(), **extra)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_user(self, email, password=None, **extra):
        extra.setdefault("role", "customer")
        return self._create(email, password, **extra)

    def create_superuser(self, email, password=None, **extra):
        extra.update(role="admin", is_staff=True, is_superuser=True)
        return self._create(email, password, **extra)


class User(AbstractUser):
    class Role(models.TextChoices):
        ADMIN = "admin", "Admin"
        STAFF = "staff", "Internal staff"
        CUSTOMER = "customer", "Customer"

    username = None
    email = models.EmailField(unique=True)
    role = models.CharField(max_length=10, choices=Role.choices, default=Role.CUSTOMER, db_index=True)
    company = models.CharField(max_length=150, blank=True)

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = []
    objects = UserManager()

    def __str__(self):
        return self.email


class Numbered(models.Model):
    """Gives every row a human-friendly number such as SUB-000042 once it has a pk."""

    NUMBER_PREFIX = "NUM"
    number = models.CharField(max_length=30, unique=True, null=True, blank=True, editable=False)

    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        if not self.number:
            self.number = f"{self.NUMBER_PREFIX}-{self.pk:06d}"
            type(self).objects.filter(pk=self.pk).update(number=self.number)


# ---------------------------------------------------------------- catalog
class Product(models.Model):
    name = models.CharField(max_length=150)
    type = models.CharField(max_length=50, default="software")
    sales_price = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(0)])
    cost_price = models.DecimalField(max_digits=12, decimal_places=2, default=0, validators=[MinValueValidator(0)])
    notes = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class ProductVariant(models.Model):
    product = models.ForeignKey(Product, related_name="variants", on_delete=models.CASCADE)
    attribute = models.CharField(max_length=60, default="Brand")
    value = models.CharField(max_length=100)
    extra_price = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    def __str__(self):
        return f"{self.product.name} / {self.attribute}: {self.value}"


class Plan(models.Model):
    class Period(models.TextChoices):
        DAILY = "daily", "Daily"
        WEEKLY = "weekly", "Weekly"
        MONTHLY = "monthly", "Monthly"
        YEARLY = "yearly", "Yearly"

    name = models.CharField(max_length=150)
    price = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(0)])
    billing_period = models.CharField(max_length=10, choices=Period.choices, default=Period.MONTHLY)
    min_quantity = models.PositiveIntegerField(default=1)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    auto_close = models.BooleanField(default=False, help_text="Close subscriptions automatically at expiry")
    closable = models.BooleanField(default=True, help_text="Can be closed before the end date")
    pausable = models.BooleanField(default=False)
    renewable = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class QuotationTemplate(models.Model):
    name = models.CharField(max_length=150)
    validity_days = models.PositiveIntegerField(default=30)
    plan = models.ForeignKey(Plan, on_delete=models.PROTECT)

    def __str__(self):
        return self.name


class QuotationTemplateLine(models.Model):
    template = models.ForeignKey(QuotationTemplate, related_name="lines", on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    variant = models.ForeignKey(ProductVariant, null=True, blank=True, on_delete=models.PROTECT)
    quantity = models.PositiveIntegerField(default=1)


class TaxRule(models.Model):
    """product=None means a general rule. Product rules override general ones; rules of one kind add up (CGST+SGST)."""

    name = models.CharField(max_length=100)
    rate = models.DecimalField(max_digits=5, decimal_places=2, help_text="Percent")
    product = models.ForeignKey(Product, null=True, blank=True, on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.name} ({self.rate}%)"


class Discount(models.Model):
    class Kind(models.TextChoices):
        FIXED = "fixed", "Fixed amount"
        PERCENT = "percent", "Percentage"

    class Scope(models.TextChoices):
        PRODUCT = "product", "Specific product"
        SUBSCRIPTION = "subscription", "Whole subscription"

    name = models.CharField(max_length=120)
    kind = models.CharField(max_length=10, choices=Kind.choices, default=Kind.PERCENT)
    value = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(0)])
    apply_to = models.CharField(max_length=15, choices=Scope.choices, default=Scope.SUBSCRIPTION)
    product = models.ForeignKey(Product, null=True, blank=True, on_delete=models.CASCADE)
    min_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    min_quantity = models.PositiveIntegerField(default=0)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    usage_limit = models.PositiveIntegerField(null=True, blank=True, help_text="Empty = unlimited")
    times_used = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class AddOn(models.Model):
    """Optional extra sold on top of a subscription (e.g. extra seats, priority support).

    Eligibility: an empty `eligible_products` / `eligible_plans` set means "no restriction".
    When both are set the subscription must satisfy both (right plan AND at least one eligible product).
    """

    name = models.CharField(max_length=150)
    description = models.CharField(max_length=255, blank=True)
    price = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(0)])
    is_active = models.BooleanField(default=True)
    eligible_products = models.ManyToManyField(Product, blank=True, related_name="add_ons")
    eligible_plans = models.ManyToManyField(Plan, blank=True, related_name="add_ons")

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


# ---------------------------------------------------------------- subscriptions
class Subscription(Numbered):
    NUMBER_PREFIX = "SUB"

    class Status(models.TextChoices):
        DRAFT = "draft", "Draft"
        QUOTATION = "quotation", "Quotation"
        CONFIRMED = "confirmed", "Confirmed"
        ACTIVE = "active", "Active"
        CLOSED = "closed", "Closed"

    customer = models.ForeignKey(User, related_name="subscriptions", on_delete=models.PROTECT)
    plan = models.ForeignKey(Plan, on_delete=models.PROTECT)
    template = models.ForeignKey(QuotationTemplate, null=True, blank=True, on_delete=models.SET_NULL)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.DRAFT)
    start_date = models.DateField()
    expiry_date = models.DateField(null=True, blank=True)
    payment_terms_days = models.PositiveIntegerField(default=15)
    quotation_valid_until = models.DateField(null=True, blank=True)
    next_invoice_date = models.DateField(null=True, blank=True)
    is_paused = models.BooleanField(default=False)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [
            models.Index(fields=["status", "next_invoice_date"], name="sub_status_nextinv_idx"),
            models.Index(fields=["customer", "status"], name="sub_customer_status_idx"),
        ]


class SubscriptionLine(models.Model):
    subscription = models.ForeignKey(Subscription, related_name="lines", on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    variant = models.ForeignKey(ProductVariant, null=True, blank=True, on_delete=models.PROTECT)
    quantity = models.PositiveIntegerField(default=1, validators=[MinValueValidator(1)])
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)


class SubscriptionAddOn(models.Model):
    """An add-on attached to a subscription. `unit_price` is a snapshot taken when it was attached,
    so later catalogue price changes never rewrite what the customer agreed to."""

    subscription = models.ForeignKey(Subscription, related_name="add_ons", on_delete=models.CASCADE)
    add_on = models.ForeignKey(AddOn, related_name="subscription_add_ons", on_delete=models.PROTECT)
    quantity = models.PositiveIntegerField(default=1, validators=[MinValueValidator(1)])
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    is_active = models.BooleanField(default=True)
    start_date = models.DateField(default=timezone.localdate)
    end_date = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [models.Index(fields=["subscription", "is_active"], name="subaddon_sub_active_idx")]

    def covers(self, period_start, period_end):
        """True if this add-on should be billed for the period [period_start, period_end]."""
        return (self.is_active and self.start_date <= period_end
                and (self.end_date is None or self.end_date >= period_start))


# ---------------------------------------------------------------- quotations
class Quotation(Numbered):
    """A standalone offer to a customer. It becomes a Subscription only through `convert`."""

    NUMBER_PREFIX = "QUO"

    class Status(models.TextChoices):
        DRAFT = "draft", "Draft"
        SENT = "sent", "Sent"
        CONVERTED = "converted", "Converted"
        CANCELLED = "cancelled", "Cancelled"

    customer = models.ForeignKey(User, related_name="quotations", on_delete=models.PROTECT)
    plan = models.ForeignKey(Plan, on_delete=models.PROTECT)
    template = models.ForeignKey(QuotationTemplate, null=True, blank=True, on_delete=models.SET_NULL)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.DRAFT)
    issue_date = models.DateField(default=timezone.localdate)
    validity_days = models.PositiveIntegerField(default=30)
    start_date = models.DateField(help_text="Proposed start of the subscription")
    expiry_date = models.DateField(null=True, blank=True, help_text="Proposed expiry of the subscription")
    payment_terms_days = models.PositiveIntegerField(default=15)
    notes = models.TextField(blank=True)
    subscription = models.OneToOneField(Subscription, null=True, blank=True, on_delete=models.SET_NULL,
                                        related_name="source_quotation")
    converted_at = models.DateTimeField(null=True, blank=True)
    created_by = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [models.Index(fields=["status", "issue_date"], name="quo_status_issue_idx"),
                   models.Index(fields=["customer", "status"], name="quo_customer_status_idx")]

    @property
    def valid_until(self):
        return self.issue_date + timedelta(days=self.validity_days)

    @property
    def is_expired(self):
        return self.status in (self.Status.DRAFT, self.Status.SENT) and self.valid_until < timezone.localdate()

    @property
    def days_remaining(self):
        return (self.valid_until - timezone.localdate()).days


class QuotationLine(models.Model):
    quotation = models.ForeignKey(Quotation, related_name="lines", on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    variant = models.ForeignKey(ProductVariant, null=True, blank=True, on_delete=models.PROTECT)
    quantity = models.PositiveIntegerField(default=1, validators=[MinValueValidator(1)])
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)


# ---------------------------------------------------------------- invoices & payments
class Invoice(Numbered):
    NUMBER_PREFIX = "INV"

    class Status(models.TextChoices):
        DRAFT = "draft", "Draft"
        CONFIRMED = "confirmed", "Confirmed"
        PAID = "paid", "Paid"
        CANCELLED = "cancelled", "Cancelled"

    subscription = models.ForeignKey(Subscription, related_name="invoices", on_delete=models.PROTECT)
    customer = models.ForeignKey(User, related_name="invoices", on_delete=models.PROTECT)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.DRAFT)
    period_start = models.DateField()
    period_end = models.DateField()
    issue_date = models.DateField(default=timezone.localdate)
    due_date = models.DateField()
    subtotal = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    discount_total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    tax_total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    amount_paid = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    applied_discount = models.ForeignKey(Discount, null=True, blank=True, on_delete=models.SET_NULL,
                                         related_name="+", help_text="The single rule that won the largest-saving contest")
    sent_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            # The core guarantee: one invoice per subscription per billing period, enforced by the database.
            models.UniqueConstraint(fields=["subscription", "period_start"], name="uniq_invoice_per_period"),
        ]
        indexes = [
            models.Index(fields=["status", "due_date"], name="inv_status_due_idx"),
            models.Index(fields=["customer", "status"], name="inv_customer_status_idx"),
            models.Index(fields=["issue_date"], name="inv_issue_date_idx"),
        ]

    @property
    def outstanding(self):
        return self.total - self.amount_paid


class InvoiceLine(models.Model):
    invoice = models.ForeignKey(Invoice, related_name="lines", on_delete=models.CASCADE)
    description = models.CharField(max_length=255)
    quantity = models.PositiveIntegerField()
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    discount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    tax_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    tax_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    amount = models.DecimalField(max_digits=12, decimal_places=2, help_text="Net of discount, before tax")


class Payment(models.Model):
    class Method(models.TextChoices):
        CARD = "card", "Card"
        UPI = "upi", "UPI"
        BANK = "bank_transfer", "Bank transfer"
        CASH = "cash", "Cash"
        CHEQUE = "cheque", "Cheque"

    invoice = models.ForeignKey(Invoice, related_name="payments", on_delete=models.PROTECT)
    method = models.CharField(max_length=15, choices=Method.choices)
    amount = models.DecimalField(max_digits=14, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))])
    date = models.DateField(default=timezone.localdate)
    note = models.CharField(max_length=255, blank=True)
    recorded_by = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [models.Index(fields=["date"], name="pay_date_idx")]


# ---------------------------------------------------------------- billing audit log
class BillingRun(models.Model):
    """One execution of `generate_invoices`. Persisted so finance can see what every run did and why."""

    class Trigger(models.TextChoices):
        MANUAL = "manual", "Manual (staff / API)"
        SCHEDULED = "scheduled", "Scheduled job"
        SEED = "seed", "Demo seeding"

    class Status(models.TextChoices):
        RUNNING = "running", "Running"
        COMPLETED = "completed", "Completed"
        FAILED = "failed", "Failed"

    started_at = models.DateTimeField(default=timezone.now, db_index=True)
    finished_at = models.DateTimeField(null=True, blank=True)
    trigger = models.CharField(max_length=10, choices=Trigger.choices, default=Trigger.MANUAL)
    triggered_by = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    as_of = models.DateField()
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.RUNNING)
    created_count = models.PositiveIntegerField(default=0)
    skipped_count = models.PositiveIntegerField(default=0)
    failed_count = models.PositiveIntegerField(default=0)
    closed_count = models.PositiveIntegerField(default=0, help_text="Subscriptions auto-closed at the end of the run")
    error = models.TextField(blank=True)

    class Meta:
        ordering = ["-id"]


class BillingRunItem(models.Model):
    class Outcome(models.TextChoices):
        CREATED = "created", "Invoice created"
        SKIPPED = "skipped", "Skipped"
        FAILED = "failed", "Failed"

    run = models.ForeignKey(BillingRun, related_name="items", on_delete=models.CASCADE)
    subscription = models.ForeignKey(Subscription, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    subscription_number = models.CharField(max_length=30, blank=True)  # snapshot, survives deletion
    invoice = models.ForeignKey(Invoice, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    period_start = models.DateField(null=True, blank=True)
    outcome = models.CharField(max_length=10, choices=Outcome.choices)
    reason = models.CharField(max_length=500, blank=True)

    class Meta:
        ordering = ["id"]
        indexes = [models.Index(fields=["run", "outcome"], name="bri_run_outcome_idx")]
