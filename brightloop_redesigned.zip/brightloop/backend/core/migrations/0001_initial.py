import decimal

import django.core.validators
import django.db.models.deletion
import django.utils.timezone
from django.conf import settings
from django.db import migrations, models

import core.models

MIN0 = [django.core.validators.MinValueValidator(0)]
NUMBER = dict(blank=True, editable=False, max_length=30, null=True, unique=True)


class Migration(migrations.Migration):
    initial = True

    dependencies = [
        ("auth", "0012_alter_user_first_name_max_length"),
    ]

    operations = [
        # ------------------------------------------------------------ users
        migrations.CreateModel(
            name="User",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("password", models.CharField(max_length=128, verbose_name="password")),
                ("last_login", models.DateTimeField(blank=True, null=True, verbose_name="last login")),
                ("is_superuser", models.BooleanField(default=False, help_text="Designates that this user has all permissions without explicitly assigning them.", verbose_name="superuser status")),
                ("first_name", models.CharField(blank=True, max_length=150, verbose_name="first name")),
                ("last_name", models.CharField(blank=True, max_length=150, verbose_name="last name")),
                ("is_staff", models.BooleanField(default=False, help_text="Designates whether the user can log into this admin site.", verbose_name="staff status")),
                ("is_active", models.BooleanField(default=True, help_text="Designates whether this user should be treated as active. Unselect this instead of deleting accounts.", verbose_name="active")),
                ("date_joined", models.DateTimeField(default=django.utils.timezone.now, verbose_name="date joined")),
                ("email", models.EmailField(max_length=254, unique=True)),
                ("role", models.CharField(choices=[("admin", "Admin"), ("staff", "Internal staff"), ("customer", "Customer")], db_index=True, default="customer", max_length=10)),
                ("company", models.CharField(blank=True, max_length=150)),
                ("groups", models.ManyToManyField(blank=True, help_text="The groups this user belongs to. A user will get all permissions granted to each of their groups.", related_name="user_set", related_query_name="user", to="auth.group", verbose_name="groups")),
                ("user_permissions", models.ManyToManyField(blank=True, help_text="Specific permissions for this user.", related_name="user_set", related_query_name="user", to="auth.permission", verbose_name="user permissions")),
            ],
            options={"verbose_name": "user", "verbose_name_plural": "users", "abstract": False},
            managers=[("objects", core.models.UserManager())],
        ),
        # ------------------------------------------------------------ catalog
        migrations.CreateModel(
            name="Product",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=150)),
                ("type", models.CharField(default="software", max_length=50)),
                ("sales_price", models.DecimalField(decimal_places=2, max_digits=12, validators=MIN0)),
                ("cost_price", models.DecimalField(decimal_places=2, default=0, max_digits=12, validators=MIN0)),
                ("notes", models.TextField(blank=True)),
                ("is_active", models.BooleanField(default=True)),
            ],
        ),
        migrations.CreateModel(
            name="ProductVariant",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("attribute", models.CharField(default="Brand", max_length=60)),
                ("value", models.CharField(max_length=100)),
                ("extra_price", models.DecimalField(decimal_places=2, default=0, max_digits=12)),
                ("product", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="variants", to="core.product")),
            ],
        ),
        migrations.CreateModel(
            name="Plan",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=150)),
                ("price", models.DecimalField(decimal_places=2, max_digits=12, validators=MIN0)),
                ("billing_period", models.CharField(choices=[("daily", "Daily"), ("weekly", "Weekly"), ("monthly", "Monthly"), ("yearly", "Yearly")], default="monthly", max_length=10)),
                ("min_quantity", models.PositiveIntegerField(default=1)),
                ("start_date", models.DateField(blank=True, null=True)),
                ("end_date", models.DateField(blank=True, null=True)),
                ("auto_close", models.BooleanField(default=False, help_text="Close subscriptions automatically at expiry")),
                ("closable", models.BooleanField(default=True, help_text="Can be closed before the end date")),
                ("pausable", models.BooleanField(default=False)),
                ("renewable", models.BooleanField(default=True)),
            ],
        ),
        migrations.CreateModel(
            name="QuotationTemplate",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=150)),
                ("validity_days", models.PositiveIntegerField(default=30)),
                ("plan", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to="core.plan")),
            ],
        ),
        migrations.CreateModel(
            name="QuotationTemplateLine",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("quantity", models.PositiveIntegerField(default=1)),
                ("product", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to="core.product")),
                ("template", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="lines", to="core.quotationtemplate")),
                ("variant", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, to="core.productvariant")),
            ],
        ),
        migrations.CreateModel(
            name="TaxRule",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=100)),
                ("rate", models.DecimalField(decimal_places=2, help_text="Percent", max_digits=5)),
                ("is_active", models.BooleanField(default=True)),
                ("product", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, to="core.product")),
            ],
        ),
        migrations.CreateModel(
            name="Discount",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=120)),
                ("kind", models.CharField(choices=[("fixed", "Fixed amount"), ("percent", "Percentage")], default="percent", max_length=10)),
                ("value", models.DecimalField(decimal_places=2, max_digits=12, validators=MIN0)),
                ("apply_to", models.CharField(choices=[("product", "Specific product"), ("subscription", "Whole subscription")], default="subscription", max_length=15)),
                ("min_amount", models.DecimalField(decimal_places=2, default=0, max_digits=12)),
                ("min_quantity", models.PositiveIntegerField(default=0)),
                ("start_date", models.DateField(blank=True, null=True)),
                ("end_date", models.DateField(blank=True, null=True)),
                ("usage_limit", models.PositiveIntegerField(blank=True, help_text="Empty = unlimited", null=True)),
                ("times_used", models.PositiveIntegerField(default=0)),
                ("is_active", models.BooleanField(default=True)),
                ("product", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, to="core.product")),
            ],
        ),
        migrations.CreateModel(
            name="AddOn",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=150)),
                ("description", models.CharField(blank=True, max_length=255)),
                ("price", models.DecimalField(decimal_places=2, max_digits=12, validators=MIN0)),
                ("is_active", models.BooleanField(default=True)),
                ("eligible_plans", models.ManyToManyField(blank=True, related_name="add_ons", to="core.plan")),
                ("eligible_products", models.ManyToManyField(blank=True, related_name="add_ons", to="core.product")),
            ],
            options={"ordering": ["name"]},
        ),
        # ------------------------------------------------------------ subscriptions
        migrations.CreateModel(
            name="Subscription",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("number", models.CharField(**NUMBER)),
                ("status", models.CharField(choices=[("draft", "Draft"), ("quotation", "Quotation"), ("confirmed", "Confirmed"), ("active", "Active"), ("closed", "Closed")], default="draft", max_length=10)),
                ("start_date", models.DateField()),
                ("expiry_date", models.DateField(blank=True, null=True)),
                ("payment_terms_days", models.PositiveIntegerField(default=15)),
                ("quotation_valid_until", models.DateField(blank=True, null=True)),
                ("next_invoice_date", models.DateField(blank=True, null=True)),
                ("is_paused", models.BooleanField(default=False)),
                ("notes", models.TextField(blank=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("customer", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="subscriptions", to=settings.AUTH_USER_MODEL)),
                ("plan", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to="core.plan")),
                ("template", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to="core.quotationtemplate")),
            ],
            options={"indexes": [
                models.Index(fields=["status", "next_invoice_date"], name="sub_status_nextinv_idx"),
                models.Index(fields=["customer", "status"], name="sub_customer_status_idx"),
            ]},
        ),
        migrations.CreateModel(
            name="SubscriptionLine",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("quantity", models.PositiveIntegerField(default=1, validators=[django.core.validators.MinValueValidator(1)])),
                ("unit_price", models.DecimalField(decimal_places=2, max_digits=12)),
                ("product", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to="core.product")),
                ("subscription", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="lines", to="core.subscription")),
                ("variant", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, to="core.productvariant")),
            ],
        ),
        migrations.CreateModel(
            name="SubscriptionAddOn",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("quantity", models.PositiveIntegerField(default=1, validators=[django.core.validators.MinValueValidator(1)])),
                ("unit_price", models.DecimalField(decimal_places=2, max_digits=12)),
                ("is_active", models.BooleanField(default=True)),
                ("start_date", models.DateField(default=django.utils.timezone.localdate)),
                ("end_date", models.DateField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("add_on", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="subscription_add_ons", to="core.addon")),
                ("subscription", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="add_ons", to="core.subscription")),
            ],
            options={"indexes": [models.Index(fields=["subscription", "is_active"], name="subaddon_sub_active_idx")]},
        ),
        # ------------------------------------------------------------ quotations
        migrations.CreateModel(
            name="Quotation",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("number", models.CharField(**NUMBER)),
                ("status", models.CharField(choices=[("draft", "Draft"), ("sent", "Sent"), ("converted", "Converted"), ("cancelled", "Cancelled")], default="draft", max_length=10)),
                ("issue_date", models.DateField(default=django.utils.timezone.localdate)),
                ("validity_days", models.PositiveIntegerField(default=30)),
                ("start_date", models.DateField(help_text="Proposed start of the subscription")),
                ("expiry_date", models.DateField(blank=True, help_text="Proposed expiry of the subscription", null=True)),
                ("payment_terms_days", models.PositiveIntegerField(default=15)),
                ("notes", models.TextField(blank=True)),
                ("converted_at", models.DateTimeField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("created_by", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="+", to=settings.AUTH_USER_MODEL)),
                ("customer", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="quotations", to=settings.AUTH_USER_MODEL)),
                ("plan", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to="core.plan")),
                ("subscription", models.OneToOneField(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="source_quotation", to="core.subscription")),
                ("template", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to="core.quotationtemplate")),
            ],
            options={"indexes": [
                models.Index(fields=["status", "issue_date"], name="quo_status_issue_idx"),
                models.Index(fields=["customer", "status"], name="quo_customer_status_idx"),
            ]},
        ),
        migrations.CreateModel(
            name="QuotationLine",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("quantity", models.PositiveIntegerField(default=1, validators=[django.core.validators.MinValueValidator(1)])),
                ("unit_price", models.DecimalField(decimal_places=2, max_digits=12)),
                ("product", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to="core.product")),
                ("quotation", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="lines", to="core.quotation")),
                ("variant", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, to="core.productvariant")),
            ],
        ),
        # ------------------------------------------------------------ invoices & payments
        migrations.CreateModel(
            name="Invoice",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("number", models.CharField(**NUMBER)),
                ("status", models.CharField(choices=[("draft", "Draft"), ("confirmed", "Confirmed"), ("paid", "Paid"), ("cancelled", "Cancelled")], default="draft", max_length=10)),
                ("period_start", models.DateField()),
                ("period_end", models.DateField()),
                ("issue_date", models.DateField(default=django.utils.timezone.localdate)),
                ("due_date", models.DateField()),
                ("subtotal", models.DecimalField(decimal_places=2, default=0, max_digits=14)),
                ("discount_total", models.DecimalField(decimal_places=2, default=0, max_digits=14)),
                ("tax_total", models.DecimalField(decimal_places=2, default=0, max_digits=14)),
                ("total", models.DecimalField(decimal_places=2, default=0, max_digits=14)),
                ("amount_paid", models.DecimalField(decimal_places=2, default=0, max_digits=14)),
                ("sent_at", models.DateTimeField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("applied_discount", models.ForeignKey(blank=True, help_text="The single rule that won the largest-saving contest", null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="+", to="core.discount")),
                ("customer", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="invoices", to=settings.AUTH_USER_MODEL)),
                ("subscription", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="invoices", to="core.subscription")),
            ],
            options={
                "indexes": [
                    models.Index(fields=["status", "due_date"], name="inv_status_due_idx"),
                    models.Index(fields=["customer", "status"], name="inv_customer_status_idx"),
                    models.Index(fields=["issue_date"], name="inv_issue_date_idx"),
                ],
                "constraints": [models.UniqueConstraint(fields=("subscription", "period_start"), name="uniq_invoice_per_period")],
            },
        ),
        migrations.CreateModel(
            name="InvoiceLine",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("description", models.CharField(max_length=255)),
                ("quantity", models.PositiveIntegerField()),
                ("unit_price", models.DecimalField(decimal_places=2, max_digits=12)),
                ("discount", models.DecimalField(decimal_places=2, default=0, max_digits=12)),
                ("tax_rate", models.DecimalField(decimal_places=2, default=0, max_digits=5)),
                ("tax_amount", models.DecimalField(decimal_places=2, default=0, max_digits=12)),
                ("amount", models.DecimalField(decimal_places=2, help_text="Net of discount, before tax", max_digits=12)),
                ("invoice", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="lines", to="core.invoice")),
            ],
        ),
        migrations.CreateModel(
            name="Payment",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("method", models.CharField(choices=[("card", "Card"), ("upi", "UPI"), ("bank_transfer", "Bank transfer"), ("cash", "Cash"), ("cheque", "Cheque")], max_length=15)),
                ("amount", models.DecimalField(decimal_places=2, max_digits=14, validators=[django.core.validators.MinValueValidator(decimal.Decimal("0.01"))])),
                ("date", models.DateField(default=django.utils.timezone.localdate)),
                ("note", models.CharField(blank=True, max_length=255)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("invoice", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="payments", to="core.invoice")),
                ("recorded_by", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="+", to=settings.AUTH_USER_MODEL)),
            ],
            options={"indexes": [models.Index(fields=["date"], name="pay_date_idx")]},
        ),
        # ------------------------------------------------------------ billing audit log
        migrations.CreateModel(
            name="BillingRun",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("started_at", models.DateTimeField(db_index=True, default=django.utils.timezone.now)),
                ("finished_at", models.DateTimeField(blank=True, null=True)),
                ("trigger", models.CharField(choices=[("manual", "Manual (staff / API)"), ("scheduled", "Scheduled job"), ("seed", "Demo seeding")], default="manual", max_length=10)),
                ("as_of", models.DateField()),
                ("status", models.CharField(choices=[("running", "Running"), ("completed", "Completed"), ("failed", "Failed")], default="running", max_length=10)),
                ("created_count", models.PositiveIntegerField(default=0)),
                ("skipped_count", models.PositiveIntegerField(default=0)),
                ("failed_count", models.PositiveIntegerField(default=0)),
                ("closed_count", models.PositiveIntegerField(default=0, help_text="Subscriptions auto-closed at the end of the run")),
                ("error", models.TextField(blank=True)),
                ("triggered_by", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="+", to=settings.AUTH_USER_MODEL)),
            ],
            options={"ordering": ["-id"]},
        ),
        migrations.CreateModel(
            name="BillingRunItem",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("subscription_number", models.CharField(blank=True, max_length=30)),
                ("period_start", models.DateField(blank=True, null=True)),
                ("outcome", models.CharField(choices=[("created", "Invoice created"), ("skipped", "Skipped"), ("failed", "Failed")], max_length=10)),
                ("reason", models.CharField(blank=True, max_length=500)),
                ("invoice", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="+", to="core.invoice")),
                ("run", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="items", to="core.billingrun")),
                ("subscription", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="+", to="core.subscription")),
            ],
            options={
                "ordering": ["id"],
                "indexes": [models.Index(fields=["run", "outcome"], name="bri_run_outcome_idx")],
            },
        ),
    ]
