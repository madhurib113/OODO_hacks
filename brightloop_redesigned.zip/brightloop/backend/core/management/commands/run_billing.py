"""Scheduled billing: python manage.py run_billing [--as-of YYYY-MM-DD]. Cron / Render cron job friendly."""
from datetime import date

from django.core.management.base import BaseCommand

from core import services
from core.models import BillingRun


class Command(BaseCommand):
    help = "Run recurring billing now and record it in the billing-run audit log."

    def add_arguments(self, p):
        p.add_argument("--as-of", type=date.fromisoformat, default=None, help="Bill everything due up to this date")

    def handle(self, *a, as_of, **o):
        r = services.generate_invoices(as_of=as_of, trigger=BillingRun.Trigger.SCHEDULED)
        self.stdout.write(self.style.SUCCESS(
            f"Run #{r['run_id']}: {r['created']} created, {r['skipped']} skipped, {r['failed']} failed, {r['closed']} closed."))
