"""Demo data: python manage.py seed_demo --count 5000 --bill"""
import random
from datetime import timedelta
from decimal import Decimal

from django.contrib.auth.hashers import make_password
from django.core.management.base import BaseCommand
from django.db import transaction
from django.db.models import Max
from django.utils import timezone

from core import services
from core.models import (AddOn, BillingRun, Discount, Invoice, Payment, Plan, Product, ProductVariant, Quotation,
                         QuotationLine, QuotationTemplate, QuotationTemplateLine, Subscription, SubscriptionAddOn,
                         SubscriptionLine, TaxRule, User)

FIRST = ["Aarav", "Diya", "Kabir", "Meera", "Rohan", "Isha", "Vihaan", "Anaya", "Arjun", "Sara", "Neel", "Tara"]
BIZ = ["Traders", "Studios", "Labs", "Foods", "Logistics", "Retail", "Textiles", "Clinic", "Cafe", "Systems"]


class Command(BaseCommand):
    help = "Create demo users, catalog and thousands of subscriptions."

    def add_arguments(self, p):
        p.add_argument("--count", type=int, default=2000)
        p.add_argument("--customers", type=int, default=300)
        p.add_argument("--bill", action="store_true", help="Run billing, confirm most invoices and record payments")
        p.add_argument("--force", action="store_true")

    def handle(self, *a, count, customers, bill, force, **o):
        if User.objects.filter(email="admin@brightloop.test").exists() and not force:
            self.stdout.write("Demo data already present (use --force to add more).")
            return
        rnd = random.Random(42)
        today = timezone.localdate()

        with transaction.atomic():
            if not User.objects.filter(email="admin@brightloop.test").exists():
                User.objects.create_superuser("admin@brightloop.test", "Admin@12345", first_name="Asha", last_name="Admin")
                User.objects.create_user("staff@brightloop.test", "Staff@12345", role="staff", first_name="Sam", last_name="Support")
                User.objects.create_user("customer@brightloop.test", "Customer@123", first_name="Nisha", company="Nisha Traders")

            pwd = make_password("Customer@123")
            start_id = (User.objects.aggregate(m=Max("id"))["m"] or 0) + 1
            User.objects.bulk_create([
                User(email=f"customer{start_id + i}@example.com", password=pwd, role="customer",
                     first_name=rnd.choice(FIRST), company=f"{rnd.choice(FIRST)} {rnd.choice(BIZ)}")
                for i in range(customers)], batch_size=500)
            custs = list(User.objects.filter(role="customer"))

            if not Product.objects.exists():
                crm = Product.objects.create(name="Brightloop CRM", type="software", sales_price=1200, cost_price=700)
                books = Product.objects.create(name="Brightloop Books", type="software", sales_price=900, cost_price=500)
                help_ = Product.objects.create(name="Helpdesk Add-on", type="addon", sales_price=300, cost_price=120)
                conn = Product.objects.create(name="ERP Connector", type="software", sales_price=1500, cost_price=800,
                                              notes="Choose a brand; Odoo adds 560")
                ProductVariant.objects.create(product=conn, attribute="Brand", value="Odoo", extra_price=560)
                ProductVariant.objects.create(product=conn, attribute="Brand", value="Tally", extra_price=300)
                ProductVariant.objects.create(product=conn, attribute="Brand", value="Standard", extra_price=0)
                monthly = Plan.objects.create(name="Monthly Standard", price=1200, billing_period="monthly", pausable=True)
                yearly = Plan.objects.create(name="Yearly Business", price=12000, billing_period="yearly", auto_close=True)
                weekly = Plan.objects.create(name="Weekly Trial", price=300, billing_period="weekly", renewable=False)
                Plan.objects.create(name="Daily Pass", price=50, billing_period="daily", closable=False)
                TaxRule.objects.create(name="GST 18%", rate=Decimal("18"))
                TaxRule.objects.create(name="GST 12% (Helpdesk)", rate=Decimal("12"), product=help_)
                Discount.objects.create(name="Volume 10% (10+ seats)", kind="percent", value=10, apply_to="subscription", min_quantity=10)
                Discount.objects.create(name="Welcome Rs.500 off", kind="fixed", value=500, apply_to="subscription",
                                        min_amount=2000, usage_limit=50)
                Discount.objects.create(name="CRM loyalty 5%", kind="percent", value=5, apply_to="product", product=crm)
                AddOn.objects.create(name="Priority Support", description="4-hour response SLA", price=250)
                AddOn.objects.create(name="Extra Storage 100GB", description="Additional file storage", price=120)
                AddOn.objects.create(name="Onboarding Workshop", description="Monthly plans only", price=400).eligible_plans.set([monthly])
                t = QuotationTemplate.objects.create(name="Standard SMB Pack", validity_days=30, plan=monthly)
                QuotationTemplateLine.objects.create(template=t, product=crm, quantity=5)
                QuotationTemplateLine.objects.create(template=t, product=help_, quantity=5)

            products = list(Product.objects.prefetch_related("variants"))
            plans = {p.billing_period: p for p in Plan.objects.all()}
            weights = [("active", 70), ("closed", 14), ("confirmed", 6), ("quotation", 5), ("draft", 5)]
            statuses = [s for s, w in weights for _ in range(w)]
            period_choices = ["monthly"] * 70 + ["yearly"] * 25 + ["weekly"] * 5
            base = Subscription.objects.aggregate(m=Max("id"))["m"] or 0

            subs = []
            for i in range(count):
                st, per = rnd.choice(statuses), rnd.choice(period_choices)
                start = today - timedelta(days=rnd.randint(0, 300))
                nxt = (today - timedelta(days=rnd.randint(0, 40))) if st == "active" else None
                subs.append(Subscription(
                    number=f"SUB-{base + i + 1:06d}", customer=rnd.choice(custs), plan=plans[per], status=st,
                    start_date=start, expiry_date=services.add_months(start, 24),
                    payment_terms_days=rnd.choice([7, 15, 30]), next_invoice_date=nxt,
                    quotation_valid_until=today + timedelta(days=30) if st == "quotation" else None))
            Subscription.objects.bulk_create(subs, batch_size=1000)

            lines = []
            for s in subs:
                for prod in rnd.sample(products, rnd.randint(1, 3)):
                    var = rnd.choice(list(prod.variants.all())) if prod.variants.all() else None
                    price = prod.sales_price + (var.extra_price if var else 0)
                    lines.append(SubscriptionLine(subscription=s, product=prod, variant=var,
                                                  quantity=rnd.randint(1, 15), unit_price=price))
            SubscriptionLine.objects.bulk_create(lines, batch_size=2000)

            # Roughly one in six subscriptions carries an add-on from the catalogue (price snapshotted).
            addons = list(AddOn.objects.filter(eligible_plans__isnull=True, eligible_products__isnull=True))
            sub_addons = [SubscriptionAddOn(subscription=sb, add_on=a, quantity=rnd.randint(1, 5), unit_price=a.price,
                                            start_date=sb.start_date)
                          for sb in subs if sb.status in ("active", "confirmed") and rnd.random() < 0.17
                          for a in [rnd.choice(addons)]] if addons else []
            SubscriptionAddOn.objects.bulk_create(sub_addons, batch_size=2000)

            # A handful of standalone quotations in each state.
            tmpl = QuotationTemplate.objects.first()
            if tmpl:
                for i in range(40):
                    q = Quotation.objects.create(
                        customer=rnd.choice(custs), plan=tmpl.plan, template=tmpl, validity_days=tmpl.validity_days,
                        issue_date=today - timedelta(days=rnd.randint(0, 45)), start_date=today + timedelta(days=7),
                        status=rnd.choice(["draft", "sent", "sent", "cancelled"]))
                    QuotationLine.objects.bulk_create([
                        QuotationLine(quotation=q, product=l.product, variant=l.variant, quantity=l.quantity,
                                      unit_price=l.product.sales_price + (l.variant.extra_price if l.variant else 0))
                        for l in tmpl.lines.select_related("product", "variant")])

        self.stdout.write(self.style.SUCCESS(f"Created {count} subscriptions, {len(lines)} lines and {len(sub_addons)} add-ons."))

        if bill:
            res = services.generate_invoices(as_of=today, trigger=BillingRun.Trigger.SEED)
            self.stdout.write(f"Billing run: {res['created']} invoices created.")
            invs = list(Invoice.objects.filter(status="draft").only("id", "status", "total", "amount_paid", "issue_date", "due_date"))
            pays = []
            for inv in invs:
                if rnd.random() < 0.08:
                    continue  # leave some drafts
                inv.status = "confirmed"
                if rnd.random() < 0.6:
                    inv.amount_paid, inv.status = inv.total, "paid"
                    pays.append(Payment(invoice=inv, method=rnd.choice(["card", "upi", "bank_transfer", "cash", "cheque"]),
                                        amount=inv.total, date=today - timedelta(days=rnd.randint(0, 120)), note="Demo payment"))
            Invoice.objects.bulk_update(invs, ["status", "amount_paid"], batch_size=1000)
            Payment.objects.bulk_create(pays, batch_size=1000)
            # Age some confirmed invoices so overdue shows up on the dashboard.
            old = list(Invoice.objects.filter(status="confirmed").order_by("id").values_list("id", flat=True)[:400])
            Invoice.objects.filter(id__in=old).update(due_date=today - timedelta(days=20), issue_date=today - timedelta(days=35))
            self.stdout.write(self.style.SUCCESS(f"Confirmed invoices, recorded {len(pays)} payments, aged {len(old)} invoices."))
