import { Plus, Trash2 } from "lucide-react";
import { money } from "../api";
import { useOptions } from "./ui";

export const emptyLine = () => ({ product: "", variant: "", quantity: 1 });
export const linesPayload = (lines) =>
  lines.filter((l) => l.product).map((l) => ({ product: l.product, variant: l.variant || null, quantity: Number(l.quantity) }));

/** Product / variant / quantity rows shared by the new-subscription and new-quotation forms. */
export default function LinesEditor({ lines, setLines, plan }) {
  const products = useOptions("/products/");
  const setLine = (i, k, v) => setLines((ls) => ls.map((l, j) => (j === i ? { ...l, [k]: v, ...(k === "product" ? { variant: "" } : {}) } : l)));
  return (
    <div className="sm:col-span-2 mt-2">
      <div className="font-semibold mb-1">Lines</div>
      {lines.map((l, i) => {
        const prod = (products.data || []).find((p) => String(p.id) === String(l.product));
        return (
          <div key={i} className="grid grid-cols-12 gap-2 mb-2">
            <select className="select select-bordered select-sm col-span-5" value={l.product} onChange={(e) => setLine(i, "product", e.target.value)} required={i === 0}>
              <option value="">Product…</option>{(products.data || []).map((p) => <option key={p.id} value={p.id}>{p.name} · {money(p.sales_price)}</option>)}</select>
            <select className="select select-bordered select-sm col-span-4" value={l.variant} disabled={!prod?.variants?.length} onChange={(e) => setLine(i, "variant", e.target.value)}>
              <option value="">{prod?.variants?.length ? "Variant…" : "No variants"}</option>{prod?.variants?.map((v) => <option key={v.id} value={v.id}>{v.value} (+{money(v.extra_price)})</option>)}</select>
            <input type="number" min={plan?.min_quantity || 1} className="input input-bordered input-sm col-span-2" value={l.quantity} onChange={(e) => setLine(i, "quantity", e.target.value)} />
            <button type="button" className="btn btn-ghost btn-sm col-span-1 text-error" aria-label="Remove line" onClick={() => setLines((ls) => ls.filter((_, j) => j !== i))}><Trash2 size={14} /></button>
          </div>);
      })}
      <button type="button" className="btn btn-xs" onClick={() => setLines([...lines, emptyLine()])}><Plus size={12} /> Add line</button>
    </div>
  );
}
