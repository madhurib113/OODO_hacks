import { useEffect, useState } from "react";
import { Link, NavLink, Navigate, Outlet, Route, Routes, useNavigate } from "react-router-dom";
import { Banknote, FileText, History, LayoutDashboard, LogOut, Menu, Moon, Package, Receipt, Repeat, Sun, Tag, Users } from "lucide-react";
import { useAuth } from "./auth";
import { Spinner, Toaster } from "./components/ui";
import { Forgot, Login, Register, ResetPassword } from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import StaffDashboard from "./pages/StaffDashboard";
import Subscriptions from "./pages/Subscriptions";
import Quotations from "./pages/Quotations";
import BillingRuns from "./pages/BillingRuns";
import Invoices from "./pages/Invoices";
import Payments from "./pages/Payments";
import Team from "./pages/Team";
import { AddOns, Discounts, Plans, Products, Taxes, Templates, Variants } from "./pages/Catalog";

function Layout() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const [theme, setTheme] = useState(localStorage.getItem("theme") || "light");
  const [mobileOpen, setMobileOpen] = useState(false);
  useEffect(() => { document.documentElement.setAttribute("data-theme", theme); localStorage.setItem("theme", theme); }, [theme]);
  const admin = user.role === "admin";
  const staff = user.role === "staff";
  const customer = user.role === "customer";

  const sections = customer ? [
    { title: "MY ACCOUNT", links: [["/", "My subscriptions", Repeat], ["/invoices", "Invoices", Receipt], ["/payments", "Payment history", Banknote]] },
  ] : admin ? [
    { title: "OVERVIEW", links: [["/", "Executive overview", LayoutDashboard]] },
    { title: "WORKSPACE", links: [["/subscriptions", "Subscriptions", Repeat], ["/quotations", "Quotations", FileText], ["/invoices", "Invoices", Receipt], ["/payments", "Payments", Banknote]] },
    { title: "CONFIGURATION", links: [["/products", "Product catalogue", Package], ["/discounts", "Taxes & discounts", Tag], ["/users", "People & access", Users], ["/billing-runs", "Billing operations", History]] },
  ] : [
    { title: "WORKSPACE", links: [["/", "Work overview", LayoutDashboard], ["/quotations", "Create quotations", FileText], ["/subscriptions", "Subscriptions", Repeat], ["/invoices", "Invoice desk", Receipt], ["/payments", "Payment recording", Banknote]] },
  ];
  const initials = (user.first_name || user.email || "U").slice(0, 1).toUpperCase();
  const roleLabel = admin ? "Administrator" : staff ? "Operations staff" : "Customer";
  return (
    <div className={`app-shell role-${user.role}`}>
      <aside className={`sidebar ${mobileOpen ? "sidebar-open" : ""}`}>
        <Link to="/" className="brand-lockup" onClick={() => setMobileOpen(false)}>
          <span className="brand-mark"><Repeat size={21} strokeWidth={2.5} /></span>
          <span><strong>brightloop</strong><small>SUBSCRIPTION CLOUD</small></span>
        </Link>
        <div className="workspace-chip"><span className="workspace-dot" /><span>{admin ? "Control centre" : staff ? "Operations workspace" : "Customer portal"}</span></div>
        <nav className="side-nav">
          {sections.map((section) => <div className="nav-section" key={section.title}>
            <div className="nav-heading">{section.title}</div>
            {section.links.map(([to, label, Icon], i) => <NavLink key={`${to}-${label}`} to={to} end={to === "/"} onClick={() => setMobileOpen(false)} className={({ isActive }) => `side-link ${isActive ? "side-link-active" : ""}`}>
              <Icon size={18} strokeWidth={1.9} /><span>{label}</span>
              {admin && label === "People & access" && <span className="nav-count">ADMIN</span>}
            </NavLink>)}
          </div>)}
        </nav>
        <div className="sidebar-bottom">
          <div className="sidebar-help"><div className="help-icon">✦</div><div><b>{admin ? "System oversight" : staff ? "Customer-first service" : "Need assistance?"}</b><small>{admin ? "Manage your subscription business" : staff ? "Keep every account moving" : "Your subscriptions, in one place"}</small></div></div>
          <div className="profile-card"><div className="avatar-circle">{initials}</div><div className="profile-meta"><b>{user.first_name || user.email}</b><small>{roleLabel}</small></div><button className="icon-button" title="Sign out" onClick={() => { logout(); nav("/login"); }}><LogOut size={17} /></button></div>
        </div>
      </aside>
      {mobileOpen && <button className="mobile-scrim" onClick={() => setMobileOpen(false)} aria-label="Close menu" />}
      <div className="main-column">
        <header className="topbar">
          <button className="icon-button mobile-menu-button" onClick={() => setMobileOpen(true)} aria-label="Open menu"><Menu size={20} /></button>
          <div className="breadcrumb"><span>Brightloop</span><span className="crumb-slash">/</span><b>{admin ? "Admin console" : staff ? "Staff workspace" : "My account"}</b></div>
          <div className="topbar-right"><span className={`role-pill ${user.role}`}>{roleLabel}</span><button className="icon-button" aria-label="Toggle theme" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>{theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}</button></div>
        </header>
        <main className="page-content"><Outlet /></main>
        <footer className="app-footer"><span>© 2026 Brightloop</span><span>Subscription management, made clear.</span></footer>
      </div>
    </div>
  );
}

function CatalogTabs() {
  const [tab, setTab] = useState("products");
  const { user } = useAuth();
  const tabs = { products: Products, variants: Variants, "add-ons": AddOns, plans: Plans, templates: Templates };
  const T = tabs[tab];
  return (<>
    <div role="tablist" className="tabs tabs-box mb-4 w-fit">{Object.keys(tabs).map((k) => <button key={k} role="tab" className={`tab capitalize ${tab === k ? "tab-active" : ""}`} onClick={() => setTab(k)}>{k}</button>)}</div>
    {user.role !== "admin" && <div className="alert alert-info text-sm mb-4">View only. Only the admin can change the catalog.</div>}
    <T />
  </>);
}
function PricingTabs() {
  const [tab, setTab] = useState("discounts");
  const { user } = useAuth();
  const T = tab === "discounts" ? Discounts : Taxes;
  return (<>
    <div role="tablist" className="tabs tabs-box mb-4 w-fit">{["discounts", "taxes"].map((k) => <button key={k} role="tab" className={`tab capitalize ${tab === k ? "tab-active" : ""}`} onClick={() => setTab(k)}>{k}</button>)}</div>
    {user.role !== "admin" && <div className="alert alert-info text-sm mb-4">View only. Only the admin can create discount and tax rules.</div>}
    <T />
  </>);
}

function Protected({ roles }) {
  const { user, loading } = useAuth();
  if (loading) return <Spinner />;
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/" replace />;
  return <Layout />;
}
const StaffHome = () => <StaffDashboard />;
const Home = () => { const { user } = useAuth(); return user.role === "customer" ? <Subscriptions /> : user.role === "staff" ? <StaffHome /> : <Dashboard />; };

export default function App() {
  return (
    <>
      <Toaster />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot" element={<Forgot />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route element={<Protected />}>
          <Route path="/" element={<Home />} />
          <Route path="/quotations" element={<Quotations />} />
          <Route path="/invoices" element={<Invoices />} />
          <Route path="/payments" element={<Payments />} />
        </Route>
        <Route element={<Protected roles={["admin", "staff"]} />}>
          <Route path="/subscriptions" element={<Subscriptions />} />
        </Route>
        <Route element={<Protected roles={["admin"]} />}>
          <Route path="/billing-runs" element={<BillingRuns />} />
          <Route path="/products" element={<CatalogTabs />} />
          <Route path="/discounts" element={<PricingTabs />} />
          <Route path="/users" element={<Team />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  );
}
