import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Minus, Plus, Search, Trash2 } from "lucide-react";
import { api, errMsg, money, rows, today } from "../api";
import { useAuth } from "../auth";
import LinesEditor, { emptyLine, linesPayload } from "../components/LinesEditor";
import { Badge, Empty, ErrorBox, Field, Modal, PageHeader, Pager, Spinner, toast, useOptions } from "../components/ui";

const NEXT = { draft: ["quotation", "Make quotation"], quotation: ["confirmed", "Confirm"], confirmed: ["active", "Activate"] };

export default function Subscriptions() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const isStaff = user.role !== "customer";
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");
  const [modal, setModal] = useState(null); // "new" | subscription (details)

  const list = useQuery({
    queryKey: ["subscriptions", page, search, status],
    queryFn: async () => (await api.get("/subscriptions/", { params: { page, search: search || undefined, status: status || undefined } })).data,
    placeholderData: (p) => p,
  });
  const act = useMutation({
    mutationFn: ({ id, action, body }) => api.post(`/subscriptions/${id}/${action}/`, body),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["subscriptions"] }); qc.invalidateQueries({ queryKey: ["dashboard"] }); toast("Updated"); },
    onError: (e) => toast(errMsg(e), "error"),
  });
  const remove = useMutation({
    mutationFn: (id) => api.delete(`/subscriptions/${id}/`),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["subscriptions"] }); toast("Deleted"); },
    onError: (e) => toast(errMsg(e), "error"),
  });

  const Actions = ({ s }) => (
    <div className="flex flex-wrap gap-1 justify-end">
      {isStaff && NEXT[s.status] && (
        <button className="btn btn-xs btn-primary" onClick={() => act.mutate({ id: s.id, action: "transition", body: { status: NEXT[s.status][0] } })}>{NEXT[s.status][1]}</button>
      )}
      {s.status === "active" && !s.is_paused && s.plan_pausable && <button className="btn btn-xs" onClick={() => act.mutate({ id: s.id, action: "pause" })}>Pause</button>}
      {s.is_paused && <button className="btn btn-xs" onClick={() => act.mutate({ id: s.id, action: "resume" })}>Resume</button>}
      {["active", "closed"].includes(s.status) && s.plan_renewable && <button className="btn btn-xs" onClick={() => act.mutate({ id: s.id, action: "renew" })}>Renew</button>}
      {["confirmed", "active"].includes(s.status) && s.plan_closable && (
        <button className="btn btn-xs btn-outline btn-error" onClick={() => confirm("Close this subscription?") && act.mutate({ id: s.id, action: "transition", body: { status: "closed" } })}>Close</button>
      )}
      {isStaff && s.status === "draft" && <button className="btn btn-xs btn-ghost text-error" aria-label="Delete" onClick={() => confirm("Delete draft?") && remove.mutate(s.id)}><Trash2 size={14} /></button>}
    </div>
  );

  const data = rows(list.data);
  return (
    <>
      <PageHeader title={isStaff ? "Subscriptions" : "My subscriptions"} sub="Draft → Quotation → Confirmed → Active → Closed · open a subscription to manage its add-ons">
        <label className="input input-bordered input-sm flex items-center gap-2"><Search size={14} />
          <input placeholder="Search number or customer" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} /></label>
        <select className="select select-bordered select-sm" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
          <option value="">All statuses</option>{["draft", "quotation", "confirmed", "active", "closed"].map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        {isStaff && <button className="btn btn-sm btn-primary" onClick={() => setModal("new")}><Plus size={16} /> New</button>}
      </PageHeader>

      {list.isLoading ? <Spinner /> : list.isError ? <ErrorBox error={list.error} /> : data.length === 0 ? <Empty text="No subscriptions found" /> : (
        <div className="card bg-base-100 shadow overflow-x-auto">
          <table className="table">
            <thead><tr><th>Number</th>{isStaff && <th>Customer</th>}<th>Plan</th><th>Status</th><th>Next invoice</th><th className="text-right">Per period</th><th /></tr></thead>
            <tbody>{data.map((s) => (
              <tr key={s.id} className="hover">
                <td><button className="link font-semibold" onClick={() => setModal(s)}>{s.number}</button></td>
                {isStaff && <td>{s.customer_company || s.customer_email}</td>}
                <td>{s.plan_name}<div className="text-xs text-base-content/60 capitalize">{s.billing_period}</div></td>
                <td><Badge value={s.status} />{s.is_paused && <span className="badge badge-outline ml-1">paused</span>}</td>
                <td>{s.next_invoice_date || "—"}</td>
                <td className="text-right">{money(s.total)}</td>
                <td><Actions s={s} /></td>
              </tr>))}
            </tbody>
          </table>
        </div>)}
      {list.data?.count != null && <Pager page={page} setPage={setPage} count={list.data.count} />}

      {modal === "new" && <NewSubscription onClose={() => setModal(null)} />}
      {modal && typeof modal === "object" && <Details id={modal.id} onClose={() => setModal(null)} />}
    </>
  );
}

function Details({ id, onClose }) {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["subscription", id], queryFn: async () => (await api.get(`/subscriptions/${id}/`)).data });
  const s = q.data;
  const open = s && s.status !== "closed";
  const eligible = useQuery({
    queryKey: ["add-ons", "eligible", id],
    queryFn: async () => rows((await api.get("/add-ons/", { params: { subscription: id, page_size: 200 } })).data),
    enabled: !!open,
  });
  const [pick, setPick] = useState({ add_on: "", quantity: 1 });
  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["subscription", id] });
    qc.invalidateQueries({ queryKey: ["subscriptions"] });
    qc.invalidateQueries({ queryKey: ["add-ons", "eligible", id] });
  };
  const attach = useMutation({
    mutationFn: () => api.post(`/subscriptions/${id}/add-ons/`, { add_on: Number(pick.add_on), quantity: Number(pick.quantity) }),
    onSuccess: () => { refresh(); setPick({ add_on: "", quantity: 1 }); toast("Add-on added"); },
    onError: (e) => toast(errMsg(e), "error"),
  });
  const change = useMutation({
    mutationFn: ({ addOnId, body }) => api.patch(`/subscription-add-ons/${addOnId}/`, body),
    onSuccess: () => { refresh(); toast("Add-on updated"); },
    onError: (e) => toast(errMsg(e), "error"),
  });

  if (!s) return <Modal title="Subscription" onClose={onClose} wide>{q.isError ? <ErrorBox error={q.error} /> : <Spinner />}</Modal>;
  const live = s.add_ons.filter((a) => a.is_active);
  const past = s.add_ons.filter((a) => !a.is_active);
  const free = (eligible.data || []).filter((a) => !live.some((l) => l.add_on === a.id));
  return (
    <Modal title={`${s.number} · ${s.plan_name}`} onClose={onClose} wide>
      <div className="grid sm:grid-cols-4 gap-2 text-sm mb-3">
        <div><span className="text-base-content/60">Customer</span><br />{s.customer_email}</div>
        <div><span className="text-base-content/60">Start / Expiry</span><br />{s.start_date} → {s.expiry_date || "open"}</div>
        <div><span className="text-base-content/60">Payment terms</span><br />{s.payment_terms_days} days</div>
        <div><span className="text-base-content/60">Per period (before tax)</span><br /><b>{money(s.total)}</b></div>
      </div>
      <table className="table table-sm"><thead><tr><th>Product</th><th>Qty</th><th>Unit</th><th>Tax</th><th className="text-right">Amount</th></tr></thead>
        <tbody>{s.lines.map((l) => <tr key={l.id}><td>{l.product_name}{l.variant_name && <div className="text-xs text-base-content/60">{l.variant_name}</div>}</td>
          <td>{l.quantity}</td><td>{money(l.unit_price)}</td><td>{l.tax_rate}%</td><td className="text-right">{money(l.amount)}</td></tr>)}</tbody></table>

      <h4 className="font-semibold mt-5 mb-1">Add-ons</h4>
      {live.length === 0 ? <p className="text-sm text-base-content/60 mb-2">No active add-ons.</p> : (
        <table className="table table-sm"><thead><tr><th>Add-on</th><th>Quantity</th><th>Unit (locked)</th><th>Since</th><th className="text-right">Amount</th><th /></tr></thead>
          <tbody>{live.map((a) => (
            <tr key={a.id}>
              <td>{a.add_on_name}</td>
              <td><div className="join">
                <button className="btn btn-xs join-item" aria-label="Decrease quantity" disabled={a.quantity <= 1 || change.isPending} onClick={() => change.mutate({ addOnId: a.id, body: { quantity: a.quantity - 1 } })}><Minus size={12} /></button>
                <span className="btn btn-xs join-item pointer-events-none">{a.quantity}</span>
                <button className="btn btn-xs join-item" aria-label="Increase quantity" disabled={change.isPending} onClick={() => change.mutate({ addOnId: a.id, body: { quantity: a.quantity + 1 } })}><Plus size={12} /></button></div></td>
              <td>{money(a.unit_price)}</td><td>{a.start_date}{a.end_date && <div className="text-xs text-warning">ends {a.end_date}</div>}</td>
              <td className="text-right">{money(a.amount)}</td>
              <td className="text-right">{open && <button className="btn btn-xs btn-ghost text-error" disabled={change.isPending}
                onClick={() => confirm(`Remove ${a.add_on_name}? It will no longer be billed.`) && change.mutate({ addOnId: a.id, body: { is_active: false } })}>Remove</button>}</td>
            </tr>))}</tbody></table>)}
      {open && (
        <form className="flex flex-wrap items-end gap-2 mt-2" onSubmit={(e) => { e.preventDefault(); attach.mutate(); }}>
          <select className="select select-bordered select-sm" value={pick.add_on} required onChange={(e) => setPick({ ...pick, add_on: e.target.value })} aria-label="Add-on">
            <option value="">{eligible.isLoading ? "Loading…" : free.length ? "Choose an add-on…" : "No add-ons available"}</option>
            {free.map((a) => <option key={a.id} value={a.id}>{a.name} · {money(a.price)}</option>)}</select>
          <input type="number" min={1} className="input input-bordered input-sm w-20" value={pick.quantity} aria-label="Quantity" onChange={(e) => setPick({ ...pick, quantity: e.target.value })} />
          <button className="btn btn-sm btn-primary" disabled={attach.isPending || !pick.add_on}><Plus size={14} /> Add</button>
        </form>)}
      {past.length > 0 && <details className="mt-3 text-sm"><summary className="cursor-pointer text-base-content/60">Removed add-ons ({past.length})</summary>
        <ul className="mt-1 space-y-1">{past.map((a) => (
          <li key={a.id} className="flex items-center justify-between">
            <span>{a.add_on_name} × {a.quantity} · {a.start_date} → {a.end_date || "—"}</span>
            {open && <button className="btn btn-xs btn-ghost" disabled={change.isPending} onClick={() => change.mutate({ addOnId: a.id, body: { is_active: true } })}>Restore</button>}
          </li>))}</ul></details>}
    </Modal>
  );
}

function NewSubscription({ onClose }) {
  const qc = useQueryClient();
  const plans = useOptions("/plans/");
  const [f, setF] = useState({ customer: "", plan: "", start_date: today(), expiry_date: "", payment_terms_days: 15 });
  const [lines, setLines] = useState([emptyLine()]);
  const plan = (plans.data || []).find((p) => String(p.id) === String(f.plan));

  const create = useMutation({
    mutationFn: () => api.post("/subscriptions/", { ...f, expiry_date: f.expiry_date || null, lines: linesPayload(lines) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["subscriptions"] }); toast("Subscription created"); onClose(); },
    onError: (e) => toast(errMsg(e), "error"),
  });
  return (
    <Modal title="New subscription" onClose={onClose} wide>
      <form onSubmit={(e) => { e.preventDefault(); create.mutate(); }} className="grid gap-2 sm:grid-cols-2">
        <Field f={{ label: "Customer", required: true, optionsFrom: "/users/", optionsParams: { role: "customer", page_size: 200 }, optionLabel: "email" }} value={f.customer} onChange={(v) => setF({ ...f, customer: v })} />
        <Field f={{ label: "Plan", required: true, optionsFrom: "/plans/", help: plan && `Min quantity ${plan.min_quantity} · bills ${plan.billing_period}` }} value={f.plan} onChange={(v) => setF({ ...f, plan: v })} />
        <Field f={{ label: "Start date", type: "date", required: true }} value={f.start_date} onChange={(v) => setF({ ...f, start_date: v })} />
        <Field f={{ label: "Expiry date", type: "date" }} value={f.expiry_date} onChange={(v) => setF({ ...f, expiry_date: v })} />
        <Field f={{ label: "Payment terms (days)", type: "number", min: 0 }} value={f.payment_terms_days} onChange={(v) => setF({ ...f, payment_terms_days: v })} />
        <LinesEditor lines={lines} setLines={setLines} plan={plan} />
        <div className="sm:col-span-2 modal-action"><button type="button" className="btn" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" disabled={create.isPending}>Create draft</button></div>
      </form>
    </Modal>
  );
}
