import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { api, rows } from "../api";
import { Badge, Empty, ErrorBox, Modal, PageHeader, Pager, Spinner } from "../components/ui";

const when = (iso) => (iso ? new Date(iso).toLocaleString("en-IN") : "—");

export default function BillingRuns() {
  const [page, setPage] = useState(1);
  const [open, setOpen] = useState(null);
  const list = useQuery({
    queryKey: ["billing-runs", page],
    queryFn: async () => (await api.get("/billing-runs/", { params: { page } })).data,
    placeholderData: (p) => p,
  });
  const data = rows(list.data);
  return (
    <>
      <PageHeader title="Billing runs" sub="Audit log of every recurring-billing run: who or what triggered it, and what happened to each subscription" />
      {list.isLoading ? <Spinner /> : list.isError ? <ErrorBox error={list.error} /> : data.length === 0 ? <Empty text="No billing runs yet. Run billing from the Invoices page." /> : (
        <div className="card bg-base-100 shadow overflow-x-auto">
          <table className="table">
            <thead><tr><th>Run</th><th>Started</th><th>Trigger</th><th>Billed up to</th><th>Status</th>
              <th className="text-right">Created</th><th className="text-right">Skipped</th><th className="text-right">Failed</th><th className="text-right">Closed</th></tr></thead>
            <tbody>{data.map((r) => (
              <tr key={r.id} className="hover">
                <td><button className="link font-semibold" onClick={() => setOpen(r)}>#{r.id}</button></td>
                <td className="text-sm">{when(r.started_at)}</td>
                <td className="text-sm">{r.trigger_label}{r.triggered_by_email && <div className="text-xs text-base-content/60">{r.triggered_by_email}</div>}</td>
                <td>{r.as_of}</td>
                <td><Badge value={r.status} /></td>
                <td className="text-right">{r.created_count}</td><td className="text-right">{r.skipped_count}</td>
                <td className={`text-right ${r.failed_count ? "text-error font-semibold" : ""}`}>{r.failed_count}</td>
                <td className="text-right">{r.closed_count}</td>
              </tr>))}</tbody>
          </table>
        </div>)}
      {list.data?.count != null && <Pager page={page} setPage={setPage} count={list.data.count} />}
      {open && <RunItems run={open} onClose={() => setOpen(null)} />}
    </>
  );
}

function RunItems({ run, onClose }) {
  const [page, setPage] = useState(1);
  const [outcome, setOutcome] = useState("");
  const q = useQuery({
    queryKey: ["billing-run-items", run.id, page, outcome],
    queryFn: async () => (await api.get(`/billing-runs/${run.id}/items/`, { params: { page, outcome: outcome || undefined } })).data,
    placeholderData: (p) => p,
  });
  const data = rows(q.data);
  return (
    <Modal title={`Billing run #${run.id} · ${when(run.started_at)}`} onClose={onClose} wide>
      {run.error && <div className="alert alert-error text-sm mb-3">{run.error}</div>}
      <div role="tablist" className="tabs tabs-box mb-3 w-fit">
        {[["", "All"], ["created", `Created (${run.created_count})`], ["skipped", `Skipped (${run.skipped_count})`], ["failed", `Failed (${run.failed_count})`]].map(([k, l]) => (
          <button key={k} role="tab" className={`tab ${outcome === k ? "tab-active" : ""}`} onClick={() => { setOutcome(k); setPage(1); }}>{l}</button>))}
      </div>
      {q.isLoading ? <Spinner /> : q.isError ? <ErrorBox error={q.error} /> : data.length === 0 ? <Empty text="No items" /> : (
        <div className="overflow-x-auto">
          <table className="table table-sm">
            <thead><tr><th>Subscription</th><th>Period</th><th>Outcome</th><th>Reason</th><th>Invoice</th></tr></thead>
            <tbody>{data.map((i) => (
              <tr key={i.id}><td>{i.subscription_number || `#${i.subscription}`}</td><td>{i.period_start || "—"}</td>
                <td><Badge value={i.outcome} /></td><td className="text-sm">{i.reason}</td><td>{i.invoice_number || "—"}</td></tr>))}</tbody>
          </table>
        </div>)}
      {q.data?.count != null && <Pager page={page} setPage={setPage} count={q.data.count} />}
    </Modal>
  );
}
