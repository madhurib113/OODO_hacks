import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { ArrowUpRight, ClipboardList, FilePlus2, ReceiptText, Repeat2 } from "lucide-react";
import { api, rows } from "../api";
import { Badge, ErrorBox, Spinner } from "../components/ui";

const Tile = ({ icon: Icon, label, value, detail, tint }) => <div className="metric-card">
  <div className={`metric-icon ${tint}`}><Icon size={20} /></div><div className="metric-label">{label}</div><div className="metric-value">{value}</div><div className="metric-detail">{detail}</div>
</div>;

export default function StaffDashboard() {
  const subs = useQuery({ queryKey: ["staff-home-subs"], queryFn: async () => (await api.get("/subscriptions/", { params: { page_size: 100 } })).data });
  const quotes = useQuery({ queryKey: ["staff-home-quotes"], queryFn: async () => (await api.get("/quotations/", { params: { page_size: 100 } })).data });
  if (subs.isLoading || quotes.isLoading) return <Spinner />;
  if (subs.isError) return <ErrorBox error={subs.error} />;
  if (quotes.isError) return <ErrorBox error={quotes.error} />;
  const subscriptions = rows(subs.data), quotations = rows(quotes.data);
  const active = subscriptions.filter(x => x.status === "active").length;
  const pending = quotations.filter(x => ["draft", "quotation", "sent"].includes(x.status)).length;
  const recent = [...quotations].slice(0, 5);
  return <>
    <div className="welcome-banner staff-banner"><div><div className="eyebrow">OPERATIONS WORKSPACE</div><h1>Good work starts here.</h1><p>Your daily command centre for customer requests, quotations and subscription operations.</p></div><div className="welcome-art"><div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="welcome-symbol"><Repeat2 size={42} /></div></div></div>
    <div className="section-heading"><div><h2>Your operations at a glance</h2><p>Live records available to your staff account</p></div></div>
    <div className="metric-grid">
      <Tile icon={Repeat2} label="Subscriptions" value={subscriptions.length} detail={`${active} currently active`} tint="violet" />
      <Tile icon={FilePlus2} label="Quotations" value={quotations.length} detail={`${pending} awaiting action`} tint="blue" />
      <Tile icon={ClipboardList} label="Active accounts" value={new Set(subscriptions.map(x => x.customer).filter(Boolean)).size} detail="Customers in your workspace" tint="mint" />
      <Tile icon={ReceiptText} label="Recent activity" value={recent.length} detail="Latest quotations loaded" tint="amber" />
    </div>
    <div className="staff-grid">
      <section className="surface-card quick-card"><div className="card-heading"><div><h3>Quick actions</h3><p>Move customer work forward</p></div></div>
        <Link className="quick-action" to="/quotations"><span className="quick-icon blue"><FilePlus2 size={19}/></span><span><b>Create a quotation</b><small>Prepare a customer proposal</small></span><ArrowUpRight size={17}/></Link>
        <Link className="quick-action" to="/subscriptions"><span className="quick-icon violet"><Repeat2 size={19}/></span><span><b>Manage subscriptions</b><small>Review lifecycle and status</small></span><ArrowUpRight size={17}/></Link>
        <Link className="quick-action" to="/invoices"><span className="quick-icon mint"><ReceiptText size={19}/></span><span><b>Open invoice desk</b><small>Review and process invoices</small></span><ArrowUpRight size={17}/></Link>
      </section>
      <section className="surface-card recent-card"><div className="card-heading"><div><h3>Recent quotations</h3><p>Latest proposals in the system</p></div><Link to="/quotations" className="text-link">View all <ArrowUpRight size={14}/></Link></div>
        {recent.length ? <div className="recent-list">{recent.map(q => <div className="recent-row" key={q.id}><div className="recent-doc"><FilePlus2 size={17}/></div><div className="recent-info"><b>{q.number || q.name || `Quotation #${q.id}`}</b><small>{q.customer_email || q.customer_name || "Customer quotation"}</small></div><Badge value={q.status || "draft"}/></div>)}</div> : <div className="empty-note">No quotations yet. Create your first customer proposal.</div>}
      </section>
    </div>
  </>;
}
