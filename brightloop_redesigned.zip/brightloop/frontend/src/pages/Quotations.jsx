import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowRightCircle, FilePlus2, Plus, Search, Send, Trash2, XCircle } from "lucide-react";
import { api, errMsg, money, rows, today } from "../api";
import { useAuth } from "../auth";
import LinesEditor, { emptyLine, linesPayload } from "../components/LinesEditor";
import { Badge, Empty, ErrorBox, Field, Modal, PageHeader, Pager, Spinner, toast, useOptions } from "../components/ui";

const validityText = (q) =>
  q.status === "converted" ? `Converted to ${q.subscription_number}`
    : q.status === "cancelled" ? "—"
    : q.is_expired ? `Expired ${q.valid_until}`
    : `Until ${q.valid_until} (${q.days_remaining} day${q.days_remaining === 1 ? "" : "s"} left)`;

export default function Quotations() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const isStaff = user.role !== "customer";
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");
  const [modal, setModal] = useState(null); // "new" | "template" | quotation (details)

  const list = useQuery({
    queryKey: ["quotations", page, search, status],
    queryFn: async () => (await api.get("/quotations/", { params: { page, search: search || undefined, status: status || undefined } })).data,
    placeholderData: (p) => p,
  });
  const refresh = () => { qc.invalidateQueries({ queryKey: ["quotations"] }); qc.invalidateQueries({ queryKey: ["subscriptions"] }); };
  const act = useMutation({
    mutationFn: ({ id, action }) => api.post(`/quotations/${id}/${action}/`),
    onSuccess: ({ data }, v) => {
      refresh();
      toast(v.action === "convert" ? `Converted to subscription ${data.subscription.number}` : v.action === "send" ? "Quotation sent" : "Quotation cancelled");
    },
    onError: (e) => toast(errMsg(e), "error"),
  });
  const remove = useMutation({
    mutationFn: (id) => api.delete(`/quotations/${id}/`),
    onSuccess: () => { refresh(); toast("Deleted"); },
    onError: (e) => toast(errMsg(e), "error"),
  });

  const canConvert = (q) => (isStaff ? ["draft", "sent"] : ["sent"]).includes(q.status) && !q.is_expired;
  const Actions = ({ q }) => (
    <div className="flex flex-wrap gap-1 justify-end">
      {isStaff && q.status === "draft" && <button className="btn btn-xs" onClick={() => act.mutate({ id: q.id, action: "send" })}><Send size={12} /> Send</button>}
      {canConvert(q) && <button className="btn btn-xs btn-primary" onClick={() => confirm(`Convert ${q.number} into a confirmed subscription?`) && act.mutate({ id: q.id, action: "convert" })}>
        <ArrowRightCircle size={12} /> {isStaff ? "Convert" : "Accept"}</button>}
      {isStaff && ["draft", "sent"].includes(q.status) && <button className="btn btn-xs btn-outline btn-error" aria-label="Cancel quotation" onClick={() => confirm("Cancel this quotation?") && act.mutate({ id: q.id, action: "cancel" })}><XCircle size={12} /></button>}
      {isStaff && q.status === "draft" && <button className="btn btn-xs btn-ghost text-error" aria-label="Delete" onClick={() => confirm("Delete draft quotation?") && remove.mutate(q.id)}><Trash2 size={14} /></button>}
    </div>
  );

  const data = rows(list.data);
  return (
    <>
      <PageHeader title={isStaff ? "Quotations" : "My quotations"} sub="Draft → Sent → Converted into a subscription (within its validity period)">
        <label className="input input-bordered input-sm flex items-center gap-2"><Search size={14} />
          <input placeholder="Search number or customer" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} /></label>
        <select className="select select-bordered select-sm" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
          <option value="">All statuses</option>{["draft", "sent", "converted", "cancelled"].map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        {isStaff && <>
          <button className="btn btn-sm" onClick={() => setModal("template")}><FilePlus2 size={16} /> From template</button>
          <button className="btn btn-sm btn-primary" onClick={() => setModal("new")}><Plus size={16} /> New</button></>}
      </PageHeader>

      {list.isLoading ? <Spinner /> : list.isError ? <ErrorBox error={list.error} /> : data.length === 0 ? <Empty text="No quotations found" /> : (
        <div className="card bg-base-100 shadow overflow-x-auto">
          <table className="table">
            <thead><tr><th>Number</th>{isStaff && <th>Customer</th>}<th>Plan</th><th>Status</th><th>Validity</th><th className="text-right">Per period</th><th /></tr></thead>
            <tbody>{data.map((q) => (
              <tr key={q.id} className="hover">
                <td><button className="link font-semibold" onClick={() => setModal(q)}>{q.number}</button></td>
                {isStaff && <td>{q.customer_company || q.customer_email}</td>}
                <td>{q.plan_name}</td>
                <td><Badge value={q.is_expired ? "expired" : q.status} /></td>
                <td className={`text-sm ${q.is_expired ? "text-error" : ""}`}>{validityText(q)}</td>
                <td className="text-right">{money(q.total)}</td>
                <td><Actions q={q} /></td>
              </tr>))}
            </tbody>
          </table>
        </div>)}
      {list.data?.count != null && <Pager page={page} setPage={setPage} count={list.data.count} />}

      {modal === "new" && <NewQuotation onClose={() => setModal(null)} onDone={refresh} />}
      {modal === "template" && <FromTemplate onClose={() => setModal(null)} onDone={refresh} />}
      {modal && typeof modal === "object" && <Details q={modal} onClose={() => setModal(null)} />}
    </>
  );
}

function Details({ q, onClose }) {
  return (
    <Modal title={`${q.number} · ${q.plan_name}`} onClose={onClose} wide>
      <div className="grid sm:grid-cols-4 gap-2 text-sm mb-3">
        <div><span className="text-base-content/60">Customer</span><br />{q.customer_email}</div>
        <div><span className="text-base-content/60">Issued / valid for</span><br />{q.issue_date} · {q.validity_days} days</div>
        <div><span className="text-base-content/60">Proposed term</span><br />{q.start_date} → {q.expiry_date || "open"}</div>
        <div><span className="text-base-content/60">Status</span><br /><Badge value={q.is_expired ? "expired" : q.status} /> <span className="text-xs">{validityText(q)}</span></div>
      </div>
      <table className="table table-sm"><thead><tr><th>Product</th><th>Qty</th><th>Unit</th><th className="text-right">Amount</th></tr></thead>
        <tbody>{q.lines.map((l) => <tr key={l.id}><td>{l.product_name}{l.variant_name && <div className="text-xs text-base-content/60">{l.variant_name}</div>}</td>
          <td>{l.quantity}</td><td>{money(l.unit_price)}</td><td className="text-right">{money(l.amount)}</td></tr>)}</tbody></table>
      <div className="text-right mt-2 font-semibold">Per period {money(q.total)} <span className="text-xs font-normal text-base-content/60">before discount and tax</span></div>
    </Modal>
  );
}

function NewQuotation({ onClose, onDone }) {
  const plans = useOptions("/plans/");
  const [f, setF] = useState({ customer: "", plan: "", start_date: today(), expiry_date: "", validity_days: 30, payment_terms_days: 15 });
  const [lines, setLines] = useState([emptyLine()]);
  const plan = (plans.data || []).find((p) => String(p.id) === String(f.plan));
  const create = useMutation({
    mutationFn: () => api.post("/quotations/", { ...f, expiry_date: f.expiry_date || null, lines: linesPayload(lines) }),
    onSuccess: () => { onDone(); toast("Quotation created"); onClose(); },
    onError: (e) => toast(errMsg(e), "error"),
  });
  return (
    <Modal title="New quotation" onClose={onClose} wide>
      <form onSubmit={(e) => { e.preventDefault(); create.mutate(); }} className="grid gap-2 sm:grid-cols-2">
        <Field f={{ label: "Customer", required: true, optionsFrom: "/users/", optionsParams: { role: "customer", page_size: 200 }, optionLabel: "email" }} value={f.customer} onChange={(v) => setF({ ...f, customer: v })} />
        <Field f={{ label: "Plan", required: true, optionsFrom: "/plans/", help: plan && `Min quantity ${plan.min_quantity} · bills ${plan.billing_period}` }} value={f.plan} onChange={(v) => setF({ ...f, plan: v })} />
        <Field f={{ label: "Valid for (days)", type: "number", required: true, min: 1, help: "Counted from today; the customer can accept until then" }} value={f.validity_days} onChange={(v) => setF({ ...f, validity_days: v })} />
        <Field f={{ label: "Payment terms (days)", type: "number", min: 0 }} value={f.payment_terms_days} onChange={(v) => setF({ ...f, payment_terms_days: v })} />
        <Field f={{ label: "Proposed start date", type: "date", required: true }} value={f.start_date} onChange={(v) => setF({ ...f, start_date: v })} />
        <Field f={{ label: "Proposed expiry date", type: "date" }} value={f.expiry_date} onChange={(v) => setF({ ...f, expiry_date: v })} />
        <LinesEditor lines={lines} setLines={setLines} plan={plan} />
        <div className="sm:col-span-2 modal-action"><button type="button" className="btn" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" disabled={create.isPending}>Save as draft</button></div>
      </form>
    </Modal>
  );
}

function FromTemplate({ onClose, onDone }) {
  const [f, setF] = useState({ template: "", customer: "", start_date: today() });
  const create = useMutation({
    mutationFn: () => api.post("/quotations/from-template/", f),
    onSuccess: () => { onDone(); toast("Draft quotation created from template"); onClose(); },
    onError: (e) => toast(errMsg(e), "error"),
  });
  return (
    <Modal title="Quotation from template" onClose={onClose}>
      <form onSubmit={(e) => { e.preventDefault(); create.mutate(); }} className="grid gap-2">
        <Field f={{ label: "Template", required: true, optionsFrom: "/templates/", help: "Plan, product lines and validity days come from the template" }} value={f.template} onChange={(v) => setF({ ...f, template: v })} />
        <Field f={{ label: "Customer", required: true, optionsFrom: "/users/", optionsParams: { role: "customer", page_size: 200 }, optionLabel: "email" }} value={f.customer} onChange={(v) => setF({ ...f, customer: v })} />
        <Field f={{ label: "Proposed start date", type: "date", required: true }} value={f.start_date} onChange={(v) => setF({ ...f, start_date: v })} />
        <div className="modal-action"><button type="button" className="btn" onClick={onClose}>Cancel</button><button className="btn btn-primary" disabled={create.isPending}>Create quotation</button></div>
      </form>
    </Modal>
  );
}
