from django.urls import include, path
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

from . import views

# trailing_slash='/?' lets /api/add-ons and /api/add-ons/ both work (POSTs without a slash are not redirected)
router = DefaultRouter(trailing_slash="/?")
router.register("users", views.UserViewSet, basename="user")
router.register("products", views.ProductViewSet, basename="product")
router.register("variants", views.VariantViewSet, basename="variant")
router.register("plans", views.PlanViewSet, basename="plan")
router.register("templates", views.TemplateViewSet, basename="template")
router.register("taxes", views.TaxRuleViewSet, basename="tax")
router.register("discounts", views.DiscountViewSet, basename="discount")
router.register("add-ons", views.AddOnViewSet, basename="add-on")
router.register("subscriptions", views.SubscriptionViewSet, basename="subscription")
router.register("subscription-add-ons", views.SubscriptionAddOnViewSet, basename="subscription-add-on")
router.register("quotations", views.QuotationViewSet, basename="quotation")
router.register("billing-runs", views.BillingRunViewSet, basename="billing-run")
router.register("invoices", views.InvoiceViewSet, basename="invoice")
router.register("payments", views.PaymentViewSet, basename="payment")

urlpatterns = [
    path("auth/register/", views.RegisterView.as_view()),
    path("auth/login/", TokenObtainPairView.as_view()),
    path("auth/refresh/", TokenRefreshView.as_view()),
    path("auth/me/", views.MeView.as_view()),
    path("auth/staff/", views.CreateStaffView.as_view()),
    path("auth/password-reset/", views.PasswordResetRequestView.as_view()),
    path("auth/password-reset/confirm/", views.PasswordResetConfirmView.as_view()),
    path("dashboard/", views.DashboardView.as_view()),
    path("", include(router.urls)),
]
